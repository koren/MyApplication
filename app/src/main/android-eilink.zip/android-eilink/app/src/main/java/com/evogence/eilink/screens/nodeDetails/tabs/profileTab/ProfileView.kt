package com.evogence.eilink.screens.nodeDetails.tabs.profileTab

import android.os.Bundle
import android.view.View
import com.evogence.eilink.R
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabView
import kotlinx.android.synthetic.main.node_details_profile.*

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class ProfileView: NodeDetailsTabView<ProfileVM>()
{
    override val title: String = "Profile"
    override val isShowSaveButton = false
    override val layout: Int = R.layout.node_details_profile

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"

        fun build(fingerprint: String): NodeDetailsTabView<ProfileVM>
        {
            val fragment = ProfileView()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }
    }

    override fun fill(model: Any)
    {
        model as ProfileVM
        editionTV.text = model.edition
        systemIdTV.text = model.sId
        locationTV.text = model.location
        companyTV.text = model.company
        ipAddressTV.text = model.ipAddress
        timeZoneTV.text = model.timeZone
        registrationDateTV.text = model.registrationDate
        eiInfoTV.text = String.format("%s\n%s", model.videoChannels, model.audioChannels)
        activityAndLoggingStorageLimitTV.text = model.activity
        upTimeTV.text = model.upTime
        systemTimeTV.text = model.systemTime
        rebootScheduleTV.text = model.rebootScheduler
        model.rebootSchedulerColor.let {rebootScheduleTV.setTextColor(it)}
    }

    override fun retrieveChanges(model: ProfileVM)
    {
    }

    override fun initView()
    {
        rebootActionBtn.setOnClickListener(this)
        restartActionBtn.setOnClickListener(this)
        shutdownActionBtn.setOnClickListener(this)
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.rebootActionBtn -> (presenter as ProfilePresenter).onClickReboot()
            R.id.restartActionBtn -> (presenter as ProfilePresenter).onClickRestart()
            R.id.shutdownActionBtn -> (presenter as ProfilePresenter).onClickShutdown()
        }
    }

    override fun initPresenter()
    {
        presenter = ProfilePresenter(arguments?.getString(FINGERPRINT_KEY))
    }
}
