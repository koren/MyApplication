package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive
/**
 * Created by Koren Vitalii on 07/25/18.
 */
class GetNodeInfoCommand: INodeCommand
{
    override val method: String = "Integration.RPN.settings.ProfilerService::getNodeDetails"
    override val desc: String = "Get Node Info"

    companion object
    {
        const val NO_HARDWARE_DATA: Double = -1.0

        const val MODEL_KEY = "model"
        const val LOCATION_KEY = "location"
        const val COMPANY_KEY = "company"
        const val HARDWARE_KEY = "hardware"
        const val SUMMARY_KEY = "summary"
        const val TITLE_KEY = "title"
        const val REBOOT_SCHEDULER_KEY = "reboot_scheduler"
        const val REBOOT_PLAYBACK_KEY = "reboot_playback"
        const val SHUTDOWN_APPLIANCE_KEY = "shutdown_appliance"
        const val SCHEDULE_REBOOT_KEY = "schedule_reboot"
        const val MAC_ADDRESS_KEY = "mac_address"
        const val INTERFACE_TRAFFIC_KEY = "interface_traffic"
        const val CPU_KEY = "cpu"
        const val GPU_TEMPERATURE_KEY = "gpu_temperature"
        const val SYS_ID_KEY = "system_id"
        const val HOUR_KEY = "hour"
        const val MINUTE_KEY = "minute"
        const val MERIDIEM_KEY = "meridiem"
        const val STATUS_KEY = "status"
        const val EDITION_KEY = "edition"
        const val VERSION_KEY = "version"
        const val SERIAL_NUMBER_KEY = "serial_number"
        const val SYSTEM_TIME_KEY = "system_time"
        const val IP_KEY = "ip"
        const val UPTIME_KEY = "uptime"
        const val TIMEZONE_KEY = "timezone"
        const val LOG_PERIOD_KEY = "log_period"
        const val PROTOCOL_KEY = "protocol"
        const val REGISTRATION_TIME_KEY = "registration_time"
        const val CHANNELS_KEY = "channels"
        const val DATE_KEY = "date"
        const val SEND_LAN_KEY = "send_lan"
        const val RECEIVED_LAN_KEY = "received_lan"
        const val SEND_WIFI_KEY = "send_wifi"
        const val RECEIVED_WIFI_KEY = "received_wifi"
        const val LOAD_KEY = "load"
        const val TEMPERATURE_KEY = "temperature"
        const val FREE_KEY = "free"
        const val TOTAL_KEY = "total"
        const val HDD_KEY = "hdd"
        const val VIDEO_KEY = "video"
        const val AUDIO_KEY = "audio"
        const val GPUS_TEMP_KEY = "gpus_temp_key"
        const val INTERFACE_TRAFFIC_DATE_KEY = "interface_traffic_date_key"
        const val INTERFACE_TRAFFIC_SEND_LAN_KEY = "interface_traffic_send_lan_key"
        const val INTERFACE_TRAFFIC_RECEIVED_LAN_KEY = "interface_traffic_received_lan_key"
        const val INTERFACE_TRAFFIC_SEND_WIFI_KEY = "interface_traffic_send_wifi_key"
        const val INTERFACE_TRAFFIC_RECEIVED_WIFI_KEY = "interface_traffic_received_wifi_key"
        const val VIDEO_CHANNELS_COUNT_KEY = "video_channels_count_key"
        const val AUDIO_CHANNELS_COUNT_KEY = "audio_channels_count_key"
        const val REBOOT_HOUR_KEY = "reboot_hour_key"
        const val REBOOT_MINUTE_KEY = "reboot_minute_key"
        const val REBOOT_MERIDIEM_KEY = "reboot_meridiem_key"
        const val REBOOT_ENABLED_KEY = "reboot_enabled_key"
        const val PLAYBACK_RESTART_HOUR_KEY = "playback_restart_hour_key"
        const val PLAYBACK_RESTART_MINUTE_KEY = "playback_restart_minute_key"
        const val PLAYBACK_RESTART_MERIDIEM_KEY = "playback_restart_meridiem_key"
        const val PLAYBACK_RESTART_ENABLED_KEY = "playback_restart_enabled_key"
        const val SHUTDOWN_RESTART_HOUR_KEY = "shutdown_restart_hour_key"
        const val SHUTDOWN_RESTART_MINUTE_KEY = "shutdown_restart_minute_key"
        const val SHUTDOWN_RESTART_MERIDIEM_KEY = "shutdown_restart_meridiem_key"
        const val SHUTDOWN_RESTART_ENABLED_KEY = "shutdown_restart_enabled_key"
        const val SN_KEY = "sn_key"
        const val SID_KEY = "sid_key"
        const val ADDRESS_KEY = "address_key"
        const val SYS_TIME_KEY = "systime_key"
        const val PERIOD_KEY = "period_key"
        const val REGISTRATION_DATE_KEY = "registrationdate_key"
        const val CPUS_LOAD_KEY = "cpus_load_key"
        const val CPUS_TEMP_KEY = "cpus_temp_key"
        const val RAM_FREE_KEY = "ram_free_key"
        const val RAM_TOTAL_KEY = "ram_total_key"
        const val HDD_TOTAL_KEY = "hdd_total_key"
        const val DETAILS_LAST_TIMESTAMP_KEY = "details_last_timestamp_key"
        const val HDD_FREE_KEY = "hdd_free_key"
        const val MOTHERBOARD_KEY = "motherboard_key"
        const val INFO_KEY = "info"
        const val RAM_KEY = "ram"
    }

    override var params: MutableMap<String, Any> = HashMap()

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        var isSuccessful = false
        val result = response.result
        if((result != null) && result.isJsonObject)
        {
            val hardware = (response.result as JsonObject).get(HARDWARE_KEY)
            val summary = (response.result as JsonObject).get(SUMMARY_KEY)
            if((hardware != null) && (summary != null) && (hardware.isJsonObject) && (summary.isJsonObject))
            {
                val summaryValidKeys = arrayOf(MODEL_KEY, EDITION_KEY, TITLE_KEY, VERSION_KEY, SERIAL_NUMBER_KEY, SYS_ID_KEY, IP_KEY, SYSTEM_TIME_KEY, UPTIME_KEY, TIMEZONE_KEY, LOG_PERIOD_KEY, PROTOCOL_KEY, INFO_KEY, COMPANY_KEY, LOCATION_KEY, SCHEDULE_REBOOT_KEY)
                val hardwareValidKeys = arrayOf(MAC_ADDRESS_KEY, CPU_KEY, GPU_TEMPERATURE_KEY, RAM_KEY, HDD_KEY)
                if(hardwareValidKeys.all {hardware.asJsonObject.has(it)} && summaryValidKeys.all {summary.asJsonObject.has(it)})
                {
                    var isValidSummary = false
                    val info = summary.asJsonObject.get(INFO_KEY)
                    val scheduleReboot = summary.asJsonObject.get(SCHEDULE_REBOOT_KEY)
                    val company = summary.asJsonObject.get(COMPANY_KEY)
                    val location = summary.asJsonObject.get(LOCATION_KEY)

                    if((info != null) && (scheduleReboot != null) && (company != null) && (location != null) && info.isJsonObject && scheduleReboot.isJsonObject)
                    {
                        val infoValidKey = arrayOf(CHANNELS_KEY)
                        val scheduleRebootValidKeys = arrayOf(REBOOT_SCHEDULER_KEY, REBOOT_PLAYBACK_KEY, SHUTDOWN_APPLIANCE_KEY)
                        isValidSummary = infoValidKey.all {info.asJsonObject.has(it)} && scheduleRebootValidKeys.all {scheduleReboot.asJsonObject.has(it)}
                    }
                    val cpu = hardware.asJsonObject.get(CPU_KEY)
                    val ram = hardware.asJsonObject.get(RAM_KEY)
                    val hdd = hardware.asJsonObject.get(HDD_KEY)
                    val validKeys = arrayOf(TEMPERATURE_KEY, LOAD_KEY)
                    isSuccessful = isValidSummary && cpu != null && ram != null && hdd != null && cpu.isJsonObject && ram.isJsonObject && hdd.isJsonObject && validKeys.all {cpu.asJsonObject.has(it)}

                }
            }
        }
        return isSuccessful
    }

    override fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()
        val resultParams: MutableMap<String, Any?> = initResultParam()

        val result = response.result as JsonObject
        val hardware = result[HARDWARE_KEY] as? JsonObject
        val summary = result[SUMMARY_KEY] as? JsonObject

        if(summary != null)
        {
            val companyInfo = summary[COMPANY_KEY] as? JsonObject
            val locationInfo = summary[LOCATION_KEY] as? JsonObject
            if(locationInfo != null)
            {
                val locationPrimitive = locationInfo[TITLE_KEY] as? JsonPrimitive
                resultParams[LOCATION_KEY] = if(locationPrimitive != null) locationPrimitive.asString else ""
            }

            if(companyInfo != null)
            {
                val companyPrimitive = companyInfo[TITLE_KEY] as? JsonPrimitive
                resultParams[COMPANY_KEY] = if(companyPrimitive != null) companyPrimitive.asString else ""
            }

            fillSchedules(resultParams, summary)
            fillSummary(resultParams, summary)
            fillChannels(resultParams, summary)
        }

        if(hardware != null)
        {
            val macAddress = hardware[MAC_ADDRESS_KEY] as? JsonPrimitive
            val interfaceTraffic = hardware.get(INTERFACE_TRAFFIC_KEY) as? JsonObject
            resultParams[MAC_ADDRESS_KEY] = if(macAddress != null) macAddress.asString else ""

            fillRAM(resultParams, hardware)
            fillStorage(resultParams, hardware)
            fillCPU(resultParams, hardware.get(CPU_KEY))
            fillGPU(resultParams, hardware.get(GPU_TEMPERATURE_KEY))
            if(interfaceTraffic != null)
            {
                fillInterfaceProtocol(resultParams, interfaceTraffic)
            }
        }

        commandResult.params = resultParams
        return commandResult
    }

    private fun initResultParam(): MutableMap<String, Any?>
    {
        val resultParams: MutableMap<String, Any?> = HashMap()
        resultParams[VIDEO_CHANNELS_COUNT_KEY] = 0
        resultParams[AUDIO_CHANNELS_COUNT_KEY] = 0
        resultParams[LOCATION_KEY] = ""
        resultParams[COMPANY_KEY] = ""
        resultParams[MAC_ADDRESS_KEY] = ""
        resultParams[REBOOT_HOUR_KEY] = 0
        resultParams[REBOOT_MINUTE_KEY] = 0
        resultParams[REBOOT_MERIDIEM_KEY] = ""
        resultParams[REBOOT_ENABLED_KEY] = false
        resultParams[PLAYBACK_RESTART_HOUR_KEY] = 0
        resultParams[PLAYBACK_RESTART_MINUTE_KEY] = 0
        resultParams[PLAYBACK_RESTART_MERIDIEM_KEY] = ""
        resultParams[PLAYBACK_RESTART_ENABLED_KEY] = false
        resultParams[SHUTDOWN_RESTART_HOUR_KEY] = 0
        resultParams[SHUTDOWN_RESTART_MINUTE_KEY] = 0
        resultParams[SHUTDOWN_RESTART_ENABLED_KEY] = false
        resultParams[SHUTDOWN_RESTART_MERIDIEM_KEY] = ""
        resultParams[MODEL_KEY] = ""
        resultParams[EDITION_KEY] = ""
        resultParams[TITLE_KEY] = ""
        resultParams[VERSION_KEY] = ""
        resultParams[SN_KEY] = ""
        resultParams[SID_KEY] = ""
        resultParams[ADDRESS_KEY] = ""
        resultParams[SYS_TIME_KEY] = ""
        resultParams[UPTIME_KEY] = ""
        resultParams[TIMEZONE_KEY] = ""
        resultParams[PERIOD_KEY] = 0
        resultParams[PROTOCOL_KEY] = ""
        resultParams[REGISTRATION_DATE_KEY] = 0
        resultParams[GPUS_TEMP_KEY] = ArrayList<Double>()
        resultParams[CPUS_LOAD_KEY] = ArrayList<Double>()
        resultParams[CPUS_TEMP_KEY] = ArrayList<Double>()
        resultParams[RAM_FREE_KEY] = NO_HARDWARE_DATA
        resultParams[RAM_TOTAL_KEY] = NO_HARDWARE_DATA
        resultParams[MOTHERBOARD_KEY] = ""
        resultParams[HDD_TOTAL_KEY] = NO_HARDWARE_DATA
        resultParams[HDD_FREE_KEY] = NO_HARDWARE_DATA
        resultParams[DETAILS_LAST_TIMESTAMP_KEY] = 0
        resultParams[INTERFACE_TRAFFIC_DATE_KEY] = 0
        resultParams[INTERFACE_TRAFFIC_SEND_LAN_KEY] = 0
        resultParams[INTERFACE_TRAFFIC_RECEIVED_LAN_KEY] = 0
        resultParams[INTERFACE_TRAFFIC_SEND_WIFI_KEY] = 0
        resultParams[INTERFACE_TRAFFIC_RECEIVED_WIFI_KEY] = 0
        resultParams[DETAILS_LAST_TIMESTAMP_KEY] = System.currentTimeMillis()
        return resultParams
    }


    private fun fillSchedules(resultParams: MutableMap<String, Any?>, summary: JsonObject)
    {
        val scheduleReboot = summary[SCHEDULE_REBOOT_KEY] as? JsonObject
        if(scheduleReboot != null)
        {
            val scheduleRebootNode = scheduleReboot[REBOOT_SCHEDULER_KEY] as? JsonObject
            val scheduleRestartPlayback = scheduleReboot[REBOOT_PLAYBACK_KEY] as? JsonObject
            val scheduleShutdownNode = scheduleReboot[SHUTDOWN_APPLIANCE_KEY] as? JsonObject

            if(scheduleRebootNode != null)
            {
                val rebootHourPrimitive = scheduleRebootNode.get(HOUR_KEY) as? JsonPrimitive
                val rebootMinutePrimitive = scheduleRebootNode[MINUTE_KEY] as? JsonPrimitive
                val rebootMeridiemPrimitive = scheduleRebootNode.get(MERIDIEM_KEY) as? JsonPrimitive
                val rebootEnabledPrimitive = scheduleRebootNode.get(STATUS_KEY) as? JsonPrimitive

                resultParams[REBOOT_HOUR_KEY] = rebootHourPrimitive?.asInt ?: 0
                resultParams[REBOOT_MINUTE_KEY] = rebootMinutePrimitive?.asInt ?: 0
                resultParams[REBOOT_MERIDIEM_KEY] = if(rebootMeridiemPrimitive != null) rebootMeridiemPrimitive.asString else ""
                resultParams[REBOOT_ENABLED_KEY] = rebootEnabledPrimitive?.asInt ?: 0 > 0
            }
            if(scheduleRestartPlayback != null)
            {
                val playbackRestartHourPrimitive = scheduleRestartPlayback[HOUR_KEY] as? JsonPrimitive
                val playbackRestartMinutePrimitive = scheduleRestartPlayback[MINUTE_KEY] as? JsonPrimitive
                val playbackRestartMeridiemPrimitive = scheduleRestartPlayback.get(MERIDIEM_KEY) as? JsonPrimitive
                val playbackRestartEnabledPrimitive = scheduleRestartPlayback.get(STATUS_KEY) as? JsonPrimitive

                resultParams[PLAYBACK_RESTART_HOUR_KEY] = playbackRestartHourPrimitive?.asInt ?: 0
                resultParams[PLAYBACK_RESTART_MINUTE_KEY] = playbackRestartMinutePrimitive?.asInt ?: 0
                resultParams[PLAYBACK_RESTART_MERIDIEM_KEY] = if(playbackRestartMeridiemPrimitive != null) playbackRestartMeridiemPrimitive.asString else ""
                resultParams[PLAYBACK_RESTART_ENABLED_KEY] = playbackRestartEnabledPrimitive?.asInt ?: 0 > 0
            }
            if(scheduleShutdownNode != null)
            {
                val shutdownHourPrimitive = scheduleShutdownNode[HOUR_KEY] as? JsonPrimitive
                val shutdownMinutePrimitive = scheduleShutdownNode[MINUTE_KEY] as? JsonPrimitive
                val shutdownMeridiemPrimitive = scheduleShutdownNode.get(MERIDIEM_KEY) as? JsonPrimitive
                val shutdownEnabledPrimitive = scheduleShutdownNode.get(STATUS_KEY) as? JsonPrimitive

                resultParams[SHUTDOWN_RESTART_HOUR_KEY] = shutdownHourPrimitive?.asInt ?: 0
                resultParams[SHUTDOWN_RESTART_MINUTE_KEY] = shutdownMinutePrimitive?.asInt ?: 0
                resultParams[SHUTDOWN_RESTART_MERIDIEM_KEY] = if(shutdownMeridiemPrimitive != null) shutdownMeridiemPrimitive.asString else ""
                resultParams[SHUTDOWN_RESTART_ENABLED_KEY] = shutdownEnabledPrimitive?.asInt ?: 0 > 0
            }
        }
    }

    private fun fillSummary(resultParams: MutableMap<String, Any?>, summary: JsonObject)
    {
        val model = summary.get(MODEL_KEY) as? JsonPrimitive
        val edition = summary.get(EDITION_KEY) as? JsonPrimitive
        val title = summary.get(TITLE_KEY) as? JsonPrimitive

        val version = summary.get(VERSION_KEY) as? JsonPrimitive
        val sn = summary.get(SERIAL_NUMBER_KEY) as? JsonPrimitive
        val sid = summary.get(SYS_ID_KEY) as? JsonPrimitive
        val address = summary.get(IP_KEY) as? JsonPrimitive
        val sysTime = summary.get(SYSTEM_TIME_KEY) as? JsonPrimitive
        val upTime = summary.get(UPTIME_KEY) as? JsonPrimitive
        val timezone = summary.get(TIMEZONE_KEY) as? JsonPrimitive
        val period = summary.get(LOG_PERIOD_KEY) as? JsonPrimitive
        val protocol = summary.get(PROTOCOL_KEY) as? JsonPrimitive
        val registrationDate = summary.get(REGISTRATION_TIME_KEY) as? JsonPrimitive

        resultParams[MODEL_KEY] = if(model != null) model.asString else ""
        resultParams[EDITION_KEY] = if(edition != null) edition.asString else ""
        resultParams[TITLE_KEY] = if(title != null) title.asString else ""
        resultParams[VERSION_KEY] = if(version != null) version.asString else ""
        resultParams[SN_KEY] = if(sn != null) sn.asString else ""
        resultParams[SID_KEY] = if(sid != null) sid.asString else ""
        resultParams[ADDRESS_KEY] = if(address != null) address.asString else ""
        resultParams[SYS_TIME_KEY] = if(sysTime != null) sysTime.asString else ""
        resultParams[UPTIME_KEY] = if(upTime != null) upTime.asString else ""
        resultParams[TIMEZONE_KEY] = if(timezone != null) timezone.asString else ""
        resultParams[PERIOD_KEY] = period?.asInt ?: 0
        resultParams[PROTOCOL_KEY] = if(protocol != null) protocol.asString else ""
        resultParams[REGISTRATION_DATE_KEY] = registrationDate?.asInt ?: 0
    }

    private fun fillChannels(resultParams: MutableMap<String, Any?>, summary: JsonObject)
    {
        val info = summary.get(INFO_KEY) as? JsonObject
        if(info != null)
        {
            val channels = info.get(CHANNELS_KEY) as? JsonObject
            if(channels != null)
            {
                val videoChannelsCount = channels.get(VIDEO_KEY) as? JsonPrimitive
                val audioChannelsCount = channels.get(AUDIO_KEY) as? JsonPrimitive

                resultParams[VIDEO_CHANNELS_COUNT_KEY] = videoChannelsCount?.asInt ?: 0
                resultParams[AUDIO_CHANNELS_COUNT_KEY] = audioChannelsCount?.asInt ?: 0
            }
        }
    }

    private fun fillGPU(resultParams: MutableMap<String, Any?>, gpu: Any?)
    {
        val gpusTemp: MutableList<Double> = ArrayList()
        if(gpu is JsonArray)
        {
            for(item in gpu)
            {
                fillGPU(resultParams, item)
            }
        }
        else if(gpu is JsonPrimitive)
        {
            if(gpu.isString)
            {
                val tempArray = gpu.asString.split(" ".toRegex()).dropLastWhile {it.isEmpty()}.toTypedArray()
                if(tempArray.isNotEmpty())
                {
                    gpusTemp.add(java.lang.Double.valueOf(tempArray[0]))
                }
                else if(gpu.isNumber)
                {
                    gpusTemp.add(gpu.asDouble)
                }
            }
            resultParams[GPUS_TEMP_KEY] = gpusTemp
        }
    }

    private fun fillCPU(resultParams: MutableMap<String, Any?>, cpu: Any?)
    {
        val cpusLoad: MutableList<Double> = ArrayList()
        val cpusTemp: MutableList<Double> = ArrayList()

        if(cpu is JsonObject)
        {
            val loads = cpu[LOAD_KEY] as? JsonArray//todo koren check one core  (load != "N/A")
            val temps = cpu[TEMPERATURE_KEY] as? JsonArray//todo koren check one core  (load != "N/A")

            if(loads != null)
            {
                for(load in loads)
                {
                    cpusLoad.add(if(load != null && load.isJsonPrimitive && load.asJsonPrimitive.isNumber) load.asDouble else 0.0)
                }
            }

            if(temps != null)
            {
                for(temp in temps)
                {
                    cpusTemp.add(if(temp != null && temp.isJsonPrimitive && temp.asJsonPrimitive.isNumber) temp.asDouble else 0.0)
                }
            }
            resultParams[CPUS_LOAD_KEY] = cpusLoad
            resultParams[CPUS_TEMP_KEY] = cpusTemp
        }
        else if(cpu is JsonArray)
            for(item in cpu.asJsonArray) fillCPU(resultParams, item)//todo koren check
    }

    private fun fillRAM(resultParams: MutableMap<String, Any?>, hardware: JsonObject)
    {
        val ramInfo = hardware.get(RAM_KEY) as? JsonObject
        if(ramInfo != null)
        {
            val free = ramInfo.get(FREE_KEY) as? JsonPrimitive
            val total = ramInfo.get(TOTAL_KEY)as? JsonPrimitive
            if(free != null && free.isString && ramInfo.asString == "n/a")
            {
                resultParams[RAM_FREE_KEY] = NO_HARDWARE_DATA
            }
            else
            {
                resultParams[RAM_FREE_KEY] = if(free != null && free.isNumber) free.asDouble * 1024 else 0.0
            }

            if(total != null && total.isString && total.asString == "n/a")
            {
                resultParams[RAM_TOTAL_KEY] = NO_HARDWARE_DATA
            }
            else
            {
                resultParams[RAM_TOTAL_KEY] = if(total != null && total.isNumber) total.asDouble * 1024 else 0.0
            }

            val motherboard = ramInfo.get("motherboard") as? JsonPrimitive

            resultParams[MOTHERBOARD_KEY] = if(motherboard != null && motherboard.isString) motherboard.asString else ""
        }
    }

    private fun fillStorage(resultParams: MutableMap<String, Any?>, hardware: JsonObject)
    {
        val hddInfo = hardware.get(HDD_KEY) as? JsonObject
        if(hddInfo != null)
        {
            val hddTotal = hddInfo.get(TOTAL_KEY) as? JsonPrimitive
            val hddFree = hddInfo.get(FREE_KEY) as? JsonPrimitive

            if(hddTotal != null && hddTotal.isString && hddTotal.asString == "n/a")
            {
                resultParams[HDD_TOTAL_KEY] = NO_HARDWARE_DATA
            }
            else
            {
                resultParams[HDD_TOTAL_KEY] = if(hddTotal != null && hddTotal.isNumber) hddTotal.asDouble else 0.0
            }

            if(hddFree != null && hddFree.isString && hddFree.asString == "n/a")
            {
                resultParams[HDD_FREE_KEY] = NO_HARDWARE_DATA
            }
            else
            {
                resultParams[HDD_FREE_KEY] = if(hddFree != null && hddFree.isNumber) hddFree.asDouble else 0.0
            }
        }
    }

    private fun fillInterfaceProtocol(resultParams: MutableMap<String, Any?>, protocol: JsonObject)
    {
        val interfaceTrafficDate = protocol[DATE_KEY] as? JsonPrimitive
        val interfaceTrafficSendLAN = protocol[SEND_LAN_KEY] as? JsonPrimitive
        val interfaceTrafficReceivedLAN = protocol[RECEIVED_LAN_KEY] as? JsonPrimitive
        val interfaceTrafficSendWiFi = protocol[SEND_WIFI_KEY] as? JsonPrimitive
        val interfaceTrafficReceivedWiFi = protocol[RECEIVED_WIFI_KEY] as? JsonPrimitive

        resultParams[INTERFACE_TRAFFIC_DATE_KEY] = if(interfaceTrafficDate != null && interfaceTrafficDate.isNumber) interfaceTrafficDate.asInt else 0
        resultParams[INTERFACE_TRAFFIC_SEND_LAN_KEY] = if(interfaceTrafficSendLAN != null && interfaceTrafficSendLAN.isNumber) interfaceTrafficSendLAN.asInt else 0
        resultParams[INTERFACE_TRAFFIC_RECEIVED_LAN_KEY] = if(interfaceTrafficReceivedLAN != null && interfaceTrafficReceivedLAN.isNumber) interfaceTrafficReceivedLAN.asInt else 0
        resultParams[INTERFACE_TRAFFIC_SEND_WIFI_KEY] = if(interfaceTrafficSendWiFi != null && interfaceTrafficSendWiFi.isNumber) interfaceTrafficSendWiFi.asInt else 0
        resultParams[INTERFACE_TRAFFIC_RECEIVED_WIFI_KEY] = if(interfaceTrafficReceivedWiFi != null && interfaceTrafficReceivedWiFi.isNumber) interfaceTrafficReceivedWiFi.asInt else 0
    }
}
