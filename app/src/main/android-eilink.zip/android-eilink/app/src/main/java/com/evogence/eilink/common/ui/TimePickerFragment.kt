package com.evogence.eilink.common.ui

import android.app.Activity
import android.app.Dialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.support.v7.app.AlertDialog
import android.view.LayoutInflater
import android.widget.TimePicker
import com.evogence.eilink.R

/**
 * Created by Koren Vitalii on 8/8/2018.
 */
class TimePickerFragment: DialogFragment()
{
    lateinit var timePicker: TimePicker

    companion object
    {
        const val HOUR_KEY = "arg_hour"
        const val MINUTE_KEY = "arg_minute"

        @JvmStatic
        fun newInstance(hour: Int, minute: Int): TimePickerFragment
        {
            val args = Bundle()
            args.putSerializable(HOUR_KEY, hour)
            args.putSerializable(MINUTE_KEY, minute)

            val fragment = TimePickerFragment()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        val v = LayoutInflater.from(activity).inflate(R.layout.dialog_time,null)

        timePicker = v.findViewById(R.id.dialog_time_picker) as TimePicker
        timePicker.currentHour = arguments?.getInt(HOUR_KEY) ?: 0
        timePicker.currentMinute = arguments?.getInt(MINUTE_KEY) ?: 0

        return AlertDialog.Builder(activity!!)
            .setView(v)
            .setTitle(R.string.time_picker_title)
            .setPositiveButton(android.R.string.ok) {_: DialogInterface, _: Int->
                val intent = Intent()
                intent.putExtra(HOUR_KEY, timePicker.currentHour)
                intent.putExtra(MINUTE_KEY, timePicker.currentMinute)
                sendResult(Activity.RESULT_OK, intent)
            }
            .create()
    }

    private fun sendResult(resultCode: Int, data: Intent)
    {
        if(targetFragment == null)
            return

        targetFragment!!.onActivityResult(targetRequestCode, resultCode, data)
    }
}