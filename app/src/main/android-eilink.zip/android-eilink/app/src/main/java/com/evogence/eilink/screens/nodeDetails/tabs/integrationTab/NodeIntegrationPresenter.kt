package com.evogence.eilink.screens.nodeDetails.tabs.integrationTab

import com.evogence.eilink.common.BlockRunnable
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.controllers.nodeCommandSender.ENodeCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetManagementServer
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetRMServerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetUpdateServerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetManagementServer
import com.evogence.eilink.screens.nodeDetails.tabs.INodeDetailsTabView
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabPresenter
import java.util.*

/**
 * Created by Koren Vitalii on 9/6/2018.
 */
open class NodeIntegrationPresenter(fingerprint: String?): NodeDetailsTabPresenter<NodeIntegrationVM>(fingerprint), INodeIntegrationPresenter
{
    override var viewModel = NodeIntegrationVM()

    private lateinit var commandsGetList: MutableList<()->Unit>
    private lateinit var commandsSaveList: MutableList<()->Unit>

    override fun attachView(view: INodeDetailsTabView<NodeIntegrationVM>)
    {
        this.view = view
        prepareViewModel()
        commandsGetList = mutableListOf({sendCommandGetManagementServer()}, {sendCommandGetRmServer()}, {sendCommandGetUpdateServer()})
        commandsSaveList = mutableListOf({saveManagementServer()}, {saveSupportServer()}, {saveUpdateServer()})
        view.fill(viewModel)
        view.showProgress("Processing")
        sendQueueGetCommand()
    }

    override fun detachView()
    {
        commandsGetList = mutableListOf()
        commandsSaveList = mutableListOf()
        super.detachView()
    }

    override fun prepareViewModel()
    {
        val nodeIntegrationInfo = node.centralServer
        viewModel.enableManagementServer = nodeIntegrationInfo.esEnable
        viewModel.useServerToGetUpdates = nodeIntegrationInfo.useEsAsUpdateServer
        viewModel.useSftp = nodeIntegrationInfo.useSFTP
        viewModel.esTaskCompletionTimeout = String.format("%d", nodeIntegrationInfo.esTaskCompletionTimeout.toLong())
        viewModel.serverIpAddressOrDomain = nodeIntegrationInfo.host
        viewModel.httpPort = nodeIntegrationInfo.httpPort
        viewModel.sshPort = nodeIntegrationInfo.sshPort
        viewModel.ftpPort = nodeIntegrationInfo.ftpPort
        viewModel.registrationToken = nodeIntegrationInfo.registrationToken
        viewModel.enableManagementServer = nodeIntegrationInfo.esEnable
        viewModel.secondaryServerIpAddressOrDomain = nodeIntegrationInfo.secondaryHost
        viewModel.secondaryHttpPort = nodeIntegrationInfo.secondaryHTTPPort
        viewModel.secondarySshPort = nodeIntegrationInfo.secondarySSHPort
        viewModel.secondaryFtpPort = nodeIntegrationInfo.secondaryFTPPort

        val supportServer = node.supportServer
        viewModel.useTunnelReverseMonitoringServer = supportServer.isUseTunnel
        viewModel.tunnelAddressReverseMonitoringServer = supportServer.tunnelAddress

        val updateServer = node.updateServer
        viewModel.isEnableUpdateServer = updateServer.isEnable
        viewModel.addressUpdateServer = updateServer.host

        viewModelBeforeChanges = viewModel.copy()
    }

    override fun saveChanges()
    {
        sendCommandSaveQueue()
    }

    override fun checkConnectionManagementServer()
    {
        view?.showProgress("Processing")
        view?.retrieveChanges(viewModel)

        commandSender.send(ENodeCommand.CHECK_CONNECTION_MANAGEMENT_SERVER, node, viewModel.serverIpAddressOrDomain, BlockRunnable {commandResult: CommandResult->
            if(commandResult.error != null)
                prepareResultMessageManagementServer(commandResult.error, true)
            else
                prepareResultMessageManagementServer("The verification process completed successfully.", false)
            view?.fill(viewModel)
            view?.hideProgress()
        })
    }

    override fun checkConnectionReverseMonitoringServer()
    {
        view?.showProgress("Processing")
        view?.retrieveChanges(viewModel)

        commandSender.send(ENodeCommand.CHECK_CONNECTION_RM_SERVER, node, viewModel.tunnelAddressReverseMonitoringServer, BlockRunnable {commandResult: CommandResult->
            if(commandResult.error != null)
                prepareResultMessageSupportServer(commandResult.error, true)
            else
                prepareResultMessageSupportServer("The verification process completed successfully.", false)
            view?.fill(viewModel)
            view?.hideProgress()
        })
    }

    override fun checkConnectionUpdateServer()
    {
        view?.showProgress("Processing")
        view?.retrieveChanges(viewModel)

        if(!isFillDataUpdateServer)
        {
            prepareResultMessageUpdateServer("Please, fill server IP address or domain", true)
            view?.fill(viewModel)
            view?.hideProgress()
        }
        else
        {
            commandSender.send(ENodeCommand.CHECK_CONNECTION_UPDATE_SERVER, node, viewModel.addressUpdateServer, BlockRunnable {commandResult: CommandResult->
                view?.hideProgress()
                if(commandResult.error == null)
                    prepareResultMessageUpdateServer("The verification process completed successfully.", false)
                else
                    prepareResultMessageUpdateServer(commandResult.error, true)
                view?.fill(viewModel)
                view?.hideProgress()
            })
        }
    }

    fun saveManagementServer()
    {
        if(!validateChangesManagementServer())
        {
            sendCommandSaveQueue()
            return
        }

        commandSender.send(ENodeCommand.SET_MANAGEMENT_SERVER, node, prepareParametersManagementServer(), BlockRunnable {commandResult: CommandResult-> processingSaveManagementServer(commandResult)})
    }

    fun refreshNodeManagementServer()
    {
        val nodeIntegrationInfo = node.centralServer

        nodeIntegrationInfo.registrationToken = viewModel.registrationToken
        nodeIntegrationInfo.esTaskCompletionTimeout = viewModel.esTaskCompletionTimeout.toDouble()
        nodeIntegrationInfo.esEnable = viewModel.enableManagementServer
        nodeIntegrationInfo.useEsAsUpdateServer = viewModel.useServerToGetUpdates
        nodeIntegrationInfo.useSFTP = viewModel.useSftp

        nodeIntegrationInfo.host = viewModel.serverIpAddressOrDomain
        nodeIntegrationInfo.httpPort = viewModel.httpPort
        nodeIntegrationInfo.sshPort = viewModel.sshPort
        nodeIntegrationInfo.ftpPort = viewModel.ftpPort

        nodeIntegrationInfo.secondaryHost = viewModel.secondaryServerIpAddressOrDomain
        nodeIntegrationInfo.secondaryHTTPPort = viewModel.secondaryHttpPort
        nodeIntegrationInfo.secondarySSHPort = viewModel.secondarySshPort
        nodeIntegrationInfo.secondaryFTPPort = viewModel.secondaryFtpPort
    }

    protected open fun processingSaveManagementServer(commandResult: CommandResult)
    {
        if(commandResult.error == null)
        {
            viewModelBeforeChanges = viewModel.copy()
            refreshNodeManagementServer()
            prepareResultMessageManagementServer("Saving successful.", false)
        }
        else
            prepareResultMessageManagementServer(commandResult.error, true)

        view?.fill(viewModel)
        sendCommandSaveQueue()
    }

    protected fun saveSupportServer()
    {
        if(!validateChangesSupportServer())
        {
            sendCommandSaveQueue()
            return
        }

        val parameters = HashMap<String, Any>()
        parameters[GetRMServerCommand.TUNNEL_ADDRESS_KEY] = viewModel.tunnelAddressReverseMonitoringServer
        parameters[GetRMServerCommand.TUNNEL_ENABLED_KEY] = if(viewModel.useTunnelReverseMonitoringServer) 1 else 0

        commandSender.send(ENodeCommand.SET_RM_SERVER, node, parameters, BlockRunnable {commandResult: CommandResult-> processingSaveSupportServer(commandResult)})
    }

    protected open fun processingSaveSupportServer(commandResult: CommandResult)
    {
        if(commandResult.error == null)
        {
            viewModelBeforeChanges = viewModel.copy()
            prepareResultMessageSupportServer("Saving successful.", false)
            refreshSupportServer()
        }
        else
            prepareResultMessageSupportServer(commandResult.error, true)

        view?.fill(viewModel)
        sendCommandSaveQueue()
    }

    protected fun saveUpdateServer()
    {
        if(!validateChangesUpdateServer())
        {
            sendCommandSaveQueue()
            return
        }

        val parameters = HashMap<String, Any>()
        parameters[GetUpdateServerCommand.STATUS_KEY] = if(viewModel.isEnableUpdateServer) 1 else 0
        parameters[GetUpdateServerCommand.HOST_KEY] = viewModel.addressUpdateServer

        commandSender.send(ENodeCommand.SET_UPDATE_SERVER, node, parameters, BlockRunnable {commandResult: CommandResult-> processingSaveUpdateServer(commandResult)})
    }

    protected open fun processingSaveUpdateServer(commandResult: CommandResult)
    {
        if(commandResult.error == null)
        {
            viewModelBeforeChanges = viewModel.copy()
            refreshUpdateServer()
            prepareResultMessageUpdateServer("Saving successful.", false)
        }
        else
            prepareResultMessageUpdateServer(commandResult.error, true)
        view?.fill(viewModel)

        sendCommandSaveQueue()
    }

    protected fun refreshSupportServer()
    {
        val reverseMonitoring = node.supportServer
        reverseMonitoring.isUseTunnel = viewModel.useTunnelReverseMonitoringServer
        reverseMonitoring.tunnelAddress = viewModel.tunnelAddressReverseMonitoringServer
    }

    protected fun refreshUpdateServer()
    {
        node.updateServer.isEnable = viewModel.isEnableUpdateServer
        node.updateServer.host = viewModel.addressUpdateServer
    }

    private fun prepareParametersManagementServer(): HashMap<String, Any>
    {
        val primaryES = HashMap<String, Any>()
        primaryES[SetManagementServer.HOST_KEY] = viewModel.serverIpAddressOrDomain
        primaryES[SetManagementServer.HTTP_PORT_KEY] = viewModel.httpPort
        primaryES[SetManagementServer.SSH_PORT_KEY] = viewModel.sshPort
        primaryES[SetManagementServer.FTP_PORT_KEY] = viewModel.ftpPort

        val secondaryES = HashMap<String, Any>()
        secondaryES[SetManagementServer.HOST_KEY] = viewModel.secondaryServerIpAddressOrDomain
        secondaryES[SetManagementServer.HTTP_PORT_KEY] = viewModel.secondaryHttpPort
        secondaryES[SetManagementServer.SSH_PORT_KEY] = viewModel.secondarySshPort
        secondaryES[SetManagementServer.FTP_PORT_KEY] = viewModel.secondaryFtpPort

        val parameters = HashMap<String, Any>()
        parameters[SetManagementServer.IS_ES_ENABLE_KEY] = if(viewModel.enableManagementServer) 1 else 0
        parameters[SetManagementServer.USE_ES_AS_UPDATE_SERVER_KEY] = if(viewModel.useServerToGetUpdates) 1 else 0
        parameters[SetManagementServer.USE_ES_SSH_CONNECTION_KEY] = if(viewModel.useSftp) 1 else 0

        if(viewModel.esTaskCompletionTimeout.isEmpty())
            viewModel.esTaskCompletionTimeout = "180"
        else if(Integer.parseInt(viewModel.esTaskCompletionTimeout) < 60)
            viewModel.esTaskCompletionTimeout = "60"

        parameters[SetManagementServer.TASK_TIMEOUT_KEY] = viewModel.esTaskCompletionTimeout
        parameters[SetManagementServer.REGISTER_TOKEN_KEY] = viewModel.registrationToken
        parameters[SetManagementServer.PRIMARY_ES_KEY] = primaryES
        parameters[SetManagementServer.SECONDARY_ES_KEY] = secondaryES

        return parameters
    }

    private fun refreshNodeManagementServer(commandResult: CommandResult)
    {
        if(commandResult.params == null)
            return

        val nodeIntegrationInfo = node.centralServer
        val params = commandResult.params

        nodeIntegrationInfo.registrationToken = params[GetManagementServer.REGISTER_TOKEN_KEY] as? String ?: ""
        nodeIntegrationInfo.esTaskCompletionTimeout = params[GetManagementServer.TASK_TIMEOUT_KEY] as? Double ?: 0.0
        nodeIntegrationInfo.esEnable = params[GetManagementServer.IS_ES_ENABLE_KEY] as? Double ?: 0.0 == 1.0
        nodeIntegrationInfo.useEsAsUpdateServer = params[GetManagementServer.USE_ES_AS_UPDATE_SERVER_KEY] as? Double ?: 0.0 == 1.0
        nodeIntegrationInfo.useSFTP = params[GetManagementServer.USE_ES_SSH_CONNECTION_KEY] as? Double ?: 0.0 == 1.0
        val primaryES = params[GetManagementServer.PRIMARY_ES_KEY] as? Map<*, *>
        if(primaryES != null)
        {
            nodeIntegrationInfo.host = if(primaryES[GetManagementServer.HOST_KEY] is Boolean) "" else primaryES[GetManagementServer.HOST_KEY] as? String ?: ""
            nodeIntegrationInfo.httpPort = primaryES[GetManagementServer.HTTP_PORT_KEY] as? String ?: ""
            nodeIntegrationInfo.sshPort = primaryES[GetManagementServer.SSH_PORT_KEY] as? String ?: ""
            nodeIntegrationInfo.ftpPort = primaryES[GetManagementServer.FTP_PORT_KEY] as? String ?: ""
        }
        val secondaryES = params[GetManagementServer.SECONDARY_ES_KEY] as? Map<*, *>
        if(secondaryES != null)
        {
            nodeIntegrationInfo.secondaryHost = if(secondaryES[GetManagementServer.HOST_KEY] is Boolean) "" else secondaryES[GetManagementServer.HOST_KEY] as? String ?: ""
            nodeIntegrationInfo.secondaryHTTPPort = secondaryES[GetManagementServer.HTTP_PORT_KEY] as? String ?: ""
            nodeIntegrationInfo.secondarySSHPort = secondaryES[GetManagementServer.SSH_PORT_KEY] as? String ?: ""
            nodeIntegrationInfo.secondaryFTPPort = secondaryES[GetManagementServer.FTP_PORT_KEY] as? String ?: ""
        }

        nodeIntegrationInfo.updateTimestamp = System.currentTimeMillis()
    }

    private fun refreshSupportServer(commandResult: CommandResult)
    {
        val reverseMonitoring = node.supportServer
        reverseMonitoring.isUseTunnel = commandResult.params[GetRMServerCommand.TUNNEL_ENABLED_KEY] as? Boolean ?: false
        reverseMonitoring.tunnelAddress = commandResult.params[GetRMServerCommand.TUNNEL_ADDRESS_KEY] as? String ?: ""
        reverseMonitoring.updateTimestamp = System.currentTimeMillis()
    }

    open fun sendCommandSaveQueue()
    {
        if(commandsSaveList.isNotEmpty())
        {
            val command = commandsSaveList[0]
            commandsSaveList.removeAt(0)
            command.invoke()
        }
        else
        {
            commandsSaveList = mutableListOf({saveManagementServer()}, {saveSupportServer()}, {saveUpdateServer()})
            view?.hideProgress()
            viewModelBeforeChanges = viewModel.copy()
            view?.enableSaveButton(false)
            view?.fill(viewModel)
        }
    }

    private fun refreshUpdateServer(commandResult: CommandResult)
    {
        node.updateServer.isEnable = commandResult.params[GetUpdateServerCommand.STATUS_KEY] as? Boolean ?: false
        node.updateServer.host = commandResult.params[GetUpdateServerCommand.HOST_KEY] as? String ?: ""
        node.updateServer.updateTimestamp = System.currentTimeMillis()
    }

    private fun prepareResultMessageManagementServer(message: String, error: Boolean)
    {
        viewModel.resultMessageManagementServer = message
        viewModel.resultMessageManagementServerError = error
    }

    private fun prepareResultMessageSupportServer(message: String, error: Boolean)
    {
        viewModel.resultMessageReverseMonitoringServer = message
        viewModel.resultMessageReverseMonitoringServerError = error
    }

    private fun prepareResultMessageUpdateServer(message: String, error: Boolean)
    {
        viewModel.resultMessageUpdateServer = message
        viewModel.resultMessageUpdateServerError = error
    }

    private fun validateChangesManagementServer(): Boolean
    {
        if(!isFillDataManagementServer)
            prepareResultMessageManagementServer("Please enter a valid Server IP Address or Domain", true)
        return isFillDataManagementServer
    }

    private fun validateChangesSupportServer(): Boolean
    {
        if(!isFillDataSupportServer)
            prepareResultMessageSupportServer("Please enter a valid Server IP Address or Domain", true)
        return isFillDataSupportServer
    }

    private fun validateChangesUpdateServer(): Boolean
    {
        if(!isFillDataUpdateServer)
            prepareResultMessageUpdateServer("Please enter a valid Server IP Address or Domain", true)
        return isFillDataUpdateServer
    }

    private fun sendQueueGetCommand()
    {
        if(commandsGetList.isNotEmpty())
        {
            val command = commandsGetList[0]
            commandsGetList.removeAt(0)
            command.invoke()
        }
        else
        {
            commandsGetList = mutableListOf({sendCommandGetManagementServer()}, {sendCommandGetRmServer()}, {sendCommandGetUpdateServer()})
            view?.hideProgress()
        }
    }

    private fun sendCommandGetManagementServer()
    {
        if(!isFillDataManagementServer || isNotUpdateMoreTimeManagementServer)
        {
            commandSender.send(ENodeCommand.GET_MANAGEMENT_SERVER, node, null, BlockRunnable {commandResult: CommandResult->
                if(commandResult.error == null)
                {
                    refreshNodeManagementServer(commandResult)
                    prepareViewModel()
                    prepareResultMessageManagementServer("", false)
                }
                else
                    prepareResultMessageManagementServer(commandResult.error, true)

                view?.fill(viewModel)
                sendQueueGetCommand()
            })
        }
        else
            sendQueueGetCommand()
    }

    private fun sendCommandGetRmServer()
    {
        if(!isFillDataSupportServer || isNotUpdateMoreTimeSupportServer)
        {
            commandSender.send(ENodeCommand.GET_RM_SERVER, node, null, BlockRunnable {commandResult: CommandResult->
                if(commandResult.error == null)
                {
                    refreshSupportServer(commandResult)
                    prepareViewModel()
                    prepareResultMessageSupportServer("", false)
                }
                else
                    prepareResultMessageSupportServer(commandResult.error, true)

                view?.fill(viewModel)
                sendQueueGetCommand()
            })
        }
        else
            sendQueueGetCommand()
    }

    private fun sendCommandGetUpdateServer()
    {
        if(isNotUpdateMoreTimeUpdateServer)
        {
            commandSender.send(ENodeCommand.GET_UPDATE_SERVER, node, null, BlockRunnable {commandResult: CommandResult->
                if(commandResult.error == null)
                {
                    refreshUpdateServer(commandResult)
                    prepareViewModel()
                    prepareResultMessageUpdateServer("", false)
                }
                else
                    prepareResultMessageUpdateServer(commandResult.error, true)
                view?.fill(viewModel)
                sendQueueGetCommand()
            })
        }
        else
            sendQueueGetCommand()
    }

    private val isFillDataManagementServer: Boolean
        get() = (viewModel.enableManagementServer && !viewModel.serverIpAddressOrDomain.isEmpty()) || !viewModel.enableManagementServer

    private val isNotUpdateMoreTimeManagementServer: Boolean
        get() = System.currentTimeMillis() - node.centralServer.updateTimestamp > ONE_MINUTE

    private val isFillDataSupportServer: Boolean
        get() = (viewModel.useTunnelReverseMonitoringServer && !viewModel.tunnelAddressReverseMonitoringServer.isEmpty()) || !viewModel.useTunnelReverseMonitoringServer

    private val isNotUpdateMoreTimeSupportServer: Boolean
        get() = System.currentTimeMillis() - node.supportServer.updateTimestamp > ONE_MINUTE

    private val isFillDataUpdateServer: Boolean
        get() = (viewModel.isEnableUpdateServer && !viewModel.addressUpdateServer.isEmpty()) || !viewModel.isEnableUpdateServer

    private val isNotUpdateMoreTimeUpdateServer: Boolean
        get() = (System.currentTimeMillis() - node.updateServer.updateTimestamp) > ONE_MINUTE
}