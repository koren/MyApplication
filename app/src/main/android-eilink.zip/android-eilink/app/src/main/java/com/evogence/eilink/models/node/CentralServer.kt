package com.evogence.eilink.models.node

import com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater.EConnectionStatus

/**
 * Created by Koren Vitalii on 07/27/18.
 */
class CentralServer
{
    var host: String = ""
    var httpPort: String = ""
    var sshPort: String = ""
    var ftpPort: String = ""
    var registrationToken: String = ""
    var esTaskCompletionTimeout: Double = 0.0
    var esEnable: Boolean = false
    var useEsAsUpdateServer: Boolean = false
    var useSFTP: Boolean = false
    var secondaryHost: String = ""
    var secondaryHTTPPort: String = ""
    var secondarySSHPort: String = ""
    var secondaryFTPPort: String = ""
    var useSsh: Boolean = false
    var updateTimestamp: Long = 0

    var connectedStatus = EConnectionStatus.UNDEFINED_STATUS

}