package com.evogence.eilink.screens.nodeList

/**
 * Created by Koren Vitalii on 05/21/18.
 */
class NodeListItemVM
{
    var fingerprint: String = ""
    var title: String = ""
    var systemId: String = ""
    var serialNumber: String = ""
    var sId: String = ""
    var version: String = ""
    var edition: String = ""
    var model: String = ""
    var companyUnique: String = ""
    var timezone: String = ""
    var isSelected: Boolean = false
    var isUserInteractionEnabled: Boolean = false
    var iconName: String = ""
    var menuOpened: Boolean = false

    override fun equals(other: Any?): Boolean
    {
        var equal = true
        if(other !is NodeListItemVM)
            equal = false

        val item = other as NodeListItemVM?

        if(item?.fingerprint != fingerprint)
            equal = false

        return equal
    }

    override fun hashCode(): Int
    {
        var result = fingerprint.hashCode()
        result = 31 * result + title.hashCode()
        result = 31 * result + systemId.hashCode()
        result = 31 * result + serialNumber.hashCode()
        result = 31 * result + sId.hashCode()
        result = 31 * result + version.hashCode()
        result = 31 * result + edition.hashCode()
        result = 31 * result + model.hashCode()
        result = 31 * result + companyUnique.hashCode()
        result = 31 * result + timezone.hashCode()
        result = 31 * result + isSelected.hashCode()
        result = 31 * result + isUserInteractionEnabled.hashCode()
        result = 31 * result + iconName.hashCode()
        result = 31 * result + menuOpened.hashCode()
        return result
    }
}
