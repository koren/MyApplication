package com.evogence.eilink.models.node

import java.util.*

/**
 * Created by Koren Vitalii on 05/21/18.
 */
class Node
{
    companion object
    {
        internal const val IOS_ICON_NAME = "icon_model_ios_big"
        internal const val ANDROID_ICON_NAME = "icon_model_android_big"
    }

    val noHardwareData: Double = -1.0

    private var md5: String = ""
    var fingerprint: String = ""
    var title: String = ""
    private var token: String = ""
    private var vendor: String = ""
    var host: String = ""
    var address: String = ""
    var port: Int? = 0
    private val domain: String = ""
    val centralServer = CentralServer()
    var updateServer = UpdateServer()
    var supportServer = SupportServer()
    var networkSettings = NodeNetworkSettings()
    var status: ENodeStatus? = null
    var syncStatus: NodeSyncStatus? = null

    /// Description
    var model: String = ""
    var version: String = ""
    var edition: String = ""
    var sn: String = ""
    var sid: String = ""

    // Summary
    var location: String = ""
    var company: String = ""
    private val platform: String = ""
    private val protocolVersion: String = ""
    var serial: String = ""
    var timezone: String = ""
    var upTime: String = ""
    var sysTime: String = ""
    var period: Int? = null
    var videoChannelsCount: Int = 0
    var audioChannelsCount: Int = 0
    var registrationDate: Int = 0

    // node_details_hardware
    val cpusLoad: MutableList<Double> = ArrayList()
    val cpusTemp: MutableList<Double> = ArrayList()
    val gpusTemp: MutableList<Double> = ArrayList()
    var macAddress: String = ""
    var motherboard: String = ""
    private val hddSN: String = ""
    var ramTotal: Double = 0.0
    var ramFree: Double = 0.0
    private val hddUsed: Int? = 0
    private val hddAvailable: Int? = 0
    var interfaceTrafficDate: Int? = 0
    var interfaceTrafficSendLAN: Int? = 0
    var interfaceTrafficReceivedLAN: Int? = 0
    var interfaceTrafficSendWiFi: Int? = 0
    var interfaceTrafficReceivedWiFi: Int? = 0

    // Scheduler
    var rebootHour: Int = 0
    var rebootMinute: Int = 0
    var rebootEnabled: Boolean = false
    var playbackRestartHour: Int = 0
    var playbackRestartMinute: Int = 0
    var playbackRestartEnabled: Boolean = false
    var shutdownHour: Int = 0
    var shutdownMinute: Int = 0
    var shutdownEnabled: Boolean = false

    /// For details info command
    var updateTimestamp: Long = 0
    var rebootMeridiem: String = ""
    var playbackRestartMeridiem: String = ""
    var shutdownMeridiem: String = ""
    var protocol: String = ""
    var hddTotal: Double = 0.0
    var hddFree: Double = 0.0

    override fun equals(other: Any?): Boolean
    {
        if(other !is Node) return false
        val node = other as? Node?

        return !((node != null) && (node.fingerprint != fingerprint))
    }

    fun getIconName(): String
    {
        val androidModels = Arrays.asList("asme_android", "asme_appliance_android", "asme_tablet_android", "asme_aio_android")
        val appleModels = Arrays.asList("iPad", "iOS")
        var iconName = findModel(androidModels, ANDROID_ICON_NAME, model.toLowerCase())
        if(iconName == null)
            iconName = findModel(appleModels, IOS_ICON_NAME, model.toLowerCase())

        if((iconName == null) && model.isNotEmpty())
            iconName = String.format("icon_model_%s_big", model.toLowerCase())

        if(iconName == null)
            iconName = "icon_model_unknown"

        return iconName
    }

    private fun findModel(models: List<String>, imageName: String, modelName: String): String?
    {
        var fileName: String? = null
        for(name in models)
        {
            if(modelName.contains(name))
                fileName = imageName
        }
        return fileName
    }

    override fun hashCode(): Int
    {
        var result = noHardwareData.hashCode()
        result = 31 * result + md5.hashCode()
        result = 31 * result + fingerprint.hashCode()
        result = 31 * result + title.hashCode()
        result = 31 * result + token.hashCode()
        result = 31 * result + vendor.hashCode()
        result = 31 * result + host.hashCode()
        result = 31 * result + address.hashCode()
        result = 31 * result + (port ?: 0)
        result = 31 * result + domain.hashCode()
        result = 31 * result + centralServer.hashCode()
        result = 31 * result + updateServer.hashCode()
        result = 31 * result + supportServer.hashCode()
        result = 31 * result + networkSettings.hashCode()
        result = 31 * result + (status?.hashCode() ?: 0)
        result = 31 * result + (syncStatus?.hashCode() ?: 0)
        result = 31 * result + model.hashCode()
        result = 31 * result + version.hashCode()
        result = 31 * result + edition.hashCode()
        result = 31 * result + sn.hashCode()
        result = 31 * result + sid.hashCode()
        result = 31 * result + location.hashCode()
        result = 31 * result + company.hashCode()
        result = 31 * result + platform.hashCode()
        result = 31 * result + protocolVersion.hashCode()
        result = 31 * result + serial.hashCode()
        result = 31 * result + timezone.hashCode()
        result = 31 * result + upTime.hashCode()
        result = 31 * result + sysTime.hashCode()
        result = 31 * result + (period ?: 0)
        result = 31 * result + videoChannelsCount
        result = 31 * result + audioChannelsCount
        result = 31 * result + registrationDate
        result = 31 * result + cpusLoad.hashCode()
        result = 31 * result + cpusTemp.hashCode()
        result = 31 * result + gpusTemp.hashCode()
        result = 31 * result + macAddress.hashCode()
        result = 31 * result + motherboard.hashCode()
        result = 31 * result + hddSN.hashCode()
        result = 31 * result + ramTotal.hashCode()
        result = 31 * result + ramFree.hashCode()
        result = 31 * result + (hddUsed ?: 0)
        result = 31 * result + (hddAvailable ?: 0)
        result = 31 * result + (interfaceTrafficDate ?: 0)
        result = 31 * result + (interfaceTrafficSendLAN ?: 0)
        result = 31 * result + (interfaceTrafficReceivedLAN ?: 0)
        result = 31 * result + (interfaceTrafficSendWiFi ?: 0)
        result = 31 * result + (interfaceTrafficReceivedWiFi ?: 0)
        result = 31 * result + rebootHour.hashCode()
        result = 31 * result + rebootMinute.hashCode()
        result = 31 * result + rebootEnabled.hashCode()
        result = 31 * result + playbackRestartHour.hashCode()
        result = 31 * result + playbackRestartMinute.hashCode()
        result = 31 * result + playbackRestartEnabled.hashCode()
        result = 31 * result + shutdownHour.hashCode()
        result = 31 * result + shutdownMinute.hashCode()
        result = 31 * result + shutdownEnabled.hashCode()
        result = 31 * result + updateTimestamp.hashCode()
        result = 31 * result + rebootMeridiem.hashCode()
        result = 31 * result + playbackRestartMeridiem.hashCode()
        result = 31 * result + shutdownMeridiem.hashCode()
        result = 31 * result + protocol.hashCode()
        result = 31 * result + hddTotal.hashCode()
        result = 31 * result + hddFree.hashCode()
        return result
    }

}
