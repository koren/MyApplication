package com.evogence.eilink.screens.nodeDetails

import com.evogence.eilink.EiLinkApplication
import com.evogence.eilink.common.BlockRunnable
import com.evogence.eilink.common.dialogs.AlertDialogFragment
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.controllers.nodeCommandSender.ENodeCommand
import com.evogence.eilink.controllers.nodeCommandSender.NodeCommandSender
import com.evogence.eilink.controllers.nodesStorage.INodesStorage
import com.evogence.eilink.models.node.Node
import com.evogence.eilink.screens.INavigator
import com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater.EConnectionStatus
import com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater.EIntegrationServer
import com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater.NodeIntegrationStatusesUpdater
import javax.inject.Inject

/**
 * Created by Koren Vitalii on 9/6/2018.
 */
class NodeDetailsPresenter(val fingerprint: String)
{
    private var view: NodeDetailsView? = null
    private val viewModel = NodeDetailsVM()
    private var node: Node
    private val commandSender: NodeCommandSender
    private val nodeIntegrationStatusesUpdater: NodeIntegrationStatusesUpdater

    @Inject lateinit var navigator: INavigator
    @Inject lateinit var nodesStorage: INodesStorage

    init
    {
        EiLinkApplication.appComponent.inject(this)
        node = nodesStorage.getDeviceByFingerprint(fingerprint) ?: Node()
        nodeIntegrationStatusesUpdater = NodeIntegrationStatusesUpdater(node)
        commandSender = NodeCommandSender()
    }

    fun attachView(view: NodeDetailsView)
    {
        this.view = view
        prepareViewModel()
        view.fill(viewModel)
        view.showProfilerTab(fingerprint)
        startStatusUpdating()
    }

    private fun startStatusUpdating()
    {
        nodeIntegrationStatusesUpdater.start()
        {connectionStatus: EConnectionStatus, integrationServer: EIntegrationServer->
            when(integrationServer)
            {
                EIntegrationServer.CENTRAL_SERVER ->
                {
                    view?.setCentralServerStatus(connectionStatus)
                    node.centralServer.connectedStatus = connectionStatus
                }
                EIntegrationServer.SUPPORT_SERVER ->
                {
                    view?.setSupportServerStatus(connectionStatus)
                    node.supportServer.connectedStatus = connectionStatus
                }
                EIntegrationServer.UPDATE_SERVER ->
                {
                    view?.setUpdateServerStatus(connectionStatus)
                    node.updateServer.connectedStatus = connectionStatus
                }
            }
        }
    }

    fun detachView()
    {
        nodeIntegrationStatusesUpdater.stop()
        view = null
    }

    fun onClickProfile()
    {
        view?.showProfilerTab(fingerprint)
    }

    fun onClickPerformance()
    {
        view?.showPerformanceTab(fingerprint)
    }

    fun onClickNetworkSettings()
    {
        view?.showNetworkSettingsTab(fingerprint)
    }

    fun onClickIntegration()
    {
        view?.showIntegrationTab(fingerprint)
    }

    fun onClickScheduler()
    {
        view?.showRestartSchedulerTab(fingerprint)
    }

    fun onClickAuxMode()
    {
        view?.showAuxModeTab(fingerprint)
    }

    fun onBack()
    {
        navigator.back()
    }

    fun onClickEditTitle()
    {
        view?.showEditTitlePopup(viewModel.title)
    }

    fun onBackEditTitle()
    {
        view?.hideEditTitlePopup()
    }

    fun onSaveEditTitle(title: String)
    {
        view?.showProgress("Processing")
        commandSender.send(ENodeCommand.SET_NAME, node, title, BlockRunnable {
            if(it?.error == null)
            {
                node.title = title
                nodesStorage.updateNode(node)
                viewModel.title = title
                view?.fill(viewModel)
                view?.hideEditTitlePopup()
            }
            else
                showCommandError(it)

            view?.hideProgress()
        })
    }

    fun doBeforeExit(isSaveBtnEnabled: Boolean, listener: AlertDialogFragment.DialogResultObserver)
    {
        if(isSaveBtnEnabled)
            view?.showAlertDialog("", "You will lose any information you have edited. Are you sure you wish to close without saving?", listener, true, true)
        else
            listener.onClickPositive()
    }

    private fun prepareViewModel()
    {
        viewModel.title = node.title
        viewModel.sId = node.sid
        viewModel.version = node.version
        viewModel.model = node.model.toUpperCase()
        viewModel.iconName = node.getIconName()
        viewModel.isController = nodesStorage.isController(viewModel.model)

        viewModel.centralConnStatus = node.centralServer.connectedStatus
        viewModel.supportServerConnStatus = node.supportServer.connectedStatus
        viewModel.updateServerConnStatus = node.updateServer.connectedStatus
    }

    private fun showCommandError(commandResult: CommandResult)
    {
        if(commandResult.isSupported)
            view?.showAlertDialog("Error", commandResult.error)
        else
            view?.showAlertDialog(message =  commandResult.error)
    }
}