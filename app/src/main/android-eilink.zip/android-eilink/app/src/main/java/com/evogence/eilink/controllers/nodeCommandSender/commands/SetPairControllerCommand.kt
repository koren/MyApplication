package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive

/**
 * Created by Koren Vitalii on 9/3/2018.
 */
class SetPairControllerCommand(parameters: Any?): INodeCommand
{
    override var params: MutableMap<String, Any> = HashMap()
    override val method: String = "Integration.RPN.settings.ContextualDeviceService::pairEiController"
    override val desc: String = "Pair [Ei] Controller"

    companion object MapKeys
    {
        const val PARAMS_KEY = "params"
        const val SERIAL_KEY = "serial"
        const val FORCE_KEY = "force"
        const val STATUS_KEY = "status"
    }

    init
    {
        if(parameters != null)
            params[PARAMS_KEY] = parameters
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonObject)?.has(STATUS_KEY)?:false && !(((response.result as? JsonObject)?.get(STATUS_KEY) as? JsonPrimitive)?.asString?:"").isEmpty()
    }
}