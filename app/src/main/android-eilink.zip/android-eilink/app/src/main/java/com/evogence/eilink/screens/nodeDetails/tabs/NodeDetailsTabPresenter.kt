package com.evogence.eilink.screens.nodeDetails.tabs

import com.evogence.eilink.EiLinkApplication
import com.evogence.eilink.controllers.nodeCommandSender.NodeCommandSender
import com.evogence.eilink.controllers.nodesStorage.INodesStorage
import com.evogence.eilink.models.node.Node
import com.evogence.eilink.screens.INavigator
import javax.inject.Inject

/**
 * Created by Koren Vitalii on 9/12/2018.
 */
abstract class NodeDetailsTabPresenter<T>(fingerprint: String?)
{
    companion object
    {
        const val ONE_MINUTE: Long = 60000
    }

    var node: Node = Node()
    var view: INodeDetailsTabView<T>? = null
    val commandSender: NodeCommandSender

    var navigator: INavigator
    var nodesStorage: INodesStorage

    abstract val viewModel: T
    protected var viewModelBeforeChanges: T = viewModel

    init
    {
        val injectorHelper = InjectorHelper()
        navigator = injectorHelper.navigator
        nodesStorage = injectorHelper.nodesStorage
        if(fingerprint != null)
            node = nodesStorage.getDeviceByFingerprint(fingerprint) ?: Node()

        commandSender = NodeCommandSender()
    }

    open fun attachView(view: INodeDetailsTabView<T>)
    {
        this.view = view
        prepareViewModel()
        view.fill(viewModel as Any)
    }

    open fun detachView()
    {
        view?.hideProgress()
        commandSender.cancel()
        view = null
    }

    open fun onSave()
    {
        view?.retrieveChanges(viewModel)
        view?.showProgress("Processing")
        view?.hideKeyboard()
        saveChanges()
    }

    fun onBack()
    {
        view?.hideProgress()
        commandSender.cancel()
        navigator.back()
    }

    abstract fun prepareViewModel()

    abstract fun saveChanges()

    fun onDataChanged()
    {
        view?.retrieveChanges(viewModel)
        view?.enableSaveButton(viewModel != viewModelBeforeChanges)
    }

    class InjectorHelper
    {
        @Inject lateinit var navigator: INavigator
        @Inject lateinit var nodesStorage: INodesStorage

        init
        {
            EiLinkApplication.appComponent.inject(this)
        }
    }
}