package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class GetNetSettingsCommand: INodeCommand
{
    override val method: String = "Integration.RPN.settings.ProfilerService::getNetworkSettings"
    override val desc: String = "Get Network Settings"

    override var params: MutableMap<String, Any> = HashMap()

    companion object MapKeys
    {
        const val HOST_KEY = "host"
        const val ETHERNET_KEY = "ethernet"
        const val WIFI_KEY = "wifi"
        const val IPDHCP_KEY = "ipdhcp"
        const val IPDNS1_KEY = "ipdns1"
        const val IPDNS2_KEY = "ipdns2"
        const val IPDNS3_KEY = "ipdns3"
        const val IPADDRESS_KEY = "ipaddress"
        const val IPNETMASK_KEY = "ipnetmask"
        const val IPGATEWAY_KEY = "ipgateway"
        const val IP_VERSION_KEY = "ipversion"
        const val WIFI_PREFERRED_KEY = "wifi_preferred"
        const val IPDHCP1_KEY = "ipdhcp1"
        const val WIFI_ENABLED_KEY = "wifi_enabled"
        const val SSID_KEY = "ssid"
        const val SECURITY_PROTOCOL_KEY = "security_protocol"
        const val AUTH_IDENTITY_KEY = "auth_identity"
        const val AUTH_KEY = "auth_key"
        const val AUTH_PASSWORD_KEY = "auth_password"
        const val AUTH_PRIVATE_KEY_PASSWD_KEY = "auth_private_key_passwd"
        const val IPADDRESS1_KEY = "ipaddress1"
        const val IPNETMASK1_KEY = "ipnetmask1"
        const val IPGATEWAY1_KEY = "ipgateway1"
        const val IP_VERSION1_KEY = "ipversion1"
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        var isCorrect = false

        val type = object: TypeToken<Map<String, Any?>>()
        {}.type
        val result = Gson().fromJson<Map<String, Any?>>(response.result, type)

        if(result != null)
        {
            val ethernet = result[ETHERNET_KEY] as? Map<*, *>
            val wifi = result[WIFI_KEY] as? Map<*, *>
            if(ethernet != null && wifi != null)
            {
                val ethernetValidKeys = arrayListOf(IPDHCP_KEY, IPDNS1_KEY, IPDNS2_KEY, IPDNS3_KEY, IPADDRESS_KEY, IPNETMASK_KEY, IPGATEWAY_KEY, IP_VERSION_KEY)
                val wifiValidKeys = arrayListOf(WIFI_PREFERRED_KEY, IPDHCP1_KEY, WIFI_ENABLED_KEY, SSID_KEY, SECURITY_PROTOCOL_KEY, AUTH_IDENTITY_KEY, AUTH_KEY, AUTH_PASSWORD_KEY, AUTH_PRIVATE_KEY_PASSWD_KEY, IPADDRESS1_KEY, IPNETMASK1_KEY, IPGATEWAY1_KEY, IP_VERSION1_KEY)
                isCorrect = (ethernet.keys.containsAll(ethernetValidKeys.toList()) && wifi.keys.containsAll(wifiValidKeys.toList()))
            }
        }
        return isCorrect
    }
}