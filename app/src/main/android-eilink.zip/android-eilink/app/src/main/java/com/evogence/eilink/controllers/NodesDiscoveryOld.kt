package com.evogence.eilink.controllers

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.CountDownTimer
import com.evogence.eilink.models.node.Node
import com.evogence.eilink.models.node.NodeSyncStatus

/**
 * Created by Anatolij on 8/29/18.
 */
class NodesDiscoveryOld(val context: Context)
{
    companion object
    {
        private const val SERVICE_TYPE = "_http._tcp"
        private const val SERVICE_NAME = "NodesDiscoveryOld"
        private const val PORT = 9000
        private const val TIMER_PERIOD = 3000L
    }

    val nodeList: MutableList<Node> = mutableListOf()
    private val nsdManager: NsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var mServiceName: String? = null
    private var waitTimer: CountDownTimer? = null
    private lateinit var mNsdManager: NsdManager
    private var completion: (TabLayout (List<Node>)->Unit)? = null

    private val mRegistrationListener = object: NsdManager.RegistrationListener
    {
        override fun onServiceRegistered(serviceInfo: NsdServiceInfo)
        {
            mServiceName = serviceInfo.serviceName
            nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, mDiscoveryListener)
        }

        override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int)
        {
        }

        override fun onServiceUnregistered(arg0: NsdServiceInfo)
        {
        }

        override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int)
        {
        }
    }

    private val mDiscoveryListener = object: NsdManager.DiscoveryListener
    {
        override fun onServiceFound(service: NsdServiceInfo)
        {
            stopTimer()
            startTimer(TIMER_PERIOD)
            {
                //completion?.invoke(getTestNodes()) //todo for tests
                completion?.invoke(nodeList)
                nsdManager.stopServiceDiscovery(this)
                unregisterService()
            }

            if(service.serviceName.contains("Ei"))
            {
                mNsdManager.resolveService(service, object: NsdManager.ResolveListener
                {

                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int)
                    {
                    }

                    override fun onServiceResolved(serviceInfo: NsdServiceInfo)
                    {
                        val node = Node()
                        node.port = serviceInfo.port
                        node.host = serviceInfo.host.hostName
                        serviceInfo.attributes.forEach {(key, value)->
                            val stringValue = String(value, Charsets.UTF_8)
                            when(key)
                            {
                                "fingerprint" -> node.fingerprint = stringValue
                                "productid" -> node.model = stringValue
                                "serial" -> node.sn = stringValue
                                "sid" -> node.sid = stringValue
                                "title" -> node.title = stringValue
                                "version" -> node.version = stringValue
                            }
                        }
                        nodeList.add(node)
                    }
                })
            }
        }

        override fun onServiceLost(service: NsdServiceInfo)
        {
        }

        override fun onDiscoveryStarted(p0: String?)
        {
        }

        override fun onDiscoveryStopped(serviceType: String)
        {
        }

        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int)
        {
            nsdManager.stopServiceDiscovery(this)
        }

        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int)
        {
            nsdManager.stopServiceDiscovery(this)
        }
    }

    private fun unregisterService()
    {
        mNsdManager.unregisterService(mRegistrationListener)
    }

    fun searchDevices(completion: (List<Node>)->Unit)
    {
        this.completion = completion
        registerService(PORT)
    }

    private fun registerService(port: Int)
    {
        val serviceInfo = NsdServiceInfo().apply()
        {
            serviceName = SERVICE_NAME
            serviceType = SERVICE_TYPE
            setPort(port)
        }

        mNsdManager = (context.getSystemService(Context.NSD_SERVICE) as NsdManager).apply()
        {
            registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, mRegistrationListener)
        }
    }

    private fun startTimer(period: Long, function: ()->Unit)
    {
        waitTimer = object: CountDownTimer(period, period)
        {

            override fun onTick(millisUntilFinished: Long)
            {
            }

            override fun onFinish()
            {
                function.invoke()
            }
        }.start()
    }

    fun stopTimer()
    {
        waitTimer?.cancel()
        waitTimer = null
    }

    private fun getFakeNodes(): List<Node>
    {
        val result = ArrayList<Node>()

        var node = Node()
        node.fingerprint = "755877a67cce9c6ef8bb70559ba9e7e1"
        node.title = "222"
        node.sn = "678678679789"
        node.port = 80
        node.sid = "G43507R001239"
        node.model = "s1137"
        node.host = "192.168.101.222"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.101.222"
        node.version = "4.0.1.p1"
        result.add(node)

        node = Node()
        node.fingerprint = "ee6f83be4b723d43d92b5c6c75551da7"
        node.title = "192.168.101.117"
        node.sn = "45756778678"
        node.port = 80
        node.sid = "G46230R003626"
        node.host = "192.168.101.117"
        node.model = "s2117f"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.101.117"
        result.add(node)

        node = Node()
        node.fingerprint = "386f043c2c27c518932866afb9fc8a39"
        node.title = "192.168.101.157"
        node.sn = "45787544577"
        node.port = 80
        node.model = "asme_android"
        node.host = "192.168.101.157"
        node.sid = "H17658R000179"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.101.157"
        result.add(node)

        node = Node()
        node.fingerprint = "004ea82006d629fd9bce1d2db974f455"
        node.title = "Ei Node"
        node.sn = "19216815054"
        node.port = 80
        node.model = "eic100"
        node.host = "192.168.150.54"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.54"
        node.version = "4.0.2 D"
        result.add(node)

        node = Node()
        node.fingerprint = "e0d239de5516ba992eccac4ab1638765"
        node.title = "192.168.150.52"
        node.sn = "54578755665436"
        node.port = 80
        node.model = "s1137"
        node.host = "192.168.150.52"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.52"
        node.version = "4.0.2 D"
        result.add(node)

        node = Node()
        node.title = "192.168.150.55"
        node.address = "192.168.150.55"
        node.model = "e2225"
        node.version = "4.0.2.p.1_dev D"
        node.sn = "19216815055"
        node.sid = "50026B7223016326"
        node.fingerprint = "34b61ddb98b575b30e6c468164d34f67"
        node.port = 80
        node.host = "192.168.150.55"
        node.syncStatus = NodeSyncStatus()
        result.add(node)


        node = Node()
        node.fingerprint = "444b7a755c32fd16ba0fd806981ac5ba"
        node.title = "192.168.150.51"
        node.sn = "876t8754573453"
        node.port = 80
        node.model = "s2117f"
        node.host = "192.168.150.51"
        node.sid = "161523400118"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.51"
        node.version = "4.0.2.p.1_dev D"
        node.edition = "advanced"
        node.location = "EVD Location 111"
        result.add(node)

        return result
    }

    private fun getTestNodes(): List<Node>
    {
        val result = ArrayList<Node>()

        var node = Node()
        node.fingerprint = "34b61ddb98b575b30e6c468164d34f67"
        node.title = "[Ei]-Node"
        node.sn = "19216815055"
        node.port = 80
        node.sid = "50026B7223016326"
        node.model = "e2225"
        node.host = "192.168.150.55"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.55"
        node.version = "4.0.2.p.1_dev D"
        result.add(node)

        node = Node()
        node.fingerprint = "004ea82006d629fd9bce1d2db974f455"
        node.title = "Ei Node2"
        node.sn = "370528"
        node.port = 80
        node.sid = "370528"
        node.host = "192.168.150.54"
        node.model = "eic100"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.54"
        result.add(node)

        return result
    }
}