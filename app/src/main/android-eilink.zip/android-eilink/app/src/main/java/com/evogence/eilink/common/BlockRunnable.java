package com.evogence.eilink.common;

import com.evogence.eilink.controllers.nodeCommandSender.CommandResult;

public interface BlockRunnable
{
    void run(CommandResult result);
}
