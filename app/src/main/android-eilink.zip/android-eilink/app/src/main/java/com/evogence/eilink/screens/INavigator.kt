package com.evogence.eilink.screens

import android.support.v7.app.AppCompatActivity
import com.evogence.eilink.screens.nodeList.groupOperations.EGroupOperation

/**
 * Created by Koren Vitalii on 19.04.2018.
 */
interface INavigator
{
    fun getBackStackEntryCount(): Int
    fun navigateToAuthorization()
    fun navigateToNodeDetails(fingerprint: String)
    fun prepare(activity: AppCompatActivity)
    fun back()
    fun navigateToNodeList()
    fun navigateToAbout()
    fun navigateToNodeIntegrationTab(fingerprint: String)
    fun navigateToGroupOperation(fingerprints: Array<String>, integration: EGroupOperation)
}
