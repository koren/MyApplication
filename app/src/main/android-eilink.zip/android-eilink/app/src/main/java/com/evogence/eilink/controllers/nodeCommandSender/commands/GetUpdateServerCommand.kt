package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.JsonObject

class GetUpdateServerCommand: INodeCommand
{
    override val method: String = "Integration.RPN.settings.ManagementServer::getUpdateServer"
    override val desc: String = "Get Update Server"

    companion object MapKeys
    {
        const val STATUS_KEY = "status"
        const val HOST_KEY = "host"
    }

    override var params: MutableMap<String, Any> = HashMap()

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonObject)?.has(STATUS_KEY) ?: false && (response.result as? JsonObject)?.has(HOST_KEY) ?: false
    }

    override fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()
        var status = false
        var host = ""
        if((response.result as JsonObject).has(STATUS_KEY))
        {
            status = (response.result as JsonObject).get(STATUS_KEY).asInt == 1
        }

        if((response.result as JsonObject).has(HOST_KEY))
        {
            host = (response.result as JsonObject).get(HOST_KEY).asString
        }
        commandResult.params = mapOf(STATUS_KEY to status, HOST_KEY to host)

        return commandResult
    }

}