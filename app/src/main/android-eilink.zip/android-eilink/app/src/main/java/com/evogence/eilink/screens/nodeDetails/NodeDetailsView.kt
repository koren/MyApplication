package com.evogence.eilink.screens.nodeDetails

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.evogence.eilink.R
import com.evogence.eilink.common.Utils.prepareIconRes
import com.evogence.eilink.common.dialogs.AlertDialogFragment
import com.evogence.eilink.common.ui.ScreenView
import com.evogence.eilink.common.ui.SelectorView
import com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater.EConnectionStatus
import com.evogence.eilink.screens.nodeDetails.tabs.INodeDetailsTabViewTitleBar
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.AuxModeView
import com.evogence.eilink.screens.nodeDetails.tabs.integrationTab.NodeIntegrationView
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.NetworkSettingsView
import com.evogence.eilink.screens.nodeDetails.tabs.performanceTab.PerformanceView
import com.evogence.eilink.screens.nodeDetails.tabs.profileTab.ProfileView
import com.evogence.eilink.screens.nodeDetails.tabs.restartSchedulerTab.RestartSchedulerView
import io.reactivex.Maybe
import io.reactivex.android.schedulers.AndroidSchedulers
import kotlinx.android.synthetic.main.node_details.*
import kotlinx.android.synthetic.main.node_details_edit_name.*
import kotlinx.android.synthetic.main.node_item_common_part.*

/**
 * Created by Koren Vitalii on 9/6/2018.
 */
class NodeDetailsView: ScreenView(), View.OnClickListener
{
    lateinit var presenter: NodeDetailsPresenter
    private var previousActiveMenuBtn: View? = null
    private var currentTab: INodeDetailsTabViewTitleBar? = null

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"

        @JvmStatic
        fun newInstance(fingerprint: String): Fragment
        {
            val fragment = NodeDetailsView()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        presenter = NodeDetailsPresenter(arguments?.getString(FINGERPRINT_KEY)!!)
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.node_details, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        initView()
        presenter.attachView(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onDestroyView()
    {
        fragmentManager!!.beginTransaction()
            .remove(fragmentManager!!.findFragmentById(R.id.tabContainer))
            .commit()
        presenter.detachView()
        super.onDestroyView()
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.saveBtn -> currentTab?.onClickSave()
            R.id.backBtn -> processingBackBtn()
            R.id.editBtn -> presenter.onClickEditTitle()
            R.id.backEditTitleBtn -> presenter.onBackEditTitle()
            R.id.profileBtn,
            R.id.performanceBtn,
            R.id.networkSettingsBtn,
            R.id.integrationBtn,
            R.id.restartSchedulerBtn,
            R.id.auxModeBtn -> onClickMenuBtn(v, currentTab?.isShowSaveButton == true, saveBtn.isEnabled)
        }
    }

    private fun processingBackBtn()
    {
        if(currentTab?.isShowSaveButton == true)
        {
            presenter.doBeforeExit(saveBtn.isEnabled, object: AlertDialogFragment.DialogResultObserver
            {
                override fun onClickPositive()
                {
                    presenter.onBack()
                }
            })
        }
        else
            presenter.onBack()
    }

    override fun fill(model: Any)
    {
        model as NodeDetailsVM
        auxModeBtn.visibility = if(model.isController) View.VISIBLE else View.GONE

        nodeNameTV.text = model.title
        serialNumberTV.text = model.sId
        versionLabelTV.text = model.version
        modelLabelTV.text = if(model.model.isEmpty()) model.sId else model.model
        applianceImg.setImageResource(prepareIconRes(context, model.iconName))

        updateStatusImage(model.centralConnStatus, centralServerIV, R.drawable.ic_management_server_undefined, R.drawable.ic_management_server_active, R.drawable.ic_management_server_inactive)
        updateStatusImage(model.supportServerConnStatus, supportServerIV, R.drawable.ic_support_server_undefined, R.drawable.ic_support_server_active, R.drawable.ic_support_server_inactive)
        updateStatusImage(model.updateServerConnStatus, updateServerIV, R.drawable.ic_update_server_undefined, R.drawable.ic_update_server_active, R.drawable.ic_update_server_inactive)
    }

    fun showProfilerTab(fingerprint: String)
    {
        showTab(ProfileView.build(fingerprint))
    }

    fun showPerformanceTab(fingerprint: String)
    {
        showTab(PerformanceView.build(fingerprint))
    }

    fun showNetworkSettingsTab(fingerprint: String)
    {
        showTab(NetworkSettingsView.build(fingerprint))
    }

    fun showIntegrationTab(fingerprint: String)
    {
        showTab(NodeIntegrationView.build(fingerprint))
    }

    fun showRestartSchedulerTab(fingerprint: String)
    {
        showTab(RestartSchedulerView.build(fingerprint))
    }

    fun showAuxModeTab(fingerprint: String)
    {
        showTab(AuxModeView.build(fingerprint))
    }

    fun showEditTitlePopup(title: String)
    {
        editTitleContainer.visibility = View.VISIBLE

        val selectorView = SelectorView()
        backEditTitleBtn.setOnTouchListener(selectorView)
        saveEditTitleBtn.setOnTouchListener(selectorView)

        backEditTitleBtn.setOnClickListener(this)
        saveEditTitleBtn.setOnClickListener {presenter.onSaveEditTitle(editTitleET.text.toString())}
        editTitleET.setText(title)
    }

    fun hideEditTitlePopup()
    {
        hideKeyboard()
        editTitleContainer.visibility = View.GONE
    }

    fun actionOnMenuBtnClick(v: View?)
    {
        changeMenuBtn(v)

        when(v?.id)
        {
            R.id.profileBtn -> presenter.onClickProfile()
            R.id.performanceBtn -> presenter.onClickPerformance()
            R.id.networkSettingsBtn -> presenter.onClickNetworkSettings()
            R.id.integrationBtn -> presenter.onClickIntegration()
            R.id.restartSchedulerBtn -> presenter.onClickScheduler()
            R.id.auxModeBtn -> presenter.onClickAuxMode()
        }
    }

    private fun changeMenuBtn(v: View?)
    {
        previousActiveMenuBtn?.background = context?.getDrawable(R.drawable.bottom_button_corner)
        previousActiveMenuBtn = v
        v?.background = context?.getDrawable(R.drawable.bottom_button_corner_active)
    }

    private fun showTab(view: Fragment)
    {
        val fr = fragmentManager!!.findFragmentById(R.id.tabContainer)
        if((fr == null) || (view.javaClass.name != fr.javaClass.name))
        {
            fragmentManager!!.beginTransaction()
                .replace(R.id.tabContainer, view, view.javaClass.name)
                .commit()
        }

        if(view is INodeDetailsTabViewTitleBar)
        {
            currentTab = view
            currentTab?.changeSaveButtonStatusListener = {enableSaveButton->
                saveBtn?.let {it.isEnabled = enableSaveButton}
            }
            titleTV.text = view.title
            saveBtn.visibility = if(view.isShowSaveButton) View.VISIBLE else View.GONE
        }
        else
            currentTab = null
    }

    private fun initView()
    {
        previousActiveMenuBtn = profileBtn

        val selectorView = SelectorView()
        profileBtn.setOnTouchListener(selectorView)
        performanceBtn.setOnTouchListener(selectorView)
        networkSettingsBtn.setOnTouchListener(selectorView)
        integrationBtn.setOnTouchListener(selectorView)
        restartSchedulerBtn.setOnTouchListener(selectorView)
        auxModeBtn.setOnTouchListener(selectorView)
        logBtn.setOnTouchListener(selectorView)
        backBtn.setOnTouchListener(selectorView)
        saveBtn.setOnTouchListener(selectorView)
        editBtn.setOnTouchListener(selectorView)

        profileBtn.setOnClickListener(this)
        performanceBtn.setOnClickListener(this)
        networkSettingsBtn.setOnClickListener(this)
        integrationBtn.setOnClickListener(this)
        restartSchedulerBtn.setOnClickListener(this)
        auxModeBtn.setOnClickListener(this)
        logBtn.setOnClickListener(this)
        backBtn.setOnClickListener(this)
        saveBtn.setOnClickListener(this)
        editBtn.setOnClickListener(this)

        saveBtn.isEnabled = false
    }

    private fun onClickMenuBtn(view: View?, isShowSaveButton: Boolean, isSaveBtnEnabled: Boolean)
    {
        if(isShowSaveButton)
        {
            presenter.doBeforeExit(isSaveBtnEnabled, object: AlertDialogFragment.DialogResultObserver
            {
                override fun onClickPositive()
                {
                    saveBtn.isEnabled = false
                    actionOnMenuBtnClick(view)
                }
            })
        }
        else
            actionOnMenuBtnClick(view)
    }

    fun setCentralServerStatus(connectionStatus: EConnectionStatus)
    {
        updateStatusImage(connectionStatus, centralServerIV, R.drawable.ic_management_server_undefined, R.drawable.ic_management_server_active, R.drawable.ic_management_server_inactive)
    }

    fun setSupportServerStatus(connectionStatus: EConnectionStatus)
    {
        updateStatusImage(connectionStatus, supportServerIV, R.drawable.ic_support_server_undefined, R.drawable.ic_support_server_active, R.drawable.ic_support_server_inactive)
    }

    fun setUpdateServerStatus(connectionStatus: EConnectionStatus)
    {
        updateStatusImage(connectionStatus, updateServerIV, R.drawable.ic_update_server_undefined, R.drawable.ic_update_server_active, R.drawable.ic_update_server_inactive)
    }

    private fun updateStatusImage(connectionStatus: EConnectionStatus, imageView: ImageView, iconIdUndefined: Int, iconIdActive: Int, iconIdInactive: Int)
    {
        Maybe.fromAction<Any> {
            when(connectionStatus)
            {
                EConnectionStatus.UNDEFINED_STATUS -> imageView.setImageDrawable(ContextCompat.getDrawable(context!!, iconIdUndefined))
                EConnectionStatus.CONNECTED_STATUS -> imageView.setImageDrawable(ContextCompat.getDrawable(context!!, iconIdActive))
                EConnectionStatus.DISCONNECTED_STATUS -> imageView.setImageDrawable(ContextCompat.getDrawable(context!!, iconIdInactive))
            }
        }.subscribeOn(AndroidSchedulers.mainThread()).subscribe()
    }
}