package com.evogence.eilink.screens.nodeList.groupOperations

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import com.evogence.eilink.common.ui.SelectorView
import com.evogence.eilink.screens.nodeDetails.tabs.INodeDetailsTabViewTitleBar
import com.evogence.eilink.screens.nodeDetails.tabs.integrationTab.NodeIntegrationView
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.NetworkSettingsView
import com.evogence.eilink.screens.nodeDetails.tabs.restartSchedulerTab.RestartSchedulerView
import kotlinx.android.synthetic.main.group_operations.*

/**
 * Created by Koren Vitalii on 9/6/2018.
 */
class GroupOperationView: Fragment(), View.OnClickListener
{
    lateinit var presenter: GroupOperationsPresenter
    private var currentOperation: INodeDetailsTabViewTitleBar? = null

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"
        private const val OPERATION_KEY = "operation_key"

        @JvmStatic
        fun build(fingerprints: Array<String>, operation: EGroupOperation): Fragment
        {
            val fragment = GroupOperationView()
            val args = Bundle()
            args.putStringArray(FINGERPRINT_KEY, fingerprints)
            args.putSerializable(OPERATION_KEY, operation)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        arguments?.let {presenter = GroupOperationsPresenter(it.getStringArray(FINGERPRINT_KEY), it.getSerializable(OPERATION_KEY) as EGroupOperation)}
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.group_operations, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        initView()
        presenter.attachView(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onDestroyView()
    {
        presenter.detachView()
        super.onDestroyView()
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.saveBtn -> currentOperation?.onClickSave()
            R.id.backBtn -> presenter.onBack()
        }
    }

    fun showIntegration(fingerprints: Array<String>)
    {
        showOperation(NodeIntegrationView.build(fingerprints))
    }

    fun showNetworkSettings(fingerprints: Array<String>)
    {
        showOperation(NetworkSettingsView.build(fingerprints))
    }

    fun showShutdownScheduler(fingerprints: Array<String>)
    {
        showOperation(RestartSchedulerView.build(fingerprints))
    }

    private fun showOperation(view: Fragment)
    {
        fragmentManager!!.beginTransaction()
            .replace(R.id.operationContainer, view, view.javaClass.name)
            .commit()

        if(view is INodeDetailsTabViewTitleBar)
        {
            currentOperation = view
            titleTV.text = view.title
//            saveBtn.visibility = if(view.isShowSaveButton) View.VISIBLE else View.GONE
            view.changeSaveButtonStatusListener = {enableSaveButton->
                saveBtn.isEnabled = enableSaveButton
            }
            view.enableSaveButton(false)
        }
        else
        {
            currentOperation = null
        }
    }

    private fun initView()
    {
        val selectorView = SelectorView()
        backBtn.setOnTouchListener(selectorView)
        saveBtn.setOnTouchListener(selectorView)

        backBtn.setOnClickListener(this)
        saveBtn.setOnClickListener(this)
    }
}