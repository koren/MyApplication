package com.evogence.eilink.controllers.apiServices

import com.evogence.eilink.common.ConnectionData
import com.evogence.eilink.common.json_rpc.JsonRpcRequest
import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import io.reactivex.Flowable

interface INodeApiService
{
    fun build(connectionData: ConnectionData, fingerprint: String): INodeApiService

    fun getBaseURL() : String
    fun getFingerprint() : String
    fun request(request: JsonRpcRequest) : Flowable<JsonRpcResponse>
}
