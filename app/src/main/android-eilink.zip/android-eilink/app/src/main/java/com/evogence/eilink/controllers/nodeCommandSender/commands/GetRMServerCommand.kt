package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.JsonObject

class GetRMServerCommand: INodeCommand
{
    override val method: String = "Integration.RPN.settings.ManagementServer::getTunnelData"
    override val desc: String = "Get Reverse Monitoring Configuration Server"

    companion object MapKeys
    {
        const val TUNNEL_ENABLED_KEY = "tunnel_enabled"
        const val TUNNEL_ADDRESS_KEY = "tunnel_address"
    }

    override var params: MutableMap<String, Any> = HashMap()

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonObject)?.has(TUNNEL_ENABLED_KEY)?:false && (response.result as? JsonObject)?.has(TUNNEL_ADDRESS_KEY)?: false
    }

    override fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()
        val jsonObject = response.result as JsonObject
        commandResult.params = mapOf(
            TUNNEL_ENABLED_KEY to (jsonObject.get(TUNNEL_ENABLED_KEY).asInt == 1),
            TUNNEL_ADDRESS_KEY to jsonObject.get(TUNNEL_ADDRESS_KEY).asString)
        return commandResult
    }
}
