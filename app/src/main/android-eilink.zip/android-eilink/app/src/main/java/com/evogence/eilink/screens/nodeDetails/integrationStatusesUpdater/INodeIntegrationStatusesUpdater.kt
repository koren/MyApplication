package com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater

/**
 * Created by Koren Vitalii on 10/5/2018.
 */
interface INodeIntegrationStatusesUpdater
{
    fun start(changedTo: ((EConnectionStatus, EIntegrationServer) -> Unit)?)
    fun stop()
}