package com.evogence.eilink.screens.nodeDetails

import com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater.EConnectionStatus

/**
 * Created by Koren Vitalii on 9/6/2018.
 */
class NodeDetailsVM
{
    var title: String = ""
    var sId: String = ""
    var version: String = ""
    var model: String = ""
    var iconName: String = ""
    var isController = false

    var centralConnStatus = EConnectionStatus.UNDEFINED_STATUS
    var supportServerConnStatus = EConnectionStatus.UNDEFINED_STATUS
    var updateServerConnStatus = EConnectionStatus.UNDEFINED_STATUS
}