package com.evogence.eilink.screens.nodeList

import android.support.v4.content.ContextCompat
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.daimajia.swipe.SwipeLayout
import com.evogence.eilink.R
import com.evogence.eilink.common.Utils.prepareIconRes
import com.evogence.eilink.common.ui.SelectorView
import kotlinx.android.synthetic.main.node_item_common_part_for_list.view.*
import kotlinx.android.synthetic.main.node_list_item.view.*

/**
 * Created by Koren Vitalii on 05/23/18.
 */
class NodeListItemHolder(inflater: LayoutInflater, parent: ViewGroup, private val nodeListView: NodeListView): RecyclerView.ViewHolder(inflater.inflate(R.layout.node_list_item, parent, false)), View.OnClickListener
{
    lateinit var node: NodeListItemVM
    private var userInteractionEnabled: Boolean = false

    fun bind(node: NodeListItemVM)
    {
        this.node = node

        val selectorView = SelectorView()
        itemView.resetBtn.setOnTouchListener(selectorView)
        itemView.rebootBtn.setOnTouchListener(selectorView)
        itemView.restartBtn.setOnTouchListener(selectorView)

        itemView.nodeIconContainer.setOnClickListener(this)
        itemView.dataContainer.setOnClickListener(this)
        itemView.resetBtn.setOnClickListener(this)
        itemView.rebootBtn.setOnClickListener(this)
        itemView.restartBtn.setOnClickListener(this)

        itemView.nodeNameTV.text = node.title
        itemView.serialNumberTV.text = node.serialNumber
        itemView.versionLabelTV.text = node.version
        itemView.modelLabelTV.text = if(node.model.isEmpty()) node.sId else node.model
        itemView.applianceImg.setImageResource(prepareIconRes(itemView.context, node.iconName))

        itemView.swipeLayout.showMode = SwipeLayout.ShowMode.LayDown
        itemView.swipeLayout.addDrag(SwipeLayout.DragEdge.Left, itemView.backgroundContainer)
        itemView.swipeLayout.addDrag(SwipeLayout.DragEdge.Right, null)
        itemView.swipeLayout.addSwipeListener(object: SwipeLayout.SwipeListener
        {
            override fun onOpen(layout: SwipeLayout?)
            {
                node.menuOpened = true
                nodeListView.onOpen(layout)
            }

            override fun onUpdate(layout: SwipeLayout?, leftOffset: Int, topOffset: Int)
            {
            }

            override fun onStartOpen(layout: SwipeLayout?)
            {
                nodeListView.onStartOpenMenu(layout)
            }

            override fun onStartClose(layout: SwipeLayout?)
            {
            }

            override fun onHandRelease(layout: SwipeLayout?, xvel: Float, yvel: Float)
            {
            }

            override fun onClose(layout: SwipeLayout?)
            {
                node.menuOpened = false
            }
        })
        userInteractionEnabled = node.isUserInteractionEnabled
        updateUISelectedPart()
    }

    override fun onClick(v: View)
    {
        when(v.id)
        {
            R.id.nodeIconContainer -> nodeListView.onClickNodeIconContainer(node.fingerprint)
            R.id.dataContainer ->
            {
                if(node.menuOpened)
                    return

                node.isSelected = !node.isSelected
                if(node.isSelected)
                    itemView.swipeLayout.addDrag(SwipeLayout.DragEdge.Left, null)
                else
                    itemView.swipeLayout.addDrag(SwipeLayout.DragEdge.Left, itemView.backgroundContainer)

                nodeListView.changeStatusGroupOperationsBar()
                updateUISelectedPart()
            }
            R.id.resetBtn -> nodeListView.reset(node.fingerprint)
            R.id.rebootBtn -> nodeListView.reboot(node.fingerprint)
            R.id.restartBtn -> nodeListView.restart(node.fingerprint)
        }
    }

    private fun updateUISelectedPart()
    {
        if(node.isSelected)
        {
            itemView.selectedIV.visibility = View.VISIBLE
            itemView.foregroundContainer.background = itemView.context.getDrawable(R.drawable.node_list_item_menu)
            itemView.serialNumberTV.setTextColor(ContextCompat.getColor(itemView.context, R.color.white))
        }
        else
        {
            itemView.selectedIV.visibility = View.GONE
            itemView.foregroundContainer.background = itemView.context.getDrawable(R.drawable.nodes_item)
            itemView.serialNumberTV.setTextColor(ContextCompat.getColor(itemView.context, R.color.node_list_item_details_small_text))
        }
    }
}

