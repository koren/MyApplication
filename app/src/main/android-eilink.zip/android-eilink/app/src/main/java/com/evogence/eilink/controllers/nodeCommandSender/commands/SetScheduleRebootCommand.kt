package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.JsonPrimitive

class SetScheduleRebootCommand(parameters: Any?): INodeCommand
{
    override val method: String = "Integration.RPN.settings.ProfilerService::setScheduleReboot"
    override val desc: String get() = "Set Schedule " + this.type

    override var params: MutableMap<String, Any> = HashMap()
    var type: String = ""

    companion object MapKeys
    {
        val PARAMS_KEY: String = "params"
        val HOST_KEY: String = "host"
        val TYPE_KEY:String = "type"
    }

    init
    {
        if(parameters != null)
        {
            params[PARAMS_KEY] = parameters
            if(parameters is Map<*, *>)
            {
                type = parameters[TYPE_KEY].toString()
            }
        }
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonPrimitive)?.isBoolean ?: false
    }

    override fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()
        val result = (response.result as JsonPrimitive).asBoolean
        if(!result)
        {
            if((response.error) != null && (response.error!!.message != null))
            {
                commandResult.error = "Configuration have not been changed: " + response.error!!.message
            }
            else
            {
                commandResult.error = "Configuration have not been changed."
            }
        }
        return commandResult
    }
}