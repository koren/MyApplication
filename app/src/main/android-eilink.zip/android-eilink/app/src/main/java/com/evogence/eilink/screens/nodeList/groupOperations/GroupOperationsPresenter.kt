package com.evogence.eilink.screens.nodeList.groupOperations

import com.evogence.eilink.EiLinkApplication
import com.evogence.eilink.controllers.nodesStorage.INodesStorage
import com.evogence.eilink.screens.INavigator
import javax.inject.Inject

/**
 * Created by Koren Vitalii on 9/6/2018.
 */
class GroupOperationsPresenter(val fingerprints: Array<String>, private val operation: EGroupOperation)
{
    private var view: GroupOperationView? = null

    @Inject lateinit var navigator: INavigator
    @Inject lateinit var nodesStorage: INodesStorage

    init
    {
        EiLinkApplication.appComponent.inject(this)
    }

    fun attachView(view: GroupOperationView)
    {
        this.view = view
        when(operation)
        {
            EGroupOperation.Integration -> view.showIntegration(fingerprints)
            EGroupOperation.Network -> view.showNetworkSettings(fingerprints)
            EGroupOperation.Reboot -> view.showShutdownScheduler(fingerprints)
        }
    }

    fun detachView()
    {
        view = null
    }

    fun onBack()
    {
        navigator.back()
    }
}