package com.evogence.eilink.common.ui;

import android.content.Context;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.util.AttributeSet;

import com.evogence.eilink.R;

/**
 * Created by Koren Vitalii on 9/11/2018.
 */
public class GradientTextView extends android.support.v7.widget.AppCompatTextView
{
    public GradientTextView(Context context)
    {
        super(context, null, -1);
    }

    public GradientTextView(Context context, AttributeSet attrs)
    {
        super(context, attrs, -1);
    }

    public GradientTextView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right,
                            int bottom)
    {
        super.onLayout(changed, left, top, right, bottom);
        if(changed)
        {
            getPaint().setShader(
                    new LinearGradient(0, 0, getWidth(), 0, getContext().getResources().getColor(R.color.startGradientNodeListItemMenu),
                            getContext().getResources().getColor(R.color.endGradientNodeListItemMenu), Shader.TileMode.REPEAT));
        }
    }
}
