package com.evogence.eilink.common

import android.content.Context

/**
 * Created by admin on 9/7/17.
 */

interface ISysInfo
{
    fun getFormattedDate(format: String): String
    val cpuUsage: Double
    val shortVersion: String
    val uptime: Long
    val currentTimestamp: Long
    val udid: String
    val appVersion: String?
    val platform: String?
    val timeZone: String?
    val ip: String?
    val systemOS: String?
    val macAddress: String?
    val deviceModel: String?
    val memoryInfo: MemoryInfo
    fun getConnectionType(context: Context): EConnectionType
}
