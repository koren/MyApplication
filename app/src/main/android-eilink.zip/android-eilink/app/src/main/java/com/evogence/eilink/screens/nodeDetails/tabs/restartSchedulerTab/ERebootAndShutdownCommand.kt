package com.evogence.eilink.screens.nodeDetails.tabs.restartSchedulerTab

/**
 * Created by Koren Vitalii on 8/8/2018.
 */
enum class ERebootAndShutdownCommand(val type: String)
{
    REBOOT_SCHEDULER("reboot_scheduler"),
    SHUTDOWN_APPLIANCE("shutdown_appliance"),
    REBOOT_PLAYBACK("reboot_playback"),
    EMPTY("")
}