package com.evogence.eilink.controllers.nodeCommandSender.commands.parameters

import com.evogence.eilink.controllers.nodeCommandSender.commands.SetRemoteNodeSwitchSettingsCommand

/**
 * Created by Koren Vitalii on 9/4/2018.
 */
class RemoteNodeSwitchSettingsParams(var serial: String = "",
                                     private val enable: Int = 0,
                                     private val watchdogNodeSN: String = "",
                                     private val watchdogTimeout: Double = 0.0)
{
    fun buildMap(): Map<String, Any?>
    {
        return  mapOf(
                    SetRemoteNodeSwitchSettingsCommand.SERIAL_KEY to serial,
                    SetRemoteNodeSwitchSettingsCommand.EISWITCH_KEY to
                            mapOf(
                                SetRemoteNodeSwitchSettingsCommand.ENABLED_KEY to enable,
                                SetRemoteNodeSwitchSettingsCommand.WATCHDOG_NODE_SERIAL_KEY to watchdogNodeSN,
                                SetRemoteNodeSwitchSettingsCommand.WATCHDOG_TIMEOUT_KEY to watchdogTimeout))
    }
}
