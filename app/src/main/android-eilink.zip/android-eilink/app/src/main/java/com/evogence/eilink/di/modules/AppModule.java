package com.evogence.eilink.di.modules;

import android.content.Context;

import com.evogence.eilink.EiLinkApplication;
import com.evogence.eilink.SystemPreferences;
import com.evogence.eilink.common.ConnectionData;
import com.evogence.eilink.common.SysInfo;
import com.evogence.eilink.controllers.authManager.AuthManager;
import com.evogence.eilink.controllers.apiServices.CentralAPIInterface;
import com.evogence.eilink.controllers.apiServices.CentralAPIService;
import com.evogence.eilink.controllers.nodesStorage.INodesStorage;
import com.evogence.eilink.controllers.nodesStorage.NodesStorage;
import com.evogence.eilink.screens.Navigator;
import com.evogence.eilink.screens.INavigator;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public class AppModule
{
    private Context context;
    private CentralAPIInterface apiService;
    private INavigator navigator;
    private SysInfo sysInfo;
    private AuthManager authManager;
    private SystemPreferences systemPreferences;
    private NodesStorage nodesStorage;

    public AppModule(Context context)
    {
        this.context = context;
    }

    @Provides
    public Context context()
    {
        return context;
    }

    @Provides
    @Singleton
    SysInfo provideSysInfo()
    {
        if(sysInfo == null)
            sysInfo = new SysInfo(context);

        return sysInfo;
    }

    @Provides
    @Singleton
    CentralAPIInterface provideCentralAPIService(ConnectionData connectionData, SysInfo sysInfo)
    {
        if(apiService == null)
            apiService = new CentralAPIService(connectionData, sysInfo.getUdid());

        return apiService;
    }

    @Provides
    @Singleton
    INavigator provideNavigateManagerInterface()
    {
        if(navigator == null)
            navigator = new Navigator();

        return navigator;
    }

    @Provides
    @Singleton
    AuthManager provideAuthManager()
    {
        if(authManager == null)
            authManager = new AuthManager(context);

        return authManager;
    }

    @Provides
    @Singleton
    SystemPreferences provideSystemPreferences()
    {
        if(systemPreferences == null)
            systemPreferences = new SystemPreferences(context);

        return systemPreferences;
    }

    @Provides
    @Singleton
    INodesStorage provideNodesStorage()
    {
        if(nodesStorage == null)
            nodesStorage = new NodesStorage();

        return nodesStorage;
    }

    @Provides
    @Singleton
    EiLinkApplication provideApplication()
    {
        return (EiLinkApplication) context;
    }
}