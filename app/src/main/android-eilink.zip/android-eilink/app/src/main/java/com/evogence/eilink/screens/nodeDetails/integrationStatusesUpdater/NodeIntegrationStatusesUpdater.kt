package com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater

import com.evogence.eilink.common.ConnectionData
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.controllers.nodeCommandSender.ENodeCommand
import com.evogence.eilink.controllers.nodeCommandSender.INodeCommandSender
import com.evogence.eilink.controllers.nodeCommandSender.NodeCommandSender
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetManagementServer
import com.evogence.eilink.models.node.Node
import io.reactivex.Flowable
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import java.util.concurrent.TimeUnit


/**
 * Created by Koren Vitalii on 10/5/2018.
 */
class NodeIntegrationStatusesUpdater(var node: Node): INodeIntegrationStatusesUpdater
{
    private var commandSender: INodeCommandSender = NodeCommandSender()
    private var timeInterval: Long = 20
    private var disposable: Disposable? = null
    private var completed: ((EConnectionStatus, EIntegrationServer)->Unit)? = null

    private var managementLastStatus = EConnectionStatus.UNDEFINED_STATUS
    private var reverseMonitoringLastStatus = EConnectionStatus.UNDEFINED_STATUS
    private var updateLastStatus = EConnectionStatus.UNDEFINED_STATUS

    override fun start(changedTo: ((EConnectionStatus, EIntegrationServer)->Unit)?)
    {
        managementLastStatus = EConnectionStatus.UNDEFINED_STATUS
        reverseMonitoringLastStatus = EConnectionStatus.UNDEFINED_STATUS
        updateLastStatus = EConnectionStatus.UNDEFINED_STATUS
        completed = changedTo
        send()
    }

    override fun stop()
    {
        disposable?.dispose()
        commandSender.cancel()
        completed = null
    }

    fun send()
    {
        disposable?.dispose()

        disposable = Flowable.interval(0, timeInterval, TimeUnit.SECONDS, Schedulers.io())
            .retry()
            .subscribe {sendGetDataCommands()}
    }

    private fun sendGetDataCommands()
    {
        commandSender.send(getDataCommands(), node, object: (ENodeCommand, CommandResult)->Unit()
        {
            override fun invoke(command: ENodeCommand, result: CommandResult)
            {
                parse(result, command)
            }
        }, object: ()->Unit()
        {
            override fun invoke()
            {
                sendCheckConnectionCommands()
            }
        })
    }

    private fun sendCheckConnectionCommands()
    {
        commandSender.send(getCheckConnectionCommands(), node, object: (ENodeCommand, CommandResult)->Unit()
        {
            override fun invoke(command: ENodeCommand, result: CommandResult)
            {
                parse(result, command)
            }
        }, object: ()->Unit()
        {
            override fun invoke()
            {
            }
        })
    }

    fun parse(result: CommandResult, command: ENodeCommand)
    {
        val connectionStatus = if(result.error == null) EConnectionStatus.CONNECTED_STATUS else EConnectionStatus.DISCONNECTED_STATUS
        when(command)
        {
            ENodeCommand.GET_MANAGEMENT_SERVER ->
            {
                if(connectionStatus == EConnectionStatus.CONNECTED_STATUS)
                    refreshNodeManagementServer(result)
            }
            ENodeCommand.GET_RM_SERVER ->
            {
                if(result.error == null)
                {
                    val params = result.params
                    node.supportServer.isUseTunnel = params["tunnel_enabled"] as Boolean
                    node.supportServer.tunnelAddress = params["tunnel_address"] as String
                }
            }
            ENodeCommand.GET_UPDATE_SERVER ->
            {
                if(result.error == null)
                {
                    val params = result.params
                    node.updateServer.isEnable = params["status"] as Boolean
                    node.updateServer.host = params["host"] as String
                }
            }
            ENodeCommand.CHECK_CONNECTION_MANAGEMENT_SERVER ->
            {
                if(managementLastStatus != connectionStatus)
                {
                    managementLastStatus = connectionStatus
                    completed?.invoke(connectionStatus, EIntegrationServer.CENTRAL_SERVER)
                }
            }
            ENodeCommand.CHECK_CONNECTION_RM_SERVER ->
            {
                if(reverseMonitoringLastStatus != connectionStatus)
                {
                    reverseMonitoringLastStatus = connectionStatus
                    completed?.invoke(connectionStatus, EIntegrationServer.SUPPORT_SERVER)
                }

            }
            ENodeCommand.CHECK_CONNECTION_UPDATE_SERVER ->
            {
                if(updateLastStatus != connectionStatus)
                {
                    updateLastStatus = connectionStatus
                    completed?.invoke(connectionStatus, EIntegrationServer.UPDATE_SERVER)
                }
            }
            else ->
            {
            }
        }
    }

    private fun getCheckConnectionCommands(): Map<ENodeCommand, Any?>
    {
        val commands = mutableMapOf<ENodeCommand, Any?>()

        if(node.centralServer.esEnable)
        {
            commands[ENodeCommand.CHECK_CONNECTION_MANAGEMENT_SERVER] = getManagementParams()
        }
        else if(managementLastStatus != EConnectionStatus.DISCONNECTED_STATUS)
        {
            managementLastStatus = EConnectionStatus.DISCONNECTED_STATUS
            completed?.invoke(EConnectionStatus.DISCONNECTED_STATUS, EIntegrationServer.CENTRAL_SERVER)
        }

        if(node.supportServer.isUseTunnel)
        {
            commands[ENodeCommand.CHECK_CONNECTION_RM_SERVER] = getReverseMonitoringParams()
        }
        else if(reverseMonitoringLastStatus != EConnectionStatus.DISCONNECTED_STATUS)
        {
            reverseMonitoringLastStatus = EConnectionStatus.DISCONNECTED_STATUS
            completed?.invoke(EConnectionStatus.DISCONNECTED_STATUS, EIntegrationServer.SUPPORT_SERVER)
        }

        if(node.updateServer.isEnable)
        {
            commands[ENodeCommand.CHECK_CONNECTION_UPDATE_SERVER] = getUpdateParams()
        }
        else if(updateLastStatus != EConnectionStatus.DISCONNECTED_STATUS)
        {
            updateLastStatus = EConnectionStatus.DISCONNECTED_STATUS
            completed?.invoke(EConnectionStatus.DISCONNECTED_STATUS, EIntegrationServer.UPDATE_SERVER)
        }

        return commands
    }

    private fun getDataCommands(): Map<ENodeCommand, Any?>
    {
        val commands = mutableMapOf<ENodeCommand, Any?>()
        if(node.centralServer.host.isEmpty())
            commands[ENodeCommand.GET_MANAGEMENT_SERVER] = null

        if(node.supportServer.tunnelAddress.isEmpty())
            commands[ENodeCommand.GET_RM_SERVER] = null

        if(node.updateServer.host.isEmpty())

            commands[ENodeCommand.GET_UPDATE_SERVER] = null

        return commands
    }

    private fun getManagementParams(): String?
    {
        return ConnectionData().build(ConnectionData.HTTP_KEY, node.centralServer.host, 80).host
    }

    private fun getReverseMonitoringParams(): String?
    {
        return ConnectionData().build(ConnectionData.HTTP_KEY, node.supportServer.tunnelAddress, 80).host
    }

    private fun getUpdateParams(): String?
    {
        return ConnectionData().build(ConnectionData.HTTP_KEY, node.updateServer.host, 80).host
    }

    private fun refreshNodeManagementServer(commandResult: CommandResult)
    {
        if(commandResult.params == null)
            return

        val nodeIntegrationInfo = node.centralServer
        val params = commandResult.params

        nodeIntegrationInfo.registrationToken = params[GetManagementServer.REGISTER_TOKEN_KEY] as? String ?: ""
        nodeIntegrationInfo.esTaskCompletionTimeout = params[GetManagementServer.TASK_TIMEOUT_KEY] as? Double ?: 0.0
        nodeIntegrationInfo.esEnable = params[GetManagementServer.IS_ES_ENABLE_KEY] as? Double ?: 0.0 == 1.0
        nodeIntegrationInfo.useEsAsUpdateServer = params[GetManagementServer.USE_ES_AS_UPDATE_SERVER_KEY] as? Double ?: 0.0 == 1.0
        nodeIntegrationInfo.useSFTP = params[GetManagementServer.USE_ES_SSH_CONNECTION_KEY] as? Double ?: 0.0 == 1.0
        val primaryES = params[GetManagementServer.PRIMARY_ES_KEY] as? Map<*, *>
        if(primaryES != null)
        {
            nodeIntegrationInfo.host = if(primaryES[GetManagementServer.HOST_KEY] is Boolean) "" else primaryES[GetManagementServer.HOST_KEY] as? String ?: ""
            nodeIntegrationInfo.httpPort = primaryES[GetManagementServer.HTTP_PORT_KEY] as? String ?: ""
            nodeIntegrationInfo.sshPort = primaryES[GetManagementServer.SSH_PORT_KEY] as? String ?: ""
            nodeIntegrationInfo.ftpPort = primaryES[GetManagementServer.FTP_PORT_KEY] as? String ?: ""
        }
        val secondaryES = params[GetManagementServer.SECONDARY_ES_KEY] as? Map<*, *>
        if(secondaryES != null)
        {
            nodeIntegrationInfo.secondaryHost = if(secondaryES[GetManagementServer.HOST_KEY] is Boolean) "" else secondaryES[GetManagementServer.HOST_KEY] as? String ?: ""
            nodeIntegrationInfo.secondaryHTTPPort = secondaryES[GetManagementServer.HTTP_PORT_KEY] as? String ?: ""
            nodeIntegrationInfo.secondarySSHPort = secondaryES[GetManagementServer.SSH_PORT_KEY] as? String ?: ""
            nodeIntegrationInfo.secondaryFTPPort = secondaryES[GetManagementServer.FTP_PORT_KEY] as? String ?: ""
        }

        nodeIntegrationInfo.updateTimestamp = System.currentTimeMillis()
    }
}