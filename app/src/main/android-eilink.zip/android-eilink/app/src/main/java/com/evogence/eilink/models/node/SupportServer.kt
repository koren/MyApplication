package com.evogence.eilink.models.node

import com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater.EConnectionStatus

/**
 * Created by Koren Vitalii on 8/21/2018.
 */
class SupportServer
{
    var isUseTunnel: Boolean = false
    var tunnelAddress: String = ""
    var updateTimestamp: Long = 0

    var connectedStatus = EConnectionStatus.UNDEFINED_STATUS
}