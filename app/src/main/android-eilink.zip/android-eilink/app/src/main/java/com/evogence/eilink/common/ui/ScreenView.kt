package com.evogence.eilink.common.ui

import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.inputmethod.InputMethodManager
import com.evogence.eilink.MainActivity
import com.evogence.eilink.common.dialogs.AlertDialogFragment

/**
 * Created by Anatolij on 9/28/18.
 */
abstract class ScreenView: IScreenView, Fragment()
{
    override fun showProgress(processing: String)
    {
        (activity as MainActivity).showProgress(processing)
    }

    override fun hideProgress()
    {
        (activity as MainActivity).hideProgress()
    }

    override fun hideKeyboard()
    {
        val imm = activity?.getSystemService(AppCompatActivity.INPUT_METHOD_SERVICE) as InputMethodManager
        if(activity?.currentFocus != null)
            imm.hideSoftInputFromWindow(activity?.currentFocus?.windowToken, 0)
    }

    override fun showAlertDialog(title: String, message: String, observer: AlertDialogFragment.DialogResultObserver?, showPositiveButton: Boolean, showNegativeButton: Boolean)
    {
        val dialog = AlertDialogFragment.getInstance(title, message, showPositiveButton, showNegativeButton)
        observer?.let {dialog.setObserver(it)}
        fragmentManager?.let {dialog.show(it)}
    }

    override fun showAlertDialog(title: String, message: String)
    {
        showAlertDialog(title, message, null, true, false)
    }

    override fun finish()
    {
        activity?.finish()
    }
}