package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive

/**
 * Created by Koren Vitalii on 9/4/2018.
 */
class SetDisconnectNodeCommand(parameters: Any?): INodeCommand
{
    override val method: String = "Integration.RPN.settings.ContextualDeviceService::unpairEiNode"
    override val desc: String = "Unpair [Ei] Node"
    override var params: MutableMap<String, Any> = mutableMapOf()

    companion object MapKeys
    {
        const val STATUS_KEY = "status"
    }

    init
    {
        if(parameters != null)
            params[SetPairNodeCommand.PARAMS_KEY] = parameters
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonObject)?.has(STATUS_KEY) ?: false && !(((response.result as? JsonObject)?.get(STATUS_KEY) as? JsonPrimitive)?.asString ?: "").isEmpty()
    }
}