package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.JsonPrimitive

class RebootAndShutdownCommand(parameters: Any?): INodeCommand
{
    override val method: String = "Integration.RPN.settings.SystemService::setReboot"
    override val desc: String get() = this.type
    override var params: MutableMap<String, Any> = HashMap()
    var type: String = ""

    companion object MapKeys
    {
        const val PARAMS_KEY = "params"
        const val TYPE_KEY = "type"
    }

    init
    {
        if(parameters is String)
        {
            params[PARAMS_KEY] = mapOf("params" to mapOf(TYPE_KEY to parameters))
            type = parameters
        }
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonPrimitive)?.isBoolean ?: false
    }

    override fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()
        val result = (response.result as? JsonPrimitive)?.isBoolean ?: false
        if(!result)
        {
            if((response.error) != null && (response.error!!.message != null))
            {
                commandResult.error = response.error!!.message
            }
            else
            {
                commandResult.error = ""
            }
        }
        return commandResult
    }
}
