package com.evogence.eilink.screens.nodeList.tabs

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import com.evogence.eilink.screens.nodeList.NodeListItemHolder
import com.evogence.eilink.screens.nodeList.NodeListItemVM
import com.evogence.eilink.screens.nodeList.NodeListView
import kotlinx.android.synthetic.main.node_list_tab_item.*

/**
 * Created by Koren Vitalii on 9/5/2018.
 */
class NodeListTabView: Fragment()
{
    private var adapter: NodeListAdapter? = null
    private var nodes: List<NodeListItemVM> = ArrayList()
    private var nodeListView: NodeListView? = null

    companion object
    {
        fun build(listView: NodeListView): NodeListTabView
        {
            var instance = NodeListTabView()
            instance.setNodeListView(listView)
            return instance
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.node_list_tab_item, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        initView()

        super.onViewCreated(view, savedInstanceState)
    }

    private fun initView()
    {
        if((activity != null) && (nodeListView != null))
        {
            adapter = NodeListAdapter(activity!!, nodeListView!!)
            adapter?.setList(nodes)
            adapter?.notifyDataSetChanged()
            recyclerView.layoutManager = LinearLayoutManager(context)
            recyclerView.adapter = adapter

            recyclerView.addOnItemTouchListener(object: RecyclerView.OnItemTouchListener
            {
                override fun onTouchEvent(rv: RecyclerView?, e: MotionEvent?)
                {
                }

                override fun onInterceptTouchEvent(rv: RecyclerView?, e: MotionEvent?): Boolean
                {
                    return e?.x?.compareTo(10F) ?: 0 == -1
                }

                override fun onRequestDisallowInterceptTouchEvent(disallowIntercept: Boolean)
                {
                }
            })
        }
    }

    fun setList(nodes: List<NodeListItemVM>)
    {
        this.nodes = nodes
        adapter?.setList(nodes)
        adapter?.notifyDataSetChanged()
    }

    fun setNodeListView(nodeListView: NodeListView)
    {
        this.nodeListView = nodeListView
    }

    fun notifyDataSetChanged()
    {
        adapter?.notifyDataSetChanged()
    }

    private class NodeListAdapter internal constructor(private val context: Context, private val nodeListView: NodeListView): RecyclerView.Adapter<RecyclerView.ViewHolder>()
    {
        private var nodes: List<NodeListItemVM> = ArrayList()

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder
        {
            return NodeListItemHolder(LayoutInflater.from(context), parent, nodeListView)
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int)
        {
            (holder as NodeListItemHolder).bind(nodes[position])
        }

        override fun getItemCount(): Int
        {
            return nodes.size
        }

        fun setList(nodes: List<NodeListItemVM>)
        {
            this.nodes = nodes
        }
    }
}