package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.google.gson.JsonObject

class SetUpNetSettingsCommand(parameters: Any?): INodeCommand
{
    override val method: String = "Integration.RPN.settings.ProfilerService::setNetworkSettings"
    override val desc: String = "Set Mode Configuration"

    override var params: MutableMap<String, Any> = HashMap()

    companion object MapKeys
    {
        val PARAMS_KEY: String = "params"

        const val HOST_KEY = "host"
        const val ETHERNET_KEY = "ethernet"
        const val WIFI_KEY = "wifi"
        const val IPDHCP_KEY = "ipdhcp"
        const val IPDNS1_KEY = "ipdns1"
        const val IPDNS2_KEY = "ipdns2"
        const val IPDNS3_KEY = "ipdns3"
        const val IPADDRESS_KEY = "ipaddress"
        const val IPNETMASK_KEY = "ipnetmask"
        const val IPGATEWAY_KEY = "ipgateway"
        const val IPVERSION_KEY = "ipversion"
        const val WIFI_PREFERRED_KEY = "wifi_preferred"
        const val IPDHCP1_KEY = "ipdhcp1"
        const val WIFI_ENABLED_KEY = "wifi_enabled"
        const val SSID_KEY = "ssid"
        const val SECURITY_PROTOCOL_KEY = "security_protocol"
        const val AUTH_IDENTITY_KEY = "auth_identity"
        const val AUTH_KEY = "auth_key"
        const val AUTH_PASSWORD_KEY = "auth_password"
        const val AUTH_PRIVATE_KEY_PASSWD_KEY = "auth_private_key_passwd"
        const val IPADDRESS1_KEY = "ipaddress1"
        const val IPNETMASK1_KEY = "ipnetmask1"
        const val IPGATEWAY1_KEY = "ipgateway1"
        const val IPVERSION1_KEY = "ipversion1"
    }

    init
    {
        if(parameters is Map<*, *>)
            params[PARAMS_KEY] = parameters
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonObject)?.has(ETHERNET_KEY) ?: false && (response.result as? JsonObject)?.has(WIFI_KEY) ?: false
    }
}