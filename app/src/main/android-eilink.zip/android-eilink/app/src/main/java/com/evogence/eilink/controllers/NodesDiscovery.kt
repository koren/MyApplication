package com.evogence.eilink.controllers

import android.content.Context
import android.os.Build
import android.os.CountDownTimer
import com.evogence.eilink.models.node.Node
import com.evogence.eilink.models.node.NodeSyncStatus
import com.github.druk.rx2dnssd.BonjourService
import com.github.druk.rx2dnssd.Rx2DnssdEmbedded
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers

/**
 * Created by Koren Vitalii on 8/8/2018.
 */
class NodesDiscovery(val context: Context)
{
    companion object
    {
        private const val SERVICE_TYPE = "_http._tcp"
        private const val PORT = 9000
        private const val TIMER_PERIOD = 3000L
        private const val MAX_TIMER_PERIOD = 20000L
    }

    val nodeList: MutableList<Node> = mutableListOf()
    private var completion: ((List<Node>)->Unit)? = null
    private val rxDnssd: Rx2DnssdEmbedded = Rx2DnssdEmbedded(context)
    private var registerDisposable: Disposable? = null
    private var browseDisposable: Disposable? = null
    private var waitTimer: CountDownTimer? = null
    private var maxTimeWaitTimer: CountDownTimer? = null

    fun searchDevices(completion: (List<Node>)->Unit)
    {
        this.completion = completion
        registerService(PORT)
    }

    private fun registerService(port: Int)
    {
        completion?.invoke(getFakeNodes()) //todo for tests
        return//todo for tests
        val bs = BonjourService.Builder(0, 0, Build.DEVICE, SERVICE_TYPE, null).port(port).build()
        registerDisposable = rxDnssd.register(bs)
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe {_->
                startMaxTimeTimer(MAX_TIMER_PERIOD)
                {
                    stopTimer()
                    completion?.invoke(nodeList)
                    unregisterService()

                }
                browseDisposable = rxDnssd.browse(SERVICE_TYPE, "local.")
                    .compose(rxDnssd.resolve())
                    .compose(rxDnssd.queryRecords())
                    .subscribeOn(Schedulers.io())
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribe({bonjourService->
                        if (!(bonjourService.txtRecords.isNotEmpty() && bonjourService.txtRecords["vendor"]?.contains("Ei") == true))
                            return@subscribe

                        stopTimer()
                        startTimer(TIMER_PERIOD)
                        {
                            stopTimer()
                            completion?.invoke(nodeList)
                            unregisterService()
                        }
                        if(bonjourService.isLost)
                        {
                            nodeList.forEach {node->
                                val host = if(bonjourService.inetAddresses.size > 0)
                                    bonjourService.inetAddresses[0].hostAddress
                                else
                                    ""

                                if((node.port == bonjourService.port) && (node.host == host))
                                    nodeList.remove(node)
                            }
                        }
                        else
                        {
                            val node = Node()
                            node.port = bonjourService.port
                            node.host = bonjourService.hostname.toString()
                            if(bonjourService.inetAddresses.size > 0)
                                node.address = bonjourService.inetAddresses[0].hostAddress

                            bonjourService.txtRecords.forEach {(key, value)->
                                when(key)
                                {
                                    "fingerprint" -> node.fingerprint = value
                                    "productid" -> node.model = value
                                    "serial" -> node.sn = value
                                    "sid" -> node.sid = value
                                    "title" -> node.title = value
                                    "version" -> node.version = value
                                }
                            }

                            if(node.address.isEmpty())
                                node.address = node.host

                            if(node.host.isEmpty())
                                node.host = node.address

                            if(node.fingerprint.isNotEmpty() && node.address.isNotEmpty())
                                nodeList.add(node)
                        }
                    }, {})
            }
    }

    private fun unregisterService()
    {
        if(registerDisposable?.isDisposed == true)
            registerDisposable?.dispose()

        if(browseDisposable?.isDisposed == true)
            browseDisposable?.dispose()
    }

    private fun startTimer(period: Long, function: ()->Unit)
    {
        waitTimer = object: CountDownTimer(period, period)
        {

            override fun onTick(millisUntilFinished: Long)
            {
            }

            override fun onFinish()
            {
                function.invoke()
            }
        }.start()
    }

    private fun startMaxTimeTimer(period: Long, function: ()->Unit)
    {
        maxTimeWaitTimer = object: CountDownTimer(period, period)
        {

            override fun onTick(millisUntilFinished: Long)
            {
            }

            override fun onFinish()
            {
                function.invoke()
            }
        }.start()
    }

    private fun stopTimer()
    {
        maxTimeWaitTimer?.cancel()
        maxTimeWaitTimer = null

        waitTimer?.cancel()
        waitTimer = null
    }

    private fun getFakeNodes(): List<Node>
    {
        val result = ArrayList<Node>()

        var node = Node()
        node.fingerprint = "755877a67cce9c6ef8bb70559ba9e7e1"
        node.title = "222"
        node.sn = "678678679789"
        node.port = 80
        node.sid = "G43507R001239"
        node.model = "s1137"
        node.host = "192.168.101.222"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.101.222"
        node.version = "4.0.1.p1"
        result.add(node)

        node = Node()
        node.fingerprint = "ee6f83be4b723d43d92b5c6c75551da7"
        node.title = "192.168.101.117"
        node.sn = "45756778678"
        node.port = 80
        node.sid = "G46230R003626"
        node.host = "192.168.101.117"
        node.model = "s2117f"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.101.117"
        result.add(node)

        node = Node()
        node.fingerprint = "386f043c2c27c518932866afb9fc8a39"
        node.title = "192.168.101.157"
        node.sn = "45787544577"
        node.port = 80
        node.model = "asme_android"
        node.host = "192.168.101.157"
        node.sid = "H17658R000179"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.101.157"
        result.add(node)

        node = Node()
        node.fingerprint = "004ea82006d629fd9bce1d2db974f455"
        node.title = "Ei Node"
        node.sn = "19216815054"
        node.port = 80
        node.model = "eic100"
        node.host = "192.168.150.54"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.54"
        node.version = "4.0.0.p.1 D"
        result.add(node)

        node = Node()
        node.fingerprint = "55a31e4b47f2ba9f4c048ce71fe80617"
        node.title = "192.168.150.52"
        node.sn = "54578755665436"
        node.port = 80
        node.model = "s1137"
        node.host = "192.168.150.52"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.52"
        node.version = "4.0.2 D"
        result.add(node)

        node = Node()
        node.title = "192.168.150.55"
        node.address = "192.168.150.55"
        node.model = "e2225"
        node.version = "4.0.2.p.1_dev D"
        node.sn = "19216815055"
        node.sid = "50026B7223016326"
        node.fingerprint = "34b61ddb98b575b30e6c468164d34f67"
        node.port = 80
        node.host = "192.168.150.55"
        node.syncStatus = NodeSyncStatus()
        result.add(node)


        node = Node()
        node.fingerprint = "444b7a755c32fd16ba0fd806981ac5ba"
        node.title = "192.168.150.51"
        node.sn = "876t8754573453"
        node.port = 80
        node.model = "s2117f"
        node.host = "192.168.150.51"
        node.sid = "161523400118"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.51"
        node.version = "4.0.2.p.1_dev D"
        node.edition = "advanced"
        node.location = "EVD Location 111"
        result.add(node)

        return result
    }

    private fun getTestNodes(): List<Node>
    {
        val result = ArrayList<Node>()

        var node = Node()
        node.fingerprint = "34b61ddb98b575b30e6c468164d34f67"
        node.title = "[Ei]-Node"
        node.sn = "19216815055"
        node.port = 80
        node.sid = "50026B7223016326"
        node.model = "e2225"
        node.host = "192.168.150.55"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.55"
        node.version = "4.0.2.p.1_dev D"
        result.add(node)

        node = Node()
        node.fingerprint = "004ea82006d629fd9bce1d2db974f455"
        node.title = "Ei Node2"
        node.sn = "370528"
        node.port = 80
        node.sid = "370528"
        node.host = "192.168.150.54"
        node.model = "eic100"
        node.syncStatus = NodeSyncStatus()
        node.address = "192.168.150.54"
        result.add(node)

        return result
    }
}