package com.evogence.eilink.screens.nodeDetails.tabs.performanceTab

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import kotlinx.android.synthetic.main.node_details_performance_temp_and_load.view.*


/**
 * Created by Koren Vitalii on 07/31/18.
 */
class LoadAndTempHolder(val inflater: LayoutInflater, parent: ViewGroup): RecyclerView.ViewHolder(inflater.inflate(R.layout.node_details_performance_temp_and_load, parent, false))
{
    fun bind(viewModel: CPUAndTempProgressVM)
    {
        itemView.loadContainer.visibility = if(viewModel.useLoad) View.VISIBLE else View.GONE

        itemView.titleTV.text = viewModel.title
        itemView.tempPB.progress = viewModel.tempProgress
        itemView.tempValueTV.text = String.format("%s%s", viewModel.tempValue, viewModel.tempSymbol)
        if(viewModel.tempValue == 0.0)
            itemView.tempValueTV.text = "N/A"

        itemView.loadPB.progress = viewModel.loadProgress

        itemView.loadValueTV.text = String.format("%s%s", viewModel.loadValue, viewModel.loadSymbol)
        if(viewModel.loadValue == 0.0)
            itemView.loadValueTV.text = "N/A"

        when
        {
            viewModel.tempProgress < 50 -> itemView.tempPB.progressDrawable = inflater.context.getDrawable(R.drawable.progess_drawable_new_green)
            viewModel.tempProgress < 90 -> itemView.tempPB.progressDrawable = inflater.context.getDrawable(R.drawable.progess_drawable_new_yellow)
            viewModel.tempProgress >= 90 -> itemView.tempPB.progressDrawable = inflater.context.getDrawable(R.drawable.progess_drawable_new_red)
        }

        when
        {
            viewModel.loadProgress < 50 -> itemView.loadPB.progressDrawable = inflater.context.getDrawable(R.drawable.progess_drawable_new_green)
            viewModel.loadProgress < 90 -> itemView.loadPB.progressDrawable = inflater.context.getDrawable(R.drawable.progess_drawable_new_yellow)
            viewModel.loadProgress >= 90 -> itemView.loadPB.progressDrawable = inflater.context.getDrawable(R.drawable.progess_drawable_new_red)
        }
    }
}
