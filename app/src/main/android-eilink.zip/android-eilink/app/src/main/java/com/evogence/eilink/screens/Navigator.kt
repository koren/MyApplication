package com.evogence.eilink.screens

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v7.app.AppCompatActivity
import com.evogence.eilink.R
import com.evogence.eilink.screens.about.AboutView
import com.evogence.eilink.screens.authorization.AuthView
import com.evogence.eilink.screens.nodeDetails.NodeDetailsView
import com.evogence.eilink.screens.nodeDetails.tabs.integrationTab.NodeIntegrationView
import com.evogence.eilink.screens.nodeList.NodeListView
import com.evogence.eilink.screens.nodeList.groupOperations.EGroupOperation
import com.evogence.eilink.screens.nodeList.groupOperations.GroupOperationView

/**
 * Created by Koren Vitalii on 19.04.2018.
 */
class Navigator: INavigator
{
    private var fragmentManager: FragmentManager? = null
    private var activity: AppCompatActivity? = null

    private val currentFragment: Fragment
        get()
        {
            val fragmentTag = fragmentManager!!.getBackStackEntryAt(fragmentManager!!.backStackEntryCount - 1).name
            return fragmentManager!!.findFragmentByTag(fragmentTag)
        }

    override fun navigateToAbout()
    {
        addFragment(AboutView.build())
    }

    override fun navigateToAuthorization()
    {
        for(i in 0 until fragmentManager!!.backStackEntryCount)
        {
            fragmentManager?.popBackStack()
        }
        addFragmentWithoutStack(AuthView.build())
    }

    override fun getBackStackEntryCount(): Int
    {
        return fragmentManager!!.backStackEntryCount
    }

    override fun back()
    {
        if(fragmentManager!!.backStackEntryCount > 1)
        {
            fragmentManager!!.popBackStack()
        }
    }

    override fun navigateToNodeList()
    {
        val currentFragment = fragmentManager!!.findFragmentById(R.id.fragment_frame)
        if((currentFragment == null) || (currentFragment !is NodeListView))
            addFragment(NodeListView.build())
    }

    override fun navigateToNodeDetails(fingerprint: String)
    {
        val currentFragment = fragmentManager!!.findFragmentById(R.id.fragment_frame)
        if((currentFragment == null) || (currentFragment !is NodeDetailsView))
            addFragment(NodeDetailsView.newInstance(fingerprint))
    }

    override fun navigateToNodeIntegrationTab(fingerprint: String)
    {
        val currentFragment = fragmentManager!!.findFragmentById(R.id.fragment_frame)
        if((currentFragment == null) || (currentFragment !is NodeIntegrationView))
            addFragment(NodeIntegrationView.build(fingerprint))
    }

    override fun navigateToGroupOperation(fingerprints: Array<String>, integration: EGroupOperation)
    {
        val currentFragment = fragmentManager!!.findFragmentById(R.id.fragment_frame)
        if((currentFragment == null) || (currentFragment !is GroupOperationView))
            addFragment(GroupOperationView.build(fingerprints, integration))
    }

    override fun prepare(activity: AppCompatActivity)
    {
        this.activity = activity
        this.fragmentManager = activity.supportFragmentManager
    }

    private fun addFragment(fragment: Fragment)
    {
        val currentFragment = fragmentManager!!.findFragmentById(R.id.fragment_frame)
        if(currentFragment == null)
        {
            fragmentManager!!
                .beginTransaction()
                .add(R.id.fragment_frame, fragment, fragment.javaClass.name)
                .addToBackStack(fragment.javaClass.name)
                .commit()
        }
        else
        {
            fragmentManager!!
                .beginTransaction()
                .replace(R.id.fragment_frame, fragment, fragment.javaClass.name)
                .addToBackStack(fragment.javaClass.name)
                .commit()
        }
    }

    private fun addFragmentWithoutStack(fragment: Fragment)
    {
        val currentFragment = fragmentManager!!.findFragmentById(R.id.fragment_frame)
        if(currentFragment == null)
        {
            fragmentManager!!
                .beginTransaction()
                .add(R.id.fragment_frame, fragment, fragment.javaClass.name)
                .commit()
        }
        else
        {
            fragmentManager!!
                .beginTransaction()
                .replace(R.id.fragment_frame, fragment, fragment.javaClass.name)
                .commit()
        }
    }
}

