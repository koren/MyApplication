package com.evogence.eilink.screens.nodeDetails.tabs.performanceTab

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup

/**
 * Created by Koren Vitalii on 07/31/18.
 */
class ProgressBarTempAndLoadAdapter(val context: Context, private val items: List<CPUAndTempProgressVM>): RecyclerView.Adapter<RecyclerView.ViewHolder>()
{
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder
    {
        val layoutInflater = LayoutInflater.from(context)
        return LoadAndTempHolder(layoutInflater, parent)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int)
    {
        (holder as LoadAndTempHolder).bind(items[position])
    }

    override fun getItemCount(): Int
    {
        return items.size
    }
}
