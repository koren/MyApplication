package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab

/**
 * Created by Koren Vitalii on 8/30/2018.
 */
class ListItemVM
{
    var title: String = ""
    var ip: String = ""
    var serialNumber: String = ""
    var model: String = ""
    var version: String = ""
    var iconName: String = ""
}