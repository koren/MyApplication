package com.evogence.eilink.screens.about

import com.evogence.eilink.EiLinkApplication
import com.evogence.eilink.common.SysInfo
import com.evogence.eilink.controllers.authManager.AuthManager
import com.evogence.eilink.screens.INavigator
import javax.inject.Inject

/**
 * Created by Koren Vitalii on 05/30/18.
 */
internal class AboutPresenter
{
    private var view: AboutView? = null
    private val viewModel: AboutVM

    @Inject lateinit var navigator: INavigator
    @Inject lateinit var authManager: AuthManager
    @Inject lateinit var sysInfo: SysInfo

    init
    {
        EiLinkApplication.appComponent.inject(this)
        this.viewModel = AboutVM()
    }

    fun onAttachView(view: AboutView)
    {
        this.view = view
        prepareViewModel()
        view.fill(viewModel)
    }

    fun onDetachView()
    {
        view = null
    }

    fun onBack()
    {
        navigator.back()
    }

    fun prepareViewModel()
    {
        val memoryInfo = sysInfo.memoryInfo
        viewModel.version = sysInfo.shortVersion
        viewModel.usedSpace = String.format("%.2f GB of %.2f GB Used", (memoryInfo.totalFlash.toFloat() - memoryInfo.availableFlash.toFloat())/1024.0/1024.0, memoryInfo.totalFlash.toFloat()/1024.0/1024.0)
        viewModel.usedSpaceProgress = ((memoryInfo.totalFlash - memoryInfo.availableFlash) * 100 / memoryInfo.totalFlash).toInt()
    }

    fun onLogout()
    {
        authManager.logout()
        navigator.navigateToAuthorization()
    }
}
