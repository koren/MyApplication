package com.evogence.eilink.controllers.nodeCommandSender;

import java.util.Map;

public class CommandResult
{
    public String error;
    public Map<String, Object> params;
    public boolean isSupported = true;

    public CommandResult(String error)
    {
        this.error = error;
    }

    public CommandResult(Map result)
    {
        this.params = result;
    }

    public CommandResult()
    {

    }
}