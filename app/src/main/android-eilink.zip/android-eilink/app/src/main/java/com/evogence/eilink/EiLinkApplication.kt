package com.evogence.eilink

import android.app.Application
import android.support.v7.app.AppCompatActivity
import com.evogence.eilink.common.EConnectionType
import com.evogence.eilink.common.SysInfo
import com.evogence.eilink.controllers.NodesDiscovery
import com.evogence.eilink.controllers.authManager.AuthManager
import com.evogence.eilink.controllers.nodesStorage.INodesStorage
import com.evogence.eilink.di.AppComponent
import com.evogence.eilink.di.DaggerAppComponent
import com.evogence.eilink.di.modules.AppModule
import com.evogence.eilink.screens.INavigator
import javax.inject.Inject

/**
 * Created by Koren Vitalii on 17.04.2018.
 */

class EiLinkApplication: Application()
{
    private lateinit var nodesDiscovery: NodesDiscovery
    @Inject lateinit var nodesStorage: INodesStorage
    @Inject lateinit var navigator: INavigator
    @Inject lateinit var authManager: AuthManager
    @Inject lateinit var sysInfo: SysInfo

    companion object
    {
        @JvmStatic lateinit var appComponent: AppComponent
            private set
    }

    override fun onCreate()
    {
        super.onCreate()
        appComponent = DaggerAppComponent.builder().appModule(AppModule(this)).build()
        EiLinkApplication.appComponent.inject(this)
        nodesDiscovery = NodesDiscovery(this)
    }

    fun start(activity: AppCompatActivity)
    {
        navigator.prepare(activity)

        if(authManager.isAuth())
            navigator.navigateToNodeList()
        else
            navigator.navigateToAuthorization()
    }

    fun canSearchLocalDevice(): Boolean
    {
        //return true
        return sysInfo.getConnectionType(applicationContext) == EConnectionType.WIFI
    }

    fun findLocalDevice()
    {
        nodesDiscovery.searchDevices {nodesStorage.refreshLocalNodes(it)}
    }
}
