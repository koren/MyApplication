package com.evogence.eilink.screens.nodeDetails.tabs.integrationTab

interface INodeIntegrationPresenter
{
    fun checkConnectionManagementServer()
    fun checkConnectionReverseMonitoringServer()
    fun checkConnectionUpdateServer()
}
