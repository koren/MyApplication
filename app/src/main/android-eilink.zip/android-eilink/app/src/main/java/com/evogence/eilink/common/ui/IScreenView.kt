package com.evogence.eilink.common.ui

import com.evogence.eilink.common.dialogs.AlertDialogFragment

/**
 * Created by Anatolij on 9/28/18.
 */
interface IScreenView
{
    fun fill(model: Any)

    fun showProgress(processing: String)
    fun hideProgress()
    fun hideKeyboard()
    fun showAlertDialog(title: String = "", message: String, observer: AlertDialogFragment.DialogResultObserver?, showPositiveButton: Boolean, showNegativeButton: Boolean)
    fun showAlertDialog(title: String = "", message: String)
    fun finish()
}