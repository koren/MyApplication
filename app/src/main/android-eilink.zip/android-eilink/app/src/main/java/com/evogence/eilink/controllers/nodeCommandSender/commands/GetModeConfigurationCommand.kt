package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.controllers.nodeCommandSender.EPairState
import com.evogence.eilink.controllers.nodeCommandSender.EPairType
import com.evogence.eilink.controllers.nodeCommandSender.ModeConfiguration
import com.evogence.eilink.models.node.ENodeOnlineStatus
import com.google.gson.JsonObject

class GetModeConfigurationCommand: INodeCommand
{
    override val method: String = "Integration.RPN.settings.ContextualDeviceService::getAuxControllerSettings"
    override val desc: String = "Get Mode Configuration"

    override var params: MutableMap<String, Any> = HashMap()

    companion object MapKeys
    {
        const val MODE_KEY = "mode"
        const val PAIR_STATE_KEY = "pair_state"
        const val SERIAL_LIST_KEY = "serial_list"
        const val SERIAL_MANUAL_KEY = "serial_manual"
        const val TYPE_LINK_KEY = "type_link"
        const val PAIR_KEY = "pair"
        const val IP_KEY = "ip"
        const val EDITION_KEY = "edition"
        const val MODEL_KEY = "model"
        const val SYSTEMID_KEY = "systemid"
        const val TITLE_KEY = "title"
        const val VERSION_KEY = "version"
        const val STATUS_KEY = "status"
        const val CONTROLLERS_KEY = "controllers"
        const val ACTION_KEY = "action"
        const val TYPE_KEY = "type"
        const val PARAMS_KEY = "params"
        const val NODEIP_KEY = "nodeip"
        const val NODE_TITLE_KEY = "node_title"
        const val FINGERPRINT_KEY = "fingerprint"
        const val SERIAL_KEY = "serial"
        const val TIMEOUT_KEY = "timeout"
        const val AUX_KEY = "aux"
        const val DISCONNECT = "disconnect"
        const val TYPE = "ei_switch_20"

        fun prepareResult(commnadResult: CommandResult): ModeConfiguration //todo anl: why ModeConfiguration
        {
            val result = commnadResult.params
            val modeConfiguration = ModeConfiguration()
            if(result == null)
                return modeConfiguration

            modeConfiguration.snList = result[SERIAL_LIST_KEY] as? String ?: ""
            modeConfiguration.snManual = result[SERIAL_MANUAL_KEY] as? String ?: ""
            modeConfiguration.typeLink = if(EPairType.MANUALY.value == result[TYPE_LINK_KEY] as? String) EPairType.MANUALY else EPairType.LIST
            modeConfiguration.pairState = if(EPairState.PAIR.value == (result[PAIR_STATE_KEY] as? String)) EPairState.PAIR else EPairState.UNPAIR
            modeConfiguration.mode = result[MODE_KEY] as? String ?: ""
            val pair = result[PAIR_KEY]as? Map<*, *>
            val controllers = result[CONTROLLERS_KEY] as? Map<*, *>
            val aux = controllers?.get(AUX_KEY) as? ArrayList<*>
            if(pair != null)
            {
                modeConfiguration.ip = pair[IP_KEY] as? String ?: ""
                modeConfiguration.edition = pair[EDITION_KEY]as? String ?: ""
                modeConfiguration.model = pair[MODEL_KEY]as? String ?: ""
                modeConfiguration.systemID = pair[SYSTEMID_KEY]as? String ?: ""
                modeConfiguration.title = pair[TITLE_KEY]as? String ?: ""
                modeConfiguration.version = pair[VERSION_KEY]as? String ?: ""
                modeConfiguration.onlineStatus = ENodeOnlineStatus.get(pair[STATUS_KEY]as? String ?: "")
                modeConfiguration.pairSN = pair[SERIAL_KEY]as? String ?: ""
            }

            var isFound = false

            if(controllers != null && aux != null)
            {
                aux.forEach()
                {it->
                    if(it is Map<*, *>)
                    {
                        val actions = it[ACTION_KEY] as? ArrayList<*>
                        if(actions != null)
                        {
                            actions.forEach {
                                if(it is Map<*, *>)
                                {
                                    val type = it[TYPE_KEY] as? String
                                    if((type != null) && (type == TYPE))
                                    {
                                        val actionParams = it[PARAMS_KEY] as? Map<*, *>
                                        isFound = true
                                        modeConfiguration.isEnablePort = true
                                        if(actionParams != null)
                                        {
                                            modeConfiguration.timeout = actionParams[TIMEOUT_KEY] as? Double ?: 0.0
                                            modeConfiguration.isEnableWatchdog = modeConfiguration.timeout > 0
                                        }
                                    }
                                    if(isFound)
                                        return@forEach
                                }
                            }
                        }
                    }
                    if(isFound)
                        return@forEach
                }
            }
            return modeConfiguration
        }
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return response.result is JsonObject
    }
}