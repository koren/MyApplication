package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

interface INodeCommand
{
    val method: String
    val desc: String

    var params: MutableMap<String, Any>

    fun isCorrectResponse(response: JsonRpcResponse): Boolean
    fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()

        val type = object: TypeToken<Map<String, Any?>>()
        {

        }.type
        val gson = Gson()
        val mapResult = gson.fromJson<Map<String, Any?>>(response.result, type)

        commandResult.params = mapResult
        return commandResult
    }
}
