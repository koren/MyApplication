package com.evogence.eilink.common

/**
 * Created by Koren Vitalii on 8/8/2018.
 */
enum class EMeridium(val title: String)
{
    AM("AM"),
    PM("PM");

    companion object
    {
        fun get(name: String): EMeridium
        {
            EMeridium.values().forEach {
                if(it.title == name)
                    return it
            }
            return AM
        }
    }
}