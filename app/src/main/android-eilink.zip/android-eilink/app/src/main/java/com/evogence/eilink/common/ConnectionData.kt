package com.evogence.eilink.common

open class ConnectionData
{
    companion object
    {
        const val HTTP_KEY: String = "http"
        const val HTTPS_KEY: String = "https"
    }

    var scheme: String? = null
    var host: String? = null
    var port: Int? = 0

    fun build(scheme: String?, host: String?, port: Int?): ConnectionData
    {
        this.scheme = scheme
        this.host = host
        this.port = port
        return this
    }

    fun getFullAddress(): String
    {
        return if(this.port in 1..65534)
            "$scheme://$host:$port"
        else
            "$scheme://$host"
    }

//    fun isEqual(connectionData: ConnectionData?): Boolean
//    {
//        return false
//    }
//
//    fun isSSL(): Boolean
//    {
//        return (this.scheme == HTTPS_KEY)
//    }
//
//    fun isValid(): Boolean
//    {
//        return host?.isNotEmpty() ?: false
//    }
}