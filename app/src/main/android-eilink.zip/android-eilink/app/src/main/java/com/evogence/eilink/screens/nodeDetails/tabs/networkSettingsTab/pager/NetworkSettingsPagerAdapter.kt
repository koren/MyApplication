package com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.pager

import android.content.Context
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.view.LayoutInflater
import android.view.View
import com.evogence.eilink.R
import kotlinx.android.synthetic.main.custom_tab.view.*

/**
 * Created by Koren Vitalii on 9/24/2018.
 */
class NetworkSettingsPagerAdapter(val context: Context, val items: List<NetworkSettingsPage>, fm: FragmentManager): FragmentStatePagerAdapter(fm)
{
    override fun getCount(): Int = items.size

    override fun getItem(position: Int): NetworkSettingsPage = items[position]

    override fun getPageTitle(position: Int): CharSequence? = getItem(position).title

    fun getTabView(position: Int): View
    {
        val v = LayoutInflater.from(context).inflate(R.layout.custom_tab, null)
        v.selectedTV.text = getPageTitle(position)
        v.unselectedTV.text = getPageTitle(position)
        v.setPadding(0, 0, 0, 0)
        return v
    }
}