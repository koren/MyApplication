package com.evogence.eilink.controllers.nodeCommandSender

import com.evogence.eilink.common.BlockRunnable
import com.evogence.eilink.models.node.Node

enum class ENodeCommand
{
    GET_INFO,
    GET_MANAGEMENT_SERVER,
    GET_MODE_CONFIGURATION,
    GET_NET_SETTINGS,
    GET_RM_SERVER,
    GET_UPDATE_SERVER,
    CHECK_CONNECTION_MANAGEMENT_SERVER,
    CHECK_CONNECTION_RM_SERVER,
    CHECK_CONNECTION_UPDATE_SERVER,
    REBOOT_AND_SHUTDOWN,
    SET_NAME,
    SET_MANAGEMENT_SERVER,
    SET_SCHEDULE_REBOOT_AND_SHUTDOWN,
    SET_RM_SERVER,
    SET_UPDATE_SERVER,
    SET_NET_SETTINGS,
    SET_PAIR_CONTROLLER,
    SET_PAIR_NODE,
    SET_DISCONNECT_CONTROLLER,
    SET_DISCONNECT_NODE,
    SET_REMOTE_NODE_SWITCH_SETTINGS,
    RESET
}

interface INodeCommandSender
{
    fun build(): INodeCommandSender
    fun send(nodeCommand: ENodeCommand, node: Node, parameters: Any? = null, completion: BlockRunnable)
    fun send(commands: Map<ENodeCommand, Any?>, node: Node, endedCommand: ((ENodeCommand, CommandResult)->Unit)?, completion: (()->Unit)?)
    fun cancel()
}