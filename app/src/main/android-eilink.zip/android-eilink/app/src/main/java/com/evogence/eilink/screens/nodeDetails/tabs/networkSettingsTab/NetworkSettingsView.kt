package com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab

import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.Fragment
import android.support.v4.view.ViewPager
import android.view.View
import android.widget.TextView
import com.evogence.eilink.R
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabView
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.pager.NetworkSettingsPage
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.pager.NetworkSettingsPagerAdapter
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.pager.PageEthernet
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.pager.PageWifi
import com.evogence.eilink.screens.nodeList.groupOperations.networkSettingsOperation.NetworkSettingsGroupOperationPresenter
import kotlinx.android.synthetic.main.node_details_network_settings.*

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class NetworkSettingsView: NodeDetailsTabView<NetworkSettingsVM>()
{
    override val title: String = "Network Settings"
    override val isShowSaveButton: Boolean = true
    override val layout: Int = R.layout.node_details_network_settings
    private val ethernetFragment: NetworkSettingsPage = PageEthernet.build(arguments?.getString(FINGERPRINT_KEY)) as NetworkSettingsPage
    private val wifiFragment: NetworkSettingsPage = PageWifi.build(arguments?.getString(FINGERPRINT_KEY)) as NetworkSettingsPage
    private lateinit var pages: List<NetworkSettingsPage>
    private var previousPagePosition: Int = 0
    private var currentPagePosition: Int = 0

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"
        private const val LIST_FINGERPRINT_KEY = "list_fingerprint_key"

        @JvmStatic
        fun build(fingerprint: String): Fragment
        {
            val fragment = NetworkSettingsView()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }

        @JvmStatic
        fun build(fingerprints: Array<String>): Fragment
        {
            val fragment = NetworkSettingsView()
            val args = Bundle()
            args.putStringArray(LIST_FINGERPRINT_KEY, fingerprints)
            fragment.arguments = args
            return fragment
        }
    }

    override fun initView()
    {
        viewPager.addOnPageChangeListener(object: ViewPager.OnPageChangeListener
        {
            override fun onPageScrollStateChanged(state: Int)
            {
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int)
            {
            }

            override fun onPageSelected(position: Int)
            {
                pages[previousPagePosition].retrieveChanges()
                previousPagePosition = position
                pages[position].refresh()
                currentPagePosition = position
            }
        })
        initTabs()
    }

    override fun fill(model: Any)
    {
        enableDataChangeListener = false

        model as NetworkSettingsVM
        ethernetFragment.fill(model)
        wifiFragment.fill(model)

        enableDataChangeListener = true
    }

    override fun retrieveChanges(model: NetworkSettingsVM)
    {
        pages[currentPagePosition].retrieveChanges(model)
    }

    override fun initPresenter()
    {
        arguments?.let {
            presenter = if(it.containsKey(FINGERPRINT_KEY))
                NetworkSettingsPresenter(it.getString(FINGERPRINT_KEY))
            else
                NetworkSettingsGroupOperationPresenter(it.getStringArray(LIST_FINGERPRINT_KEY))
        }
    }

    private fun initTabs()
    {
        pages = listOf(ethernetFragment, wifiFragment)
        val pagerAdapter = NetworkSettingsPagerAdapter(context!!, pages, activity?.supportFragmentManager!!)
        viewPager.adapter = pagerAdapter

        tabLayout.setupWithViewPager(viewPager)
        for(i in 0 until tabLayout.tabCount)
        {
            val tab = tabLayout.getTabAt(i)
            tab?.customView = pagerAdapter.getTabView(i)
            if(i == 0)
                setTabSelectedStyle(tab)
            else
                setTabUnselectedStyle(tab)
        }

        tabLayout.addOnTabSelectedListener(object: TabLayout.OnTabSelectedListener
        {
            override fun onTabReselected(tab: TabLayout.Tab?)
            {

            }

            override fun onTabUnselected(tab: TabLayout.Tab?)
            {
                setTabUnselectedStyle(tab)
            }

            override fun onTabSelected(tab: TabLayout.Tab?)
            {
                setTabSelectedStyle(tab)
            }
        })

        pages.forEach {
            it.changeSaveButtonStatusListener = object: ()->Unit
            {
                override fun invoke()
                {
                    dataMayChanged()
                }
            }
        }
    }

    fun setTabSelectedStyle(tab: TabLayout.Tab?)
    {
        tab?.customView?.let {
            it.findViewById<TextView>(R.id.selectedTV).visibility = View.VISIBLE
            it.findViewById<TextView>(R.id.unselectedTV).visibility = View.GONE
        }
    }

    fun setTabUnselectedStyle(tab: TabLayout.Tab?)
    {
        tab?.customView?.let {
            it.findViewById<TextView>(R.id.selectedTV).visibility = View.GONE
            it.findViewById<TextView>(R.id.unselectedTV).visibility = View.VISIBLE
        }
    }
}
