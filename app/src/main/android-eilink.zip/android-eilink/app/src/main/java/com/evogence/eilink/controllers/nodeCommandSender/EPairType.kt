package com.evogence.eilink.controllers.nodeCommandSender

/**
 * Created by Koren Vitalii on 8/31/2018.
 */
enum class EPairType(val value: String)
{
    MANUALY("manual"),
    LIST("list")
}