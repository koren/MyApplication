package com.evogence.eilink.common.json_rpc

/**
 * Created by Anatolij on 10/21/17.
 */

class JsonRpcError
{
	var code: Int = 0
	var message: String? = null

	override fun toString(): String
	{
		return "code=$code message=$message"
	}
}
