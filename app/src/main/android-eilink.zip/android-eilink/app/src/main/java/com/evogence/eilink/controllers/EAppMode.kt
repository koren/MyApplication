package com.evogence.eilink.controllers

/**
 * Created by Anatolij on 8/17/18.
 */
enum class EAppMode
{
	FIELD_AGENT_MODE, SERVICE_MODE
}