package com.evogence.eilink.controllers.nodeCommandSender

enum class EIPVersionType(val key: String, val value: Boolean)
{
    IP4_VERSION_TYPE("Ipv4", true),
    IP6_VERSION_TYPE("Ipv6", false)
}

class IPSettings
{
    companion object
    {
        fun getVersionType(value: String?): EIPVersionType
        {
            var result = EIPVersionType.IP4_VERSION_TYPE
            when(value)
            {
                EIPVersionType.IP4_VERSION_TYPE.key -> result = EIPVersionType.IP4_VERSION_TYPE
                EIPVersionType.IP6_VERSION_TYPE.key -> result = EIPVersionType.IP6_VERSION_TYPE
            }
            return result
        }

        fun getVersionType(value: Boolean = true): EIPVersionType
        {
            var result = EIPVersionType.IP4_VERSION_TYPE
            when(value)
            {
                EIPVersionType.IP4_VERSION_TYPE.value -> result = EIPVersionType.IP4_VERSION_TYPE
                EIPVersionType.IP6_VERSION_TYPE.value -> result = EIPVersionType.IP6_VERSION_TYPE
            }
            return result
        }
    }

    var address: String = ""
    var netmask: String = ""
    var gateway: String = ""
    var version: String = ""
    var versionType: EIPVersionType = EIPVersionType.IP4_VERSION_TYPE
}