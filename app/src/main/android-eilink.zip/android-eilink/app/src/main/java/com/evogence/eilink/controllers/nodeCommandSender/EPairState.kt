package com.evogence.eilink.controllers.nodeCommandSender

/**
 * Created by Koren Vitalii on 8/31/2018.
 */
enum class EPairState(val value: String)
{
    PAIR("pair"),
    UNPAIR("disconnect")
}