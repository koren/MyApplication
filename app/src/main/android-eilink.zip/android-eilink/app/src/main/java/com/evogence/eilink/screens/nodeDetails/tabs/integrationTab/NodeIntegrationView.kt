package com.evogence.eilink.screens.nodeDetails.tabs.integrationTab

import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import com.evogence.eilink.common.ui.SelectorView
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabView
import com.evogence.eilink.screens.nodeList.groupOperations.integrationOperation.NodeIntegrationGroupOperationPresenter
import kotlinx.android.synthetic.main.node_details_integration.*

/**
 * Created by Koren Vitalii on 9/6/2018.
 */
class NodeIntegrationView: NodeDetailsTabView<NodeIntegrationVM>()
{
    override val title = "Integration"
    override val isShowSaveButton = true
    override val layout: Int = R.layout.node_details_integration

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"
        private const val LIST_FINGERPRINT_KEY = "list_fingerprint_key"

        @JvmStatic
        fun build(fingerprint: String): NodeIntegrationView
        {
            val fragment = NodeIntegrationView()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }

        @JvmStatic
        fun build(fingerprints: Array<String>): NodeIntegrationView
        {
            val fragment = NodeIntegrationView()
            val args = Bundle()
            args.putStringArray(LIST_FINGERPRINT_KEY, fingerprints)
            fragment.arguments = args
            return fragment
        }
    }

    override fun initPresenter()
    {
        arguments?.let {
            presenter = if(it.containsKey(FINGERPRINT_KEY))
                NodeIntegrationPresenter(it.getString(FINGERPRINT_KEY))
            else
                NodeIntegrationGroupOperationPresenter(it.getStringArray(LIST_FINGERPRINT_KEY))
        }
    }

    override fun fill(model: Any)
    {
        enableDataChangeListener = false

        model as NodeIntegrationVM
        managementServerSwitch.isChecked = model.enableManagementServer
        useServerToGetUpdatesSwitch.isChecked = model.useServerToGetUpdates
        useSFTPSwitch.isChecked = model.useSftp
        resultMessageManagementServerTV.text = model.resultMessageManagementServer
        resultMessageManagementServerTV.setTextColor(if(model.resultMessageManagementServerError) ContextCompat.getColor(context!!,R.color.message_text_error) else ContextCompat.getColor(context!!,R.color.message_text))
        taskTimeoutET.setText(model.esTaskCompletionTimeout)
        serverManagementServerET.setText(model.serverIpAddressOrDomain)
        httpPortET.setText(model.httpPort)
        sshPortET.setText(model.sshPort)

        tunnelAddressET.setText(model.tunnelAddressReverseMonitoringServer)
        resultMessageReverseMonitoringTV.text = model.resultMessageReverseMonitoringServer
        resultMessageReverseMonitoringTV.setTextColor(if(model.resultMessageReverseMonitoringServerError) ContextCompat.getColor(context!!,R.color.message_text_error) else ContextCompat.getColor(context!!,R.color.message_text))
        reverseMonitoringSwitch.isChecked = model.useTunnelReverseMonitoringServer

        updateServerSwitch.isChecked = model.isEnableUpdateServer
        updateServerET.setText(model.addressUpdateServer)
        if(model.resultMessageUpdateServer.isNotEmpty())
        {
            resultMessageUpdateServerTV.visibility = View.VISIBLE
            resultMessageUpdateServerTV.text = model.resultMessageUpdateServer
            resultMessageUpdateServerTV.setTextColor(if(model.resultMessageUpdateServerError) ContextCompat.getColor(context!!,R.color.message_text_error) else ContextCompat.getColor(context!!,R.color.message_text))
        }
        else
            resultMessageUpdateServerTV.visibility = View.INVISIBLE

        updateServerSwitched()
        reverseMonitoringSwitched()
        managementServerSwitched()

        enableDataChangeListener = true
    }

    override fun retrieveChanges(model: NodeIntegrationVM)
    {
        model.enableManagementServer = managementServerSwitch.isChecked
        model.useServerToGetUpdates = useServerToGetUpdatesSwitch.isChecked
        model.useSftp = useSFTPSwitch.isChecked
        model.esTaskCompletionTimeout = taskTimeoutET.text.toString()
        model.serverIpAddressOrDomain = serverManagementServerET.text.toString()
        model.httpPort = httpPortET.text.toString()
        model.sshPort = sshPortET.text.toString()

        model.tunnelAddressReverseMonitoringServer = tunnelAddressET.text.toString()
        model.useTunnelReverseMonitoringServer = reverseMonitoringSwitch.isChecked

        model.isEnableUpdateServer = updateServerSwitch.isChecked
        model.addressUpdateServer = updateServerET.text.toString()
    }

    override fun onDestroyView()
    {
        presenter.detachView()
        super.onDestroyView()
    }

    override fun onClick(v: View?)
    {
        hideKeyboard()
        when(v?.id)
        {
            R.id.backBtn -> presenter.onBack()
            R.id.saveBtn -> presenter.onSave()
            R.id.checkConnectionManagementServerBtn -> (presenter as INodeIntegrationPresenter).checkConnectionManagementServer()
            R.id.checkConnectionReverseMonitoringBtn -> (presenter as INodeIntegrationPresenter).checkConnectionReverseMonitoringServer()
            R.id.checkConnectionUpdateServerBtn -> (presenter as INodeIntegrationPresenter).checkConnectionUpdateServer()
            R.id.managementServerSwitch -> managementServerSwitched()
            R.id.reverseMonitoringSwitch -> reverseMonitoringSwitched()
            R.id.updateServerSwitch -> updateServerSwitched()
        }

        val list = listOf(R.id.managementServerSwitch, R.id.reverseMonitoringSwitch, R.id.updateServerSwitch,R.id.useServerToGetUpdatesSwitch, R.id.updateServerSwitch)
        if(list.contains(v?.id))
            dataMayChanged()
    }

    private fun enableViewGroup(viewGroup: ViewGroup, enabled: Boolean)
    {
        val childCount = viewGroup.childCount
        for(i in 0 until childCount)
        {
            val view = viewGroup.getChildAt(i)
            view.isEnabled = enabled
            if(view is ViewGroup)
            {
                enableViewGroup(view, enabled)
            }
        }
    }

    override fun initView()
    {
        val selectorView = SelectorView()
        checkConnectionManagementServerBtn.setOnTouchListener(selectorView)
        checkConnectionReverseMonitoringBtn.setOnTouchListener(selectorView)
        checkConnectionUpdateServerBtn.setOnTouchListener(selectorView)

        checkConnectionManagementServerBtn.setOnClickListener(this)

        managementServerSwitch.setOnClickListener(this)
        useServerToGetUpdatesSwitch.setOnClickListener(this)

        checkConnectionReverseMonitoringBtn.setOnClickListener(this)
        reverseMonitoringSwitch.setOnClickListener(this)

        checkConnectionUpdateServerBtn.setOnClickListener(this)
        updateServerSwitch.setOnClickListener(this)

        updateServerSwitched()
        reverseMonitoringSwitched()
        managementServerSwitched()
    }

    private fun updateServerSwitched()
    {
        enableViewGroup(updateServerContainer, updateServerSwitch.isChecked)
    }

    private fun reverseMonitoringSwitched()
    {
        enableViewGroup(reverseMonitoringContainer, reverseMonitoringSwitch.isChecked)
    }

    private fun managementServerSwitched()
    {
        enableViewGroup(managementServerContainer, managementServerSwitch.isChecked)
    }
}