package com.evogence.eilink.common;

public enum EConnectionType
{
    NONE(0),
    WIFI(1),
    WWAN(2);

    private int code;

    EConnectionType(int c)
    {
        code = c;
    }

    public int getCode()
    {
        return code;
    }

    public static EConnectionType of(int _type)
    {
        switch(_type)
        {
            case 1:
                return WIFI;
            case 2:
                return WWAN;
        }

        return NONE;
    }

    public String toString()
    {
        switch(code)
        {
            case 1:
                return "Wi-Fi";
            case 2:
                return "WWAN";
        }

        return "none";
    }
}
