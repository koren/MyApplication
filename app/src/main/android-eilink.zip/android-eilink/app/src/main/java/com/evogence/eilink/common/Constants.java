package com.evogence.eilink.common;

/**
 * Created by viro on 29.10.15.
 */
public class Constants
{
    public static final int APPLIANCE_PORT = 50400;
}
