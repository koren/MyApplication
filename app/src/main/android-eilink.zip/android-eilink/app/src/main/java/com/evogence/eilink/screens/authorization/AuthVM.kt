package com.evogence.eilink.screens.authorization

/**
 * Created by Koren Vitalii on 8/28/2018.
 */
class AuthVM
{
    var title: String = ""
    var username: String = ""
    var password: String = ""
}