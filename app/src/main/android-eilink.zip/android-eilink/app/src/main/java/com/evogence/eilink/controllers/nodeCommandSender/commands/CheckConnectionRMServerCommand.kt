package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.JsonPrimitive

class CheckConnectionRMServerCommand(parameters: Any?): INodeCommand
{
    override val method: String = "Integration.RPN.settings.ManagementServer::checkTunnel"
    override val desc: String = "Check Connection to Update Server"

    override var params: MutableMap<String, Any> = HashMap()

    companion object MapKeys
    {
        const val HOST_KEY = "host"
    }

    init
    {
        if(parameters is String)
            params[HOST_KEY] = parameters
    }

    override fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()
        val result = (response.result as JsonPrimitive).asBoolean
        if(!result)
        {
            commandResult.error = "The connection with the server cannot be established"
        }
        return commandResult
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonPrimitive)?.isBoolean ?: false
    }
}

