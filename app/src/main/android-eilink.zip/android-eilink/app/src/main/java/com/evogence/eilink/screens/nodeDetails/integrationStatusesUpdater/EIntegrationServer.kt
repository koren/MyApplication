package com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater

enum class EIntegrationServer
{
    CENTRAL_SERVER,
    SUPPORT_SERVER,
    UPDATE_SERVER
}
