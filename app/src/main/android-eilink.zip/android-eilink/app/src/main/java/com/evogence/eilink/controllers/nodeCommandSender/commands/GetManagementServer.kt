package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.google.gson.JsonObject


class GetManagementServer: INodeCommand
{
    override val method: String = "Integration.RPN.settings.ManagementServer::getIntegrationParams"
    override val desc: String = "Get Management Server"
    override var params: MutableMap<String, Any> = HashMap()

    companion object MapKeys
    {
        val REGISTER_TOKEN_KEY: String = "register_token"
        val TASK_TIMEOUT_KEY: String = "task_timeout"
        val IS_ES_ENABLE_KEY: String = "is_es_enable"
        val USE_ES_AS_UPDATE_SERVER_KEY: String = "use_es_as_update_server"
        val USE_ES_SSH_CONNECTION_KEY: String = "use_es_ssh_connection"
        val PRIMARY_ES_KEY: String = "primary_es"
        val HOST_KEY: String = "host"
        val HTTP_PORT_KEY: String = "http_port"
        val SSH_PORT_KEY: String = "ssh_port"
        val FTP_PORT_KEY: String = "ftp_port"
        val SECONDARY_ES_KEY: String = "secondary_es"
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        var isCorrect = false
        val result = response.result as? JsonObject
        if(result != null)
        {
            val primaryES = result[PRIMARY_ES_KEY]
            if(primaryES != null)
            {
                val validKeys = arrayOf(IS_ES_ENABLE_KEY, USE_ES_AS_UPDATE_SERVER_KEY, USE_ES_SSH_CONNECTION_KEY, TASK_TIMEOUT_KEY, REGISTER_TOKEN_KEY, PRIMARY_ES_KEY)
                val isEsEnable = result[IS_ES_ENABLE_KEY]
                val isEsEnableValue = if(isEsEnable != null && isEsEnable.isJsonPrimitive && isEsEnable.asBoolean) isEsEnable.asBoolean else false

                if(isEsEnableValue)
                {
                    if(primaryES.isJsonObject)
                    {
                        val esKeys = arrayOf(HOST_KEY, HTTP_PORT_KEY, SSH_PORT_KEY)
                        isCorrect = validKeys.all {result.asJsonObject.has(it)} && esKeys.all {primaryES.asJsonObject.has(it)}
                    }
                }
                else
                {
                    isCorrect = true
                }
            }
        }
        return isCorrect
    }
}
