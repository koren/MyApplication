package com.evogence.eilink.screens.nodeList

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.support.v4.view.ViewPager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.daimajia.swipe.SwipeLayout
import com.evogence.eilink.R
import com.evogence.eilink.common.ui.ScreenView
import com.evogence.eilink.common.ui.SelectorView
import com.evogence.eilink.screens.nodeList.tabs.NodeListTabView
import com.evogence.eilink.screens.nodeList.tabs.NodeListViewPagerAdapter
import kotlinx.android.synthetic.main.node_list.*

/**
 * Created by Koren Vitalii on 05/21/18.
 */
class NodeListView: ScreenView(), INodeListView, View.OnClickListener
{
    override lateinit var presenter: NodeListPresenter

    private var viewPagerAdapter: NodeListViewPagerAdapter? = null
    private val tabPoints: MutableList<View> = mutableListOf()
    private var titleList: MutableList<String> = mutableListOf()
    private var nodesTabItem: NodeListTabView? = null
    private var controllersTabItem: NodeListTabView? = null
    private var notSupportedTabItem: NodeListTabView? = null
    private var itemWithOpenedMenu: SwipeLayout? = null

    companion object
    {
        fun build(): Fragment
        {
            return NodeListView()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        presenter = NodeListPresenter()
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.node_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        hideKeyboard()
        initView()
        presenter.onAttachView(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onDestroyView()
    {
        presenter.onDetachView()
        viewPagerAdapter = null

//        fragmentTransaction.remove(yourfragment).commit()

        //todo we have to destroy fragments correctly
        nodesTabItem = null
        controllersTabItem = null
        notSupportedTabItem = null

        tabPoints.clear()
        titleList.clear()

        super.onDestroyView()
    }

    override fun fill(model: Any)
    {
        model as NodeListVM
        activity?.runOnUiThread {
            refreshTabs(model)
            refreshSelectedPage(pagerNodeList.currentItem)
        }
    }

    override fun initView()
    {
        initTabs()

        val selectorView = SelectorView()
        aboutBtn.setOnTouchListener(selectorView)
        groupOperationMenuItemIntegration.setOnTouchListener(selectorView)
        groupOperationMenuItemNetwork.setOnTouchListener(selectorView)
        groupOperationMenuItemReset.setOnTouchListener(selectorView)

        aboutBtn.setOnClickListener(this)

        groupOperationMenuItemIntegration.setOnClickListener(this)
        groupOperationMenuItemNetwork.setOnClickListener(this)
        groupOperationMenuItemReset.setOnClickListener(this)

        enableBottomButtonsContainer(false)

        swipeContainer.setOnRefreshListener {
            presenter.searchLocalDevice()
            swipeContainer.isRefreshing = false
        }
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.aboutBtn -> presenter.onClickAbout()
            R.id.groupOperationMenuItemIntegration -> presenter.onClickGroupOperationMenuItemIntegration()
            R.id.groupOperationMenuItemNetwork -> presenter.onClickGroupOperationMenuItemNetwork()
            R.id.groupOperationMenuItemReset -> presenter.onClickGroupOperationMenuItemReset()
        }
    }

    fun onClickNodeIconContainer(fingerprint: String)
    {
        presenter.onClickNodeIconContainer(fingerprint)
    }

    private fun initTabs()
    {
        val fm = activity?.supportFragmentManager
        if(fm != null)
        {
            viewPagerAdapter = NodeListViewPagerAdapter(fm)
            pagerNodeList.adapter = viewPagerAdapter
            pagerNodeList.addOnPageChangeListener(object: ViewPager.OnPageChangeListener
            {
                override fun onPageScrollStateChanged(state: Int)
                {
                }

                override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int)
                {
                }

                override fun onPageSelected(position: Int)
                {
                    refreshSelectedPage(position)
                    changeStatusGroupOperationsBar()
                }
            })
            tabsNodeList.setupWithViewPager(pagerNodeList)
        }

        pagerNodeList.addOnPageChangeListener(object: ViewPager.OnPageChangeListener
        {
            override fun onPageScrollStateChanged(state: Int)
            {
            }

            override fun onPageScrolled(position: Int, positionOffset: Float, positionOffsetPixels: Int)
            {
            }

            override fun onPageSelected(position: Int)
            {
                presenter.onPageSelected(position)
            }
        })
    }

    fun refreshSelectedPage(position: Int)
    {
        tabPoints.forEach {
            (it as ImageView).setImageDrawable(ContextCompat.getDrawable(activity!!, R.drawable.tabs_point_unvisible))
        }

        if(tabPoints.size >= position + 1)
        {
            val currentTabPointView = tabPoints[position]
            activity?.runOnUiThread {
                (currentTabPointView as ImageView).setImageDrawable(ContextCompat.getDrawable(activity!!, R.drawable.tabs_point_visible))
                titleTV.text = titleList[position]
            }

        }
    }

    fun reset(fingerprint: String)
    {
        presenter.reset(fingerprint)
    }

    fun reboot(fingerprint: String)
    {
        presenter.reboot(fingerprint)
    }

    fun restart(fingerprint: String)
    {
        presenter.restart(fingerprint)
    }

    override fun enableBottomButtonsContainer(enable: Boolean)
    {
        enableViewGroup(bottomButtonsContainer, enable)
    }

    override fun changeStatusGroupOperationsBar()
    {
        presenter.changeStatusGroupOperationsBar()
    }

    fun onStartOpenMenu(layout: SwipeLayout?)
    {
        if(layout != itemWithOpenedMenu)
        {
            itemWithOpenedMenu?.close(true)
            itemWithOpenedMenu = null
        }
    }

    fun onOpen(layout: SwipeLayout?)
    {
        itemWithOpenedMenu = layout
    }

    private fun refreshTabs(model: NodeListVM)
    {
        titleList = model.titleList

        configNodesTab(model)
        configControllersTab(model)
        configNotSupportedTab(model)
    }

    private fun configNodesTab(model: NodeListVM)
    {
        if(nodesTabItem == null)
            nodesTabItem = NodeListTabView.build(this)

        nodesTabItem?.let()
        {
            val indexNodesTabItem = viewPagerAdapter?.fragmentList?.indexOf(it)
            if((model.nodes.size > 0) && ((indexNodesTabItem == null) || (indexNodesTabItem < 0)))
                addTab(nodesTabItem, model.nodes, tab1PointImage)
            else if((model.nodes.size == 0) && (indexNodesTabItem != null) && (indexNodesTabItem >= 0))
                removeTab(tab1PointImage, indexNodesTabItem)
            else
                nodesTabItem?.notifyDataSetChanged()
        }
    }

    private fun configControllersTab(model: NodeListVM)
    {
        if(controllersTabItem == null)
            controllersTabItem = NodeListTabView.build(this)

        controllersTabItem?.let()
        {
            val indexControllersTabItem = viewPagerAdapter?.fragmentList?.indexOf(it)
            if((model.controllers.size > 0) && ((indexControllersTabItem == null) || (indexControllersTabItem < 0)))
                addTab(controllersTabItem, model.controllers, tab2PointImage)
            else if((model.controllers.size == 0) && (indexControllersTabItem != null) && (indexControllersTabItem >= 0))
                removeTab(tab2PointImage, indexControllersTabItem)
            else
                controllersTabItem?.notifyDataSetChanged()
        }
    }

    private fun configNotSupportedTab(model: NodeListVM)
    {
        if(notSupportedTabItem == null)
            notSupportedTabItem = NodeListTabView.build(this)

        notSupportedTabItem?.let()
        {
            val indexNotSupportedTabItem = viewPagerAdapter?.fragmentList?.indexOf(it)
            if((model.notSupported.size > 0) && ((indexNotSupportedTabItem == null) || (indexNotSupportedTabItem < 0)))
                addTab(notSupportedTabItem, model.notSupported, tab3PointImage)
            else if((model.notSupported.size == 0) && (indexNotSupportedTabItem != null) && (indexNotSupportedTabItem >= 0))
                removeTab(tab3PointImage, indexNotSupportedTabItem)
            else
                notSupportedTabItem?.notifyDataSetChanged()
        }
    }

    private fun addTab(nodeListTabView: NodeListTabView?, list: MutableList<NodeListItemVM>, tabPointImage: ImageView)
    {
        if(nodeListTabView != null)
        {
            tabPoints.add(tabPointImage)
            nodeListTabView.setList(list)
            activity?.runOnUiThread {
                tabPointImage.visibility = View.VISIBLE
                viewPagerAdapter?.addFragment(nodeListTabView)
                viewPagerAdapter?.notifyDataSetChanged()
            }
        }
    }

    private fun removeTab(tabPointImage: ImageView, indexNodesTabItem: Int)
    {
        tabPoints.remove(tab1PointImage)
        tabPointImage.visibility = View.GONE
        viewPagerAdapter?.fragmentList?.removeAt(indexNodesTabItem)
        viewPagerAdapter?.notifyDataSetChanged()
    }

    private fun enableViewGroup(viewGroup: ViewGroup, enabled: Boolean)
    {
        val childCount = viewGroup.childCount
        for(i in 0 until childCount)
        {
            val view = viewGroup.getChildAt(i)
            view.isEnabled = enabled
            if(view is ViewGroup)
            {
                view.isEnabled = enabled
                enableViewGroup(view, enabled)
            }
        }
    }
}
