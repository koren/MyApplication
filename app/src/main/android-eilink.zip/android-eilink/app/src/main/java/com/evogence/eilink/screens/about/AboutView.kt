package com.evogence.eilink.screens.about

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import com.evogence.eilink.common.ui.ScreenView
import kotlinx.android.synthetic.main.about.*

/**
 * Created by Koren Vitalii on 05/30/18.
 */
class AboutView: ScreenView(), View.OnClickListener
{
    private var presenter: AboutPresenter? = null

    companion object
    {
        fun build(): Fragment
        {
            return AboutView()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        presenter = AboutPresenter()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.about, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        initView()
        presenter?.onAttachView(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onDestroyView()
    {
        presenter?.onDetachView()
        super.onDestroyView()
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.backBtn -> presenter?.onBack()
            R.id.logoutBtn -> presenter?.onLogout()
        }
    }

    override fun fill(model: Any)
    {
        model as AboutVM
        usedSpaceTV.text = model.usedSpace
        usedSpacePB.progress = model.usedSpaceProgress
        versionTV.text = model.version
    }

    fun initView()
    {
        backBtn.setOnClickListener(this)
        logoutBtn.setOnClickListener(this)
    }
}
