package com.evogence.eilink.di;

import android.content.Context;

import com.evogence.eilink.EiLinkApplication;
import com.evogence.eilink.MainActivity;
import com.evogence.eilink.controllers.authManager.AuthManager;
import com.evogence.eilink.controllers.nodesStorage.INodesStorage;
import com.evogence.eilink.di.modules.AppModule;
import com.evogence.eilink.screens.authorization.AuthPresenter;
import com.evogence.eilink.screens.nodeList.groupOperations.GroupOperationsPresenter;
import com.evogence.eilink.screens.nodeDetails.NodeDetailsPresenter;
import com.evogence.eilink.screens.nodeDetails.NodeDetailsView;
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabPresenter;
import com.evogence.eilink.screens.nodeDetails.tabs.integrationTab.NodeIntegrationPresenter;
import com.evogence.eilink.screens.nodeList.INodeListView;
import com.evogence.eilink.screens.nodeList.NodeListPresenter;
import com.evogence.eilink.screens.about.AboutPresenter;

import org.jetbrains.annotations.NotNull;

import javax.inject.Singleton;

import dagger.Component;

/**
 * Created by Kefir on 1/2/2018
 */

@Singleton
@Component(modules = AppModule.class)
public interface AppComponent
{
    Context context();

    void inject(MainActivity activity);

    void inject(EiLinkApplication app);

    void inject(AuthManager manager);

    void inject(INodesStorage nodesStorage);

    void inject(NodeDetailsView nodeDetailsView);

    void inject(INodeListView nodeListView);

    void inject(NodeListPresenter nodeListPresenter);

    void inject(@NotNull AuthPresenter authPresenter);

    void inject(@NotNull AboutPresenter aboutPresenter);

    void inject(@NotNull NodeIntegrationPresenter nodeIntegrationPresenter);

    void inject(@NotNull NodeDetailsPresenter nodeDetailsPresenter);

    void inject(@NotNull NodeDetailsTabPresenter.InjectorHelper injectorHelper);

    void inject(@NotNull GroupOperationsPresenter groupOperationsPresenter);
}
