package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab

import android.support.v7.widget.RecyclerView
import android.view.View
import com.evogence.eilink.common.Utils
import kotlinx.android.synthetic.main.node_details_aux_mode_node_select_list_item.view.*

/**
 * Created by Koren Vitalii on 8/31/2018.
 */
class ListItemHolder(itemView: View): RecyclerView.ViewHolder(itemView)
{
    fun bind(node: ListItemVM)
    {
        itemView.applianceImg.setImageResource(Utils.prepareIconRes(itemView.context, node.iconName))
        itemView.modelLabelTV.text = node.model
        itemView.nodeNameTV.text = node.title
        itemView.addressTV.text = node.ip
        itemView.serialNumberTV.text = node.serialNumber
        itemView.versionLabelTV.text = node.version
    }
}