package com.evogence.eilink.models.node

import com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater.EConnectionStatus

/**
 * Created by Anatolij on 8/16/18.
 */
class UpdateServer
{
	var isEnable: Boolean = false
	var host: String = ""
	var updateTimestamp: Long = 0

	var connectedStatus = EConnectionStatus.UNDEFINED_STATUS
}