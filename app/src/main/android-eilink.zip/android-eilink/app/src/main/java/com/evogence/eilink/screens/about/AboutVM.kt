package com.evogence.eilink.screens.about

/**
 * Created by Koren Vitalii on 05/30/18.
 */
class AboutVM
{
    var usedSpace: String = ""
    var usedSpaceProgress: Int = 0
    var version = ""
}

