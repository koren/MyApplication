package com.evogence.eilink.models.node

import com.evogence.eilink.controllers.nodeCommandSender.IPSettings

/**
 * Created by Koren Vitalii on 21.04.2018.
 */
open class NodeNetworkSettings
{
    var ipdhcp: Boolean = false
    var ethernetIP = IPSettings()

    var wifiEnabled: Boolean = false
    var wifiPreferred: Boolean = false
    var wifiIpdhcp: Boolean = false
    var wifiSsid: String = ""
    var wifiSecurityProtocol: String = ""
    var wifiAuthIdentity: String = ""
    var wifiAuthKey: String = ""
    var wifiAuthPassword: String = ""
    var wifiAuthPrivateKeyPassword: String = ""
    var wifiIP = IPSettings()

    var dns1: String = ""
    var dns2: String = ""
    var dns3: String = ""

    var updateTimestamp: Long = 0
}
