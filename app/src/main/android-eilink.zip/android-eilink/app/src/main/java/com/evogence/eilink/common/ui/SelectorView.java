package com.evogence.eilink.common.ui;

import android.annotation.SuppressLint;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;

public class SelectorView implements OnTouchListener
{
    public static final float ALPHA_DEF = 1F;
    public static final float ALPHA_PUSHED_DEF = 0.5F;
    private float defAlpha = ALPHA_DEF;
    private float pushedAlpha = ALPHA_PUSHED_DEF;

    public SelectorView()
    {
        super();
    }

    public SelectorView(float pushedAlpha)
    {
        super();
        this.pushedAlpha = pushedAlpha;
    }

    @SuppressLint("NewApi")
    @Override
    public boolean onTouch(View view, MotionEvent event)
    {
        if (view.isClickable())
        {
            int action = event.getAction();
            if (action == MotionEvent.ACTION_DOWN)
                view.setAlpha(pushedAlpha);
            else if(action == MotionEvent.ACTION_UP)
                view.setAlpha(defAlpha);
        }

        return false;
    }

    public void setDefAlpha(float defAlpha)
    {
        this.defAlpha = defAlpha;
    }

    public void setPushedAlpha(float pushedAlpha)
    {
        this.pushedAlpha = pushedAlpha;
    }
}