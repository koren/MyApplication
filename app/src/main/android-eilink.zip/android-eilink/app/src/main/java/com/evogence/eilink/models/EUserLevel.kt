package com.evogence.eilink.models

/**
 * Created by Koren Vitalii on 07/27/18.
 */
enum class EUserLevel(level: Int)
{
    ADMIN_LEVEL(0),
    USER_LEVEL(1)
}