package com.evogence.eilink.controllers.nodeCommandSender

import com.evogence.eilink.common.BlockRunnable
import com.evogence.eilink.common.ConnectionData
import com.evogence.eilink.common.json_rpc.JsonRpcRequest
import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.apiServices.INodeApiService
import com.evogence.eilink.controllers.apiServices.NodeApiService
import com.evogence.eilink.controllers.nodeCommandSender.commands.CheckConnectionManagementServer
import com.evogence.eilink.controllers.nodeCommandSender.commands.CheckConnectionRMServerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.CheckConnectionUpdateServerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetManagementServer
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetModeConfigurationCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetNetSettingsCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetNodeInfoCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetRMServerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetUpdateServerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.INodeCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.RebootAndShutdownCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.ResetCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetDisconnectControllerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetDisconnectNodeCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetManagementServer
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetNodeNameCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetPairControllerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetPairNodeCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetRMServerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetRemoteNodeSwitchSettingsCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetScheduleRebootCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetUpNetSettingsCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetUpdateServerCommand
import com.evogence.eilink.models.node.Node
import io.reactivex.Flowable
import io.reactivex.Observable
import io.reactivex.Observer
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.Disposable
import io.reactivex.schedulers.Schedulers
import io.reactivex.schedulers.Schedulers.newThread

const val PROTOCOL_ERROR_MESSAGE = "Not supported. Please update [Ei] OS version"
const val UNEXPECTED_ERROR_MESSAGE = "Unexpected error"

class NodeCommandSender: INodeCommandSender
{
    //    private var operationLogStorage: Any /*IDeviceOperationLogStorage*/
    private var apiService: INodeApiService? = null
    private var command: INodeCommand? = null
    private val disposables = mutableListOf<Disposable>()
    private var commandResult: CommandResult? = null

    override fun build(/*storage: IDeviceOperationLogStorage*/): INodeCommandSender
    {
        //        result.operationLogStorage = storage
        return NodeCommandSender()
    }

    override fun send(nodeCommand: ENodeCommand, node: Node, parameters: Any?, completion: BlockRunnable)
    {
        command = buildCommand(nodeCommand, parameters)
        command?.params?.put("fingerprint", node.fingerprint)

        val disposable = buildRequest(node).observeOn(AndroidSchedulers.mainThread()).subscribeOn(newThread()).subscribe({
            processingResponse(it, node.fingerprint)
            completion(completion)
        }, {
            processingError(it, node.fingerprint)
            completion(completion)
        })

        disposables.add(disposable)
    }

    override fun send(commands: Map<ENodeCommand, Any?>, node: Node, endedCommand: ((ENodeCommand, CommandResult)->Unit)?, completion: (()->Unit)?)
    {
        Observable.fromIterable(commands.entries)
            .subscribeOn(Schedulers.io())
            .flatMap(fun(entry: Map.Entry<ENodeCommand, Any?>): Observable<JsonRpcResponse>?
            {
                val command = buildCommand(entry.key, entry.value)
                command.params["fingerprint"] = node.fingerprint
                return buildRequest(node, command)
                    .toObservable()
                    .observeOn(AndroidSchedulers.mainThread())
                    .subscribeOn(Schedulers.io())
                    .doOnNext {
                        val commandResult = processingResponse(it, node.fingerprint, command)
                        endedCommand?.invoke(entry.key, commandResult!!)
                    }
                    .onErrorReturn {
                        JsonRpcResponse.build("Node Unavailable")
                    }
            })
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(object: Observer<JsonRpcResponse>
            {
                override fun onComplete()
                {
                    completion?.invoke()
                }

                override fun onSubscribe(d: Disposable)
                {
                }

                override fun onNext(t: JsonRpcResponse)
                {
                }

                override fun onError(e: Throwable)
                {
                }
            })
    }

    override fun cancel()
    {
        disposables.forEach {
            it.dispose()
        }
    }

    private fun buildApi(node: Node): INodeApiService
    {
        val connectionData = ConnectionData().build(scheme = ConnectionData.HTTP_KEY, host = node.address, port = node.port)
        return NodeApiService().build(connectionData, node.fingerprint)
    }

    private fun buildCommand(nodeCommand: ENodeCommand, parameters: Any?): INodeCommand
    {
        return when(nodeCommand)
        {
            ENodeCommand.GET_INFO -> GetNodeInfoCommand()
            ENodeCommand.GET_MANAGEMENT_SERVER -> GetManagementServer()
            ENodeCommand.GET_MODE_CONFIGURATION -> GetModeConfigurationCommand()
            ENodeCommand.GET_NET_SETTINGS -> GetNetSettingsCommand()
            ENodeCommand.GET_RM_SERVER -> GetRMServerCommand()
            ENodeCommand.GET_UPDATE_SERVER -> GetUpdateServerCommand()
            ENodeCommand.CHECK_CONNECTION_MANAGEMENT_SERVER -> CheckConnectionManagementServer(parameters)
            ENodeCommand.CHECK_CONNECTION_RM_SERVER -> CheckConnectionRMServerCommand(parameters)
            ENodeCommand.CHECK_CONNECTION_UPDATE_SERVER -> CheckConnectionUpdateServerCommand(parameters)
            ENodeCommand.REBOOT_AND_SHUTDOWN -> RebootAndShutdownCommand(parameters)
            ENodeCommand.SET_NAME -> SetNodeNameCommand(parameters)
            ENodeCommand.SET_MANAGEMENT_SERVER -> SetManagementServer(parameters)
            ENodeCommand.SET_SCHEDULE_REBOOT_AND_SHUTDOWN -> SetScheduleRebootCommand(parameters)
            ENodeCommand.SET_RM_SERVER -> SetRMServerCommand(parameters)
            ENodeCommand.SET_UPDATE_SERVER -> SetUpdateServerCommand(parameters)
            ENodeCommand.SET_NET_SETTINGS -> SetUpNetSettingsCommand(parameters)
            ENodeCommand.SET_PAIR_CONTROLLER -> SetPairControllerCommand(parameters)
            ENodeCommand.SET_PAIR_NODE -> SetPairNodeCommand(parameters)
            ENodeCommand.SET_DISCONNECT_CONTROLLER -> SetDisconnectControllerCommand(parameters)
            ENodeCommand.SET_DISCONNECT_NODE -> SetDisconnectNodeCommand(parameters)
            ENodeCommand.SET_REMOTE_NODE_SWITCH_SETTINGS -> SetRemoteNodeSwitchSettingsCommand(parameters)
            ENodeCommand.RESET -> ResetCommand(parameters)
        }
    }

    private fun buildRequest(node: Node): Flowable<JsonRpcResponse>
    {
        apiService = buildApi(node)
        val request = JsonRpcRequest(this.command!!.method, this.command!!.params)
        return this.apiService!!.request(request)
    }

    private fun buildRequest(node: Node, command: INodeCommand): Flowable<JsonRpcResponse>
    {
        this.apiService = buildApi(node)
        val request = JsonRpcRequest(command.method, command.params)
        return this.apiService!!.request(request)
    }

    private fun processingResponse(response: JsonRpcResponse?, fingerprint: String)
    {
        if(this.command!!.isCorrectResponse(response!!))
        {
            this.commandResult = this.command!!.parseResponse(response)
            writeOperationLog(this.command!!.desc, message = null, desc = "Command executed successfully", fingerprint = fingerprint)
        }
        else
        {
            if(response.error != null)
                this.commandResult = buildErrorResult(response.error!!.message!!)
            else
                this.commandResult = CommandResult(PROTOCOL_ERROR_MESSAGE)

            writeOperationLog(this.command!!.desc, message = this.commandResult?.error, desc = "Command executed unsuccessfully", fingerprint = fingerprint)
        }
    }

    private fun processingResponse(response: JsonRpcResponse?, fingerprint: String, command: INodeCommand): CommandResult?
    {
        val commandResult: CommandResult?
        if(command.isCorrectResponse(response!!))
        {
            commandResult = command.parseResponse(response)
            writeOperationLog(command.desc, message = null, desc = "Command executed successfully", fingerprint = fingerprint)
        }
        else
        {
            commandResult = if(response.error != null)
                buildErrorResult(response.error!!.message!!)
            else
                CommandResult(PROTOCOL_ERROR_MESSAGE)

            writeOperationLog(command.desc, commandResult.error, "Command executed unsuccessfully", fingerprint)
        }
        return commandResult
    }

    private fun processingError(error: Throwable, fingerprint: String)
    {
        val message = error.message
        if(message != null)
            this.commandResult = buildErrorResult(message)
        else
            this.commandResult = CommandResult(UNEXPECTED_ERROR_MESSAGE)

        writeOperationLog(this.command!!.desc, message = this.commandResult?.error, desc = "Command executed unsuccessfully", fingerprint = fingerprint)
    }

    private fun buildErrorResult(error: String): CommandResult
    {
        val commandResult = CommandResult()

        if(error.contains(".php") || error.contains("html") || error.contains("Incorrect JSON RPC format"))
        {
            commandResult.error = PROTOCOL_ERROR_MESSAGE
            commandResult.isSupported = false

        }
        else if(error.contains("Could not connect to the server"))
            commandResult.error = "[Ei] Node is unreachable"
        else
            commandResult.error = error

        return commandResult
    }

    private fun completion(completion: BlockRunnable)
    {
        val result = this.commandResult
        this.commandResult = CommandResult()
        this.apiService = null
        this.command = null
        completion.run(result!!)
    }

    private fun writeOperationLog(title: String, message: String?, desc: String?, fingerprint: String)
    {
//        val operationLog = DeviceOperationLog.build(title, code = 0, errorMessage = message, desc = desc, fingerprint = fingerprint)
//        operationLogStorage.add(operationLog)
    }
}
