package com.evogence.eilink.controllers.nodeCommandSender.commands.parameters

import com.evogence.eilink.controllers.nodeCommandSender.commands.SetPairNodeCommand

/**
 * Created by Koren Vitalii on 9/3/2018.
 */
class PairNodeParams(private val snManual: String = "",
                     private val snList: String = "",
                     private val typeLink: String = "",
                     val force: Boolean = false)
{
    fun buildMap(): Map<String, Any?>
    {
        return mapOf(SetPairNodeCommand.SERIAL_MANUAL_KEY to snManual,
            SetPairNodeCommand.SERIAL_LIST_KEY to snList,
            SetPairNodeCommand.TYPE_LINK_KEY to typeLink,
            SetPairNodeCommand.FORCE_KEY to force
        )
    }
}