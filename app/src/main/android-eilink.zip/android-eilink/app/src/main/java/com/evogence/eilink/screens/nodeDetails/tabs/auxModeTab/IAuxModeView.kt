package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab

import com.evogence.eilink.common.dialogs.AlertDialogFragment

/**
 * Created by Koren Vitalii on 9/26/2018.
 */
interface IAuxModeView
{
    fun hideNodeList()
    fun showNodeList(nodeList: List<ListItemVM>)
    fun showAlertDialogWithObserver(title: String, message: String, positiveButtonTextId: Int, negativeButtonTextId: Int, observer: AlertDialogFragment.DialogResultObserver)
    fun onClickPair()
    fun onClickSelectNode()
}