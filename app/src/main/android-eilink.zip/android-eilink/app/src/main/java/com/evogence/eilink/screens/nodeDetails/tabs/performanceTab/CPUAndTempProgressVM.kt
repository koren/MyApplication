package com.evogence.eilink.screens.nodeDetails.tabs.performanceTab

/**
 * Created by Koren Vitalii on 07/27/18.
 */
class CPUAndTempProgressVM(
    val tempProgress: Int,
    val loadProgress: Int = 0,
    val tempValue: Double,
    val loadValue: Double = 0.0,
    val tempSymbol: String,
    val loadSymbol: String = "",
    val title: String,
    val useLoad: Boolean = true)
