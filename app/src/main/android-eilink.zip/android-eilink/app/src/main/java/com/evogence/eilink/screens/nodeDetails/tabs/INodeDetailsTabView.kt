package com.evogence.eilink.screens.nodeDetails.tabs

import com.evogence.eilink.common.ui.IScreenView

/**
 * Created by Koren Vitalii on 9/12/2018.
 */
interface INodeDetailsTabView<T>: INodeDetailsTabViewTitleBar, IScreenView
{
    var presenter: NodeDetailsTabPresenter<T>
    val layout: Int

    fun retrieveChanges(model: T)
    fun initPresenter()
    fun initView()
}