package com.evogence.eilink.screens.nodeDetails.tabs.performanceTab

import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabPresenter
import java.text.DecimalFormat
import java.text.SimpleDateFormat

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class PerformancePresenter(fingerprint: String?): NodeDetailsTabPresenter<PerformanceVM>(fingerprint)
{
    override var viewModel = PerformanceVM()

    override fun prepareViewModel()
    {
        val trafficDate = node.interfaceTrafficDate
        val simpleDateFormat = SimpleDateFormat("MMM")

        viewModel.interfaceTrafficMonth = simpleDateFormat.format(trafficDate)
        viewModel.interfaceTrafficSendLAN = convertByteToMB(node.interfaceTrafficSendLAN!!.toDouble())
        viewModel.interfaceTrafficReceivedLAN = convertByteToMB(node.interfaceTrafficReceivedLAN!!.toDouble())
        viewModel.interfaceTrafficSendWiFi = convertByteToMB(node.interfaceTrafficSendWiFi!!.toDouble())
        viewModel.interfaceTrafficReceivedWiFi = convertByteToMB(node.interfaceTrafficReceivedWiFi!!.toDouble())

        viewModel.cpuAndTempProgress = prepareProgressModels(node.cpusTemp, node.cpusLoad, "°C", "%", 100, 100, "CPU")
        viewModel.gpuTemp = prepareProgressModelsTemp(node.gpusTemp, "°C", 100, "GPU")
        viewModel.cpuLoadTitle = "CPU Load"
        viewModel.cpuTempTitle = "CPU Temp"
        viewModel.gpuTempTitle = "GPU Temp"

        if(node.hddTotal != node.noHardwareData && node.hddFree != node.noHardwareData)
        {
            viewModel.storageTotal = convertByteToMB(node.hddTotal)
            viewModel.storageFree = convertByteToMB(node.hddFree)
            viewModel.storageProgress = if(node.hddTotal != 0.0) (node.hddTotal - node.hddFree) / node.hddTotal else 0.0
        }
        else
        {
            viewModel.storageTotal = "N/A"
            viewModel.storageFree = "N/A"
            viewModel.storageProgress = 0.0
        }

        if(node.ramFree != node.noHardwareData && node.ramTotal != node.noHardwareData)
        {
            viewModel.ramTotal = convertByteToMB(node.ramTotal)
            viewModel.ramFree = convertByteToMB(node.ramFree)
            viewModel.ramProgress = if(node.ramTotal != 0.0) (node.ramTotal - node.ramFree) / node.ramTotal else 0.0
        }
        else
        {
            viewModel.ramTotal = "N/A"
            viewModel.ramFree = "N/A"
            viewModel.ramProgress = 0.0
        }
    }

    private fun prepareProgressModels(temps: List<Double>, loads: List<Double>, symbolTemp: String, symbolLoad: String, dividerTemp: Int, dividerLoad: Int, title: String): List<CPUAndTempProgressVM>
    {
        val result: MutableList<CPUAndTempProgressVM> = ArrayList()
        val size = Math.max(temps.size, loads.size)
        val tempsSize = temps.size
        val loadsSize = loads.size
        for(itemIndex in 0 until size)
        {
            var progressTemp = 0.0
            var tempValue = 0.0
            if(tempsSize >= itemIndex + 1)
            {
                tempValue = temps[itemIndex]
                progressTemp = tempValue / dividerTemp
            }

            var progressLoad = 0.0
            var loadValue = 0.0
            if(loadsSize >= itemIndex + 1)
            {
                loadValue = loads[itemIndex]
                progressLoad = loadValue / dividerLoad
            }

            var itemTitle = title
            if(size > 1)
                itemTitle = String.format("%s %s", title, itemIndex + 1)

            result.add(CPUAndTempProgressVM(Math.round(progressTemp * 100).toInt(), Math.round(progressLoad * 100).toInt(), tempValue, loadValue, symbolTemp, symbolLoad, itemTitle))
        }
        return result
    }

    private fun prepareProgressModelsTemp(temps: List<Double>, symbolTemp: String, dividerTemp: Int, title: String): List<CPUAndTempProgressVM>
    {
        val result: MutableList<CPUAndTempProgressVM> = ArrayList()
        val size = temps.size
        for(itemIndex in 0 until size)
        {
            val progressTemp = temps[itemIndex] / dividerTemp
            var itemTitle = title
            if(size > 1)
                itemTitle = String.format("%s %s", title, itemIndex + 1)
            result.add(CPUAndTempProgressVM(tempProgress = Math.round(progressTemp * 100).toInt(), tempValue = temps[itemIndex], tempSymbol = symbolTemp, useLoad = false, title = itemTitle))
        }
        return result
    }

    private fun convertByteToMB(size: Double): String
    {
        if(size <= 0)
            return "0"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        val digitGroups = (Math.log10(size) / Math.log10(1024.0)).toInt()
        return DecimalFormat("#,##0.##").format(size / Math.pow(1024.0, digitGroups.toDouble())) + " " + units[digitGroups]
    }

    override fun saveChanges()
    {
    }
}
