package com.evogence.eilink.screens.nodeDetails.tabs.profileTab

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class ProfileVM
{
    var location: String = ""
    var company: String = ""
    var ipAddress: String = ""
    var timeZone: String = ""
    var registrationDate: String = ""
    var videoChannels: String = ""
    var audioChannels: String = ""
    var activity: String = ""
    var rebootScheduler: String = ""
    var upTime: String = ""
    var systemTime: String = ""
    var rebootSchedulerColor: Int = 0
    var sId: String = ""
    var edition: String = ""
}
