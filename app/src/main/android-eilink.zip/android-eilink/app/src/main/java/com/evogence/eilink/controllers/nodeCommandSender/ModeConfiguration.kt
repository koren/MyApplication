package com.evogence.eilink.controllers.nodeCommandSender

import com.evogence.eilink.models.node.ENodeOnlineStatus

class ModeConfiguration
{
    var snList: String = ""
    var snManual: String = ""
    var typeLink: EPairType = EPairType.MANUALY
    var ip: String = ""
    var edition: String = ""
    var model: String = ""
    var systemID: String = ""
    var title: String = ""
    var version: String = ""
    var onlineStatus: ENodeOnlineStatus = ENodeOnlineStatus.OFFLINE
    var mode: String = ""
    var pairSN: String = ""
    var timeout: Double = 0.0
    var isEnablePort: Boolean = false
    var isEnableWatchdog: Boolean = false
    var pairState: EPairState = EPairState.UNPAIR
}