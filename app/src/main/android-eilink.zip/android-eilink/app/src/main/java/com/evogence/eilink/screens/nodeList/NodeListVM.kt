package com.evogence.eilink.screens.nodeList

/**
 * Created by Koren Vitalii on 05/21/18.
 */
class NodeListVM
{
    var enableSwipe: Boolean = false
    val nodes: MutableList<NodeListItemVM> = mutableListOf()
    val controllers: MutableList<NodeListItemVM> = mutableListOf()
    val notSupported: MutableList<NodeListItemVM> = mutableListOf()
    val titleList: MutableList<String> = mutableListOf()
    var currentPage: Int = 0
}
