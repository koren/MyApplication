package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab

import com.evogence.eilink.controllers.nodeCommandSender.ModeConfiguration

class AuxModeVM
{
    var modeConfiguration = ModeConfiguration()

    var iconName: String = ""
    var model: String = ""
    var title: String = ""
    var ip: String = ""
    var version: String = ""
    val info: String = ""
}
