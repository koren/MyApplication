package com.evogence.eilink.common.json_rpc

/**
 * Created by Anatolij on 10/21/17.
 */

class JsonRpcRequest(var method: String, params: Map<*, *>)
{
	var id: Long = 0
	var params: Map<String, Any> = params as Map<String, Any>
	var jsonrpc: String = "2.0"

}
