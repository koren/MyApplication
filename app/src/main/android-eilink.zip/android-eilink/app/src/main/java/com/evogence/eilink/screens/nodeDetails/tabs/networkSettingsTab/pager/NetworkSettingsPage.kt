package com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.pager

import android.support.v4.app.Fragment
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.NetworkSettingsVM

abstract class NetworkSettingsPage: Fragment()
{
    abstract val title: String
    abstract var changeSaveButtonStatusListener: (()->Unit)?

    abstract fun fill(viewModel: NetworkSettingsVM)
    abstract fun retrieveChanges(model: NetworkSettingsVM)
    abstract fun refresh()
    abstract fun retrieveChanges()
}
