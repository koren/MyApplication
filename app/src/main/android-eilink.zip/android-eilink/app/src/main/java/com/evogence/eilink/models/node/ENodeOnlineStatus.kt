package com.evogence.eilink.models.node

enum class ENodeOnlineStatus(val value: String)
{
    OFFLINE("offline"),
    ONLINE("online");

    companion object
    {
        fun get(status: String): ENodeOnlineStatus
        {
            return when(status)
            {
                ENodeOnlineStatus.OFFLINE.value -> ENodeOnlineStatus.OFFLINE
                ENodeOnlineStatus.ONLINE.value -> ENodeOnlineStatus.ONLINE
                else -> ENodeOnlineStatus.OFFLINE
            }
        }
    }
}