package com.evogence.eilink.screens.nodeList.tabs

import android.os.Parcelable
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentStatePagerAdapter
import android.support.v4.view.PagerAdapter
import java.util.*

/**
 * Created by Koren Vitalii on 8/27/2018.
 */
class NodeListViewPagerAdapter(manager: FragmentManager): FragmentStatePagerAdapter(manager)
{
    val fragmentList = ArrayList<Fragment>()

    override fun getItem(position: Int): Fragment
    {
        return fragmentList[position]
    }

    override fun getCount(): Int
    {
        return fragmentList.size
    }

    fun addFragment(fragment: Fragment)
    {
        fragmentList.add(fragment)
    }

    override fun getItemPosition(item: Any): Int
    {
        return PagerAdapter.POSITION_NONE
    }

    override fun restoreState(state: Parcelable?, loader: ClassLoader?)
    {
        super.restoreState(null, loader)
    }
}