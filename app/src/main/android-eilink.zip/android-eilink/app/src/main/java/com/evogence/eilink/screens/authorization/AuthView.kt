package com.evogence.eilink.screens.authorization

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import com.evogence.eilink.common.ui.ScreenView
import kotlinx.android.synthetic.main.authorization.*

/**
 * Created by Koren Vitalii on 8/28/2018.
 */
class AuthView: ScreenView(), View.OnClickListener
{
    lateinit var presenter: AuthPresenter

    companion object
    {
        fun build(): AuthView
        {
            return AuthView()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?)
    {
        presenter = AuthPresenter()
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.authorization, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        initView()
        presenter.onAttachView(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.loginBtn -> presenter.onLogin()
        }
    }

    override fun onDestroyView()
    {
        presenter.onDetachView()
        super.onDestroyView()
    }

    override fun fill(model: Any)
    {
        model as AuthVM
        usernameEt.setText(model.username)
        passwordEt.setText(model.password)
        titleTV.text = model.title
    }

    fun retrieveChanges(model: AuthVM)
    {
        model.username = usernameEt.text.toString()
        model.password = passwordEt.text.toString()
    }

    private fun initView()
    {
        loginBtn.setOnClickListener(this)
    }
}