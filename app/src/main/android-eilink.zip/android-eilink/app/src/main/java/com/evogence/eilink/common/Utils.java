package com.evogence.eilink.common;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.telephony.TelephonyManager;

import com.evogence.eilink.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by viro on 29.09.15.
 */
public class Utils
{
    private static String uuid = null;

    public static String getWifiIpAddress(Context context) throws Exception
    {
        WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
        if(wifiManager.getWifiState() == WifiManager.WIFI_STATE_ENABLED)
        {
            int ipAddress = wifiManager.getConnectionInfo().getIpAddress();
            String ip = String.format("%d.%d.%d.%d", (ipAddress & 0xff), (ipAddress >> 8 & 0xff),
                    (ipAddress >> 16 & 0xff), (ipAddress >> 24 & 0xff));
            return ip;
        }
        else
            throw new Exception("Not connected to wifi");
    }

    public static String md5(String s)
    {
        try
        {
            MessageDigest digest = java.security.MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            StringBuffer hexString = new StringBuffer();
            for(int i = 0; i < messageDigest.length; i++)
            {
                String h = Integer.toHexString(0xFF & messageDigest[i]);
                while(h.length() < 2)
                    h = "0" + h;

                hexString.append(h);
            }
            return hexString.toString();

        }
        catch(NoSuchAlgorithmException e)
        {
            e.printStackTrace();
        }
        return "";
    }

    public static String getUuid(Context _context)
    {
        if(uuid != null)
            return uuid;

        final TelephonyManager tm = (TelephonyManager) _context.getSystemService(Context.TELEPHONY_SERVICE);

        final String tmDevice, tmSerial, androidId;
        tmDevice = "" + tm.getDeviceId();
        tmSerial = "" + tm.getSimSerialNumber();
        androidId = "" + android.provider.Settings.Secure.getString(_context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

        UUID deviceUuid = new UUID(androidId.hashCode(), ((long) tmDevice.hashCode() << 32) | tmSerial.hashCode());

        return deviceUuid.toString();
    }

    public static Map<String, Integer> convertToMap(String jsonString)
    {
        Map<String, Integer> myHashMap = new HashMap<String, Integer>();
        try
        {
            JSONArray jArray = new JSONArray(jsonString);
            JSONObject jObject = null;
            String keyString = null;
            for(int i = 0; i < jArray.length(); i++)
            {
                jObject = jArray.getJSONObject(i);
                // beacuse you have only one key-value pair in each object so I have used index 0
                keyString = (String) jObject.names().get(0);
                myHashMap.put(keyString, jObject.getInt(keyString));
            }
        }
        catch(JSONException e)
        {
            e.printStackTrace();
        }
        return myHashMap;
    }

    public static int prepareIconRes(Context context, String iconName)
    {
        int res = context.getResources().getIdentifier(iconName.toLowerCase(), "drawable", context.getPackageName());
        if(res == 0)
            res = R.drawable.icon_model_unknown;
        return res;
    }

}
