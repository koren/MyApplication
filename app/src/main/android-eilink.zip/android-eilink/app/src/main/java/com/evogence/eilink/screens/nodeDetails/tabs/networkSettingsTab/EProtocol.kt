package com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab

/**
 * Created by Koren Vitalii on 8/23/2018.
 */
enum class EProtocol(val key: String, val value: String)
{
    NONE("NONE", "NONE"), WEP("WEP", "WEP"), WPA_PSK("WPA-PSK", "WPA/WPA2 PSK"), WPA_EAP_PEAP("WPA-EAP-PEAP", "WPA/WPA2 EAP PEAP");

    companion object
    {
        fun getKey(value: String): String
        {
            var key = EProtocol.NONE.key
            EProtocol.values().forEach {
                if(it.value == value)
                    key = it.key
            }
            return key
        }
    }

}