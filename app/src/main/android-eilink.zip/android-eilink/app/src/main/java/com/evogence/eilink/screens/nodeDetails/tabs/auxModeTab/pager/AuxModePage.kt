package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.pager

import android.support.v4.app.Fragment
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.AuxModeVM
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.IAuxModeView

abstract class AuxModePage: Fragment()
{
    abstract val title: String
    abstract var auxModeView: IAuxModeView?

    abstract fun fill(model: AuxModeVM)
    abstract fun retrieveChanges(model: AuxModeVM)
}
