package com.evogence.eilink.screens.nodeDetails.tabs

interface INodeDetailsTabViewTitleBar
{
    val title: String
    val isShowSaveButton: Boolean
    var changeSaveButtonStatusListener: ((enableSaveButton: Boolean)->Unit)?

    fun onClickSave()
    fun enableSaveButton(enable: Boolean)
}
