package com.evogence.eilink.controllers.authManager

/**
 * Created by Koren Vitalii on 8/28/2018.
 */
enum class EAuthStatus(val value: Int)
{
    OFFLINE_AUTH(-1),
    NON_AUTH(0),
    ONLINE_AUTH(1)
}