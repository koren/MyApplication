package com.evogence.eilink.screens.nodeDetails.tabs.integrationTab

/**
 * Created by Koren Vitalii on 9/6/2018.
 */

open class NodeIntegrationVM: Cloneable
{
    /*Management*/
    var enableManagementServer: Boolean = false
    var useServerToGetUpdates: Boolean = false
    var useSftp: Boolean = false
    var esTaskCompletionTimeout: String = ""
    var serverIpAddressOrDomain: String = ""
    var httpPort: String = ""
    var sshPort: String = ""
    var ftpPort: String = ""
    var registrationToken: String = ""
    var secondaryServerIpAddressOrDomain: String = ""
    var secondaryHttpPort: String = ""
    var secondarySshPort: String = ""
    var secondaryFtpPort: String = ""
    var resultMessageManagementServer: String = ""
    var resultMessageManagementServerError: Boolean = false
    /*Reverse monitoring*/
    var useTunnelReverseMonitoringServer: Boolean = false
    var tunnelAddressReverseMonitoringServer: String = ""
    var resultMessageReverseMonitoringServer: String = ""
    var resultMessageReverseMonitoringServerError: Boolean = false
    /*Update*/
    var isEnableUpdateServer: Boolean = false
    var addressUpdateServer: String = ""
    var resultMessageUpdateServer: String = ""
    var resultMessageUpdateServerError: Boolean = false

    override fun hashCode(): Int
    {
        var result = enableManagementServer.hashCode()
        result = 31 * result + useServerToGetUpdates.hashCode()
        result = 31 * result + useSftp.hashCode()
        result = 31 * result + esTaskCompletionTimeout.hashCode()
        result = 31 * result + serverIpAddressOrDomain.hashCode()
        result = 31 * result + httpPort.hashCode()
        result = 31 * result + sshPort.hashCode()
        result = 31 * result + ftpPort.hashCode()
        result = 31 * result + registrationToken.hashCode()
        result = 31 * result + secondaryServerIpAddressOrDomain.hashCode()
        result = 31 * result + secondaryHttpPort.hashCode()
        result = 31 * result + secondarySshPort.hashCode()
        result = 31 * result + secondaryFtpPort.hashCode()
        result = 31 * result + resultMessageManagementServer.hashCode()
        result = 31 * result + resultMessageManagementServerError.hashCode()
        result = 31 * result + useTunnelReverseMonitoringServer.hashCode()
        result = 31 * result + tunnelAddressReverseMonitoringServer.hashCode()
        result = 31 * result + resultMessageReverseMonitoringServer.hashCode()
        result = 31 * result + resultMessageReverseMonitoringServerError.hashCode()
        result = 31 * result + isEnableUpdateServer.hashCode()
        result = 31 * result + addressUpdateServer.hashCode()
        return result
    }

    override fun equals(other: Any?): Boolean
    {
        return hashCode() == (other as NodeIntegrationVM).hashCode()
    }

    fun copy(): NodeIntegrationVM
    {
        return this.clone() as NodeIntegrationVM
    }
}