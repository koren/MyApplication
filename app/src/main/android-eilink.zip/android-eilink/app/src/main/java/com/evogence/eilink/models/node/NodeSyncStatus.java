package com.evogence.eilink.models.node;

/**
 * Created by Koren Vitalii on 21.04.2018.
 */
public class NodeSyncStatus
{
    public String fingerprint;
    public EProcessing processing;
    public String message;

    public NodeSyncStatus()
    {
        processing = EProcessing.WAITING_SYNC;
    }

    public enum EProcessing
    {
        WAITING_SYNC, SYNCHRONIZING, END_SYNC
    }
}
