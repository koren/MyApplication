package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive

/**
 * Created by Koren Vitalii on 9/4/2018.
 */
class SetRemoteNodeSwitchSettingsCommand(parameters: Any?): INodeCommand
{
    override var params: MutableMap<String, Any> = HashMap()
    override val method: String = "Integration.RPN.settings.ContextualDeviceService::remoteNodeSetSwitchSettings"
    override val desc: String = "Set Remote [Ei] Node Switch Settings"

    companion object MapKeys
    {
        const val PARAMS_KEY = "params"
        const val STATUS_KEY = "status"
        const val SERIAL_KEY = "serial"
        const val EISWITCH_KEY = "eiswitch"
        const val ENABLED_KEY = "enabled"
        const val WATCHDOG_NODE_SERIAL_KEY = "watchdog_node_serial"
        const val WATCHDOG_TIMEOUT_KEY = "watchdog_timeout"
    }

    init
    {
        if(parameters != null)
            params[PARAMS_KEY] = parameters
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonObject)?.has(STATUS_KEY) ?: false && !(((response.result as? JsonObject)?.get(STATUS_KEY) as? JsonPrimitive)?.asString ?: "").isEmpty()
    }
}