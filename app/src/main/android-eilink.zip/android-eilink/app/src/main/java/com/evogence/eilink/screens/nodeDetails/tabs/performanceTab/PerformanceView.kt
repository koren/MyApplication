package com.evogence.eilink.screens.nodeDetails.tabs.performanceTab

import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.widget.GridLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import com.evogence.eilink.common.ui.GridDividerItemDecoration
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabView
import kotlinx.android.synthetic.main.node_details_performance.*


/**
 * Created by Koren Vitalii on 05/29/18.
 */
class PerformanceView: NodeDetailsTabView<PerformanceVM>()
{
    override val title: String = "Performance"
    override val isShowSaveButton: Boolean = false
    override val layout: Int = R.layout.node_details_performance
    private var model: PerformanceVM? = null

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"

        fun build(fingerprint: String): PerformanceView
        {
            val fragment = PerformanceView()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }
    }

    override fun initPresenter()
    {
        presenter = PerformancePresenter(arguments?.getString(FINGERPRINT_KEY))
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        val view = inflater.inflate(layout, container, false)
        if(model != null)
            fill(model!!)
        return view
    }

    override fun fill(model: Any)
    {
        model as PerformanceVM
        this.model = model
        val hardwareCpuLoadAdapter = context?.let {ProgressBarTempAndLoadAdapter(it, model.cpuAndTempProgress)}
        cpuLoadAndTempGrid?.layoutManager = GridLayoutManager(activity, 2)
        cpuLoadAndTempGrid?.adapter = hardwareCpuLoadAdapter

        val horizontalDivider = ContextCompat.getDrawable(context!!, R.drawable.empty_divider_horizontal)
        val verticalDivider = ContextCompat.getDrawable(context!!, R.drawable.empty_divider)
        cpuLoadAndTempGrid.addItemDecoration(GridDividerItemDecoration(horizontalDivider, verticalDivider, 2, 0))

        val hardwareGpuTempAdapter = activity?.let {ProgressBarTempAndLoadAdapter(it, model.gpuTemp)}
        gpuTempGrid?.layoutManager = GridLayoutManager(activity, 2)
        gpuTempGrid?.adapter = hardwareGpuTempAdapter

        ramTotalTV?.text = model.ramTotal
        ramFreeTV?.text = model.ramFree
        ramPB?.progress = (100 * model.ramProgress).toInt()
        ramContainer?.visibility = (if(model.ramProgress < 0.001) View.GONE else View.VISIBLE)
        storageTotalTV?.text = model.storageTotal
        storageFreeTV?.text = model.storageFree
        storagePB?.progress = (100 * model.storageProgress).toInt()
        storageContainer?.visibility = if(model.storageProgress < 0.001) View.GONE else View.VISIBLE
    }

    override fun initView()
    {
    }

    override fun retrieveChanges(model: PerformanceVM)
    {
    }
}
