package com.evogence.eilink;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import butterknife.BindView;
import io.reactivex.Maybe;
import io.reactivex.android.schedulers.AndroidSchedulers;

public class MainActivity extends AppCompatActivity
{
    @BindView(R.id.ll_progress_container) View progressContainer;
    @BindView(R.id.tv_progress) TextView progressText;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setTheme(R.style.AppTheme);
        setContentView(R.layout.activity_main);
        progressContainer = findViewById(R.id.ll_progress_container);
        progressText = findViewById(R.id.tv_progress);

        startApplication();
    }

    public void showProgress(String text)
    {
        Maybe.fromAction(() -> {
                    progressContainer.setVisibility(View.VISIBLE);

                    if(text != null)
                        progressText.setText(text);
                }
        ).subscribeOn(AndroidSchedulers.mainThread()).subscribe();
    }

    public void hideProgress()
    {
        Maybe.fromAction(() -> {
                    progressContainer.setVisibility(View.GONE);
                    progressText.setText("");
                }
        ).subscribeOn(AndroidSchedulers.mainThread()).subscribe();
    }

    private void startApplication()
    {
        ((EiLinkApplication) getApplicationContext()).start(this);
    }
}