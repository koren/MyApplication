package com.evogence.eilink.screens.nodeDetails.tabs.restartSchedulerTab

import com.evogence.eilink.common.BlockRunnable
import com.evogence.eilink.common.EMeridium
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.controllers.nodeCommandSender.ENodeCommand
import com.evogence.eilink.screens.nodeDetails.tabs.INodeDetailsTabView
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabPresenter
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Koren Vitalii on 05/29/18.
 */
open class RestartSchedulerPresenter(fingerprint: String?): NodeDetailsTabPresenter<RestartSchedulerVM>(fingerprint)
{
    override var viewModel = RestartSchedulerVM()
    private lateinit var commandsSaveList: MutableList<()->Unit>
    private var resultCommandError = ""
    private var resultCommandInfo = ""
    private val inFormat = SimpleDateFormat("hh:mm aa", Locale.getDefault())
    override fun saveChanges()
    {
        resultCommandError = ""
        resultCommandInfo = ""
        sendQueueSaveCommand()
    }

    override fun attachView(view: INodeDetailsTabView<RestartSchedulerVM>)
    {
        commandsSaveList = mutableListOf({saveRestartNodeScheduler()}, {savePlaybackRestartScheduler()}, {saveShutdownNodeScheduler()})
        viewModelBeforeChanges = viewModel.copy()
        super.attachView(view)
    }

    override fun prepareViewModel()
    {
        val hourFormat = SimpleDateFormat("hh", Locale.getDefault())
        val minuteFormat = SimpleDateFormat("mm", Locale.getDefault())
        val meridianFormat = SimpleDateFormat("aa", Locale.getDefault())

        var time = timeFromString(dateFrom(node.rebootHour, node.rebootMinute, node.rebootMeridiem))
        viewModel.timeRestartNodeSchedulerText = inFormat.format(time)
        viewModel.restartNodeSchedulerEnabled = node.rebootEnabled
        viewModel.restartNodeHour = hourFormat.format(time).toInt()
        viewModel.restartNodeMinute = minuteFormat.format(time).toInt()
        viewModel.restartNodeMeridian = EMeridium.get(meridianFormat.format(time))

        time = timeFromString(dateFrom(node.playbackRestartHour, node.playbackRestartMinute, node.playbackRestartMeridiem))
        viewModel.timePlaybackRestartSchedulerText = inFormat.format(time)
        viewModel.restartPlaybackSchedulerEnabled = node.playbackRestartEnabled
        viewModel.restartPlaybackHour = hourFormat.format(time).toInt()
        viewModel.restartPlaybackMinute = minuteFormat.format(time).toInt()
        viewModel.restartPlaybackMeridian = EMeridium.get(meridianFormat.format(time))

        time = timeFromString(dateFrom(node.shutdownHour, node.shutdownMinute, node.shutdownMeridiem))
        viewModel.timeShutdownNodeSchedulerText = inFormat.format(time)
        viewModel.shutdownNodeSchedulerEnabled = node.shutdownEnabled
        viewModel.shutdownHour = hourFormat.format(time).toInt()
        viewModel.shutdownMinute = minuteFormat.format(time).toInt()
        viewModel.shutdownMeridian = EMeridium.get(meridianFormat.format(time))

        viewModelBeforeChanges = viewModel.copy()
    }

    private fun dateFrom(shutdownHour: Int?, shutdownMinute: Int?, shutdownMeridiem: String): String
    {
        return String.format("%s:%s %s", convertDate(shutdownHour ?: 0, 2), convertDate(shutdownMinute ?: 0, 2), EMeridium.get(shutdownMeridiem))
    }

    private fun convertDate(input: Int, range: Int): String
    {
        val inputString = String.format("00%s", input.toString())
        return inputString.substring(inputString.length - range, inputString.length)
    }

    private fun sendQueueSaveCommand()
    {
        if(commandsSaveList.isNotEmpty())
        {
            val command = commandsSaveList[0]
            commandsSaveList.removeAt(0)
            command.invoke()
        }
        else
        {
            if(resultCommandError.isNotEmpty())
                view?.showAlertDialog("Error", resultCommandError)

            if(resultCommandInfo.isNotEmpty())
            {
                view?.showAlertDialog("Info", resultCommandInfo)
                viewModelBeforeChanges = viewModel.copy()
                view?.enableSaveButton(false)
            }

            commandsSaveList = mutableListOf({saveRestartNodeScheduler()}, {savePlaybackRestartScheduler()}, {saveShutdownNodeScheduler()})
            view?.hideProgress()
        }
    }

    protected fun saveShutdownNodeScheduler()
    {
        val parameters = mapOf("type" to ERebootAndShutdownCommand.SHUTDOWN_APPLIANCE, "status" to if(viewModel.restartNodeSchedulerEnabled) 1 else 0, "meridiem" to viewModel.restartNodeMeridian.title.toLowerCase(), "hour" to viewModel.restartNodeHour, "type" to ERebootAndShutdownCommand.REBOOT_SCHEDULER.type, "minute" to viewModel.restartNodeMinute)
        sendSaveCommand(parameters) {refreshShutdownPartOfNode()}
    }

    protected fun savePlaybackRestartScheduler()
    {
        val parameters = mapOf("type" to ERebootAndShutdownCommand.REBOOT_PLAYBACK, "status" to if(viewModel.restartPlaybackSchedulerEnabled) 1 else 0, "meridiem" to viewModel.restartPlaybackMeridian.title.toLowerCase(), "hour" to viewModel.restartPlaybackHour, "type" to ERebootAndShutdownCommand.REBOOT_PLAYBACK.type, "minute" to viewModel.restartPlaybackMinute)
        sendSaveCommand(parameters) {refreshPlaybackPartOfNode()}
    }

    protected fun saveRestartNodeScheduler()
    {
        val parameters = mapOf("type" to ERebootAndShutdownCommand.REBOOT_SCHEDULER, "status" to if(viewModel.shutdownNodeSchedulerEnabled) 1 else 0, "meridiem" to viewModel.shutdownMeridian.title.toLowerCase(), "hour" to viewModel.shutdownHour, "type" to ERebootAndShutdownCommand.SHUTDOWN_APPLIANCE.type, "minute" to viewModel.shutdownMinute)
        sendSaveCommand(parameters) {refreshRestartNodePartOfNode()}
    }

    private fun sendSaveCommand(parameters: Map<*, *>, refreshNode: ()->Unit)
    {
        commandSender.send(ENodeCommand.SET_SCHEDULE_REBOOT_AND_SHUTDOWN, node, parameters, BlockRunnable {processingSaveCommand(it, refreshNode)})
    }

    protected open fun processingSaveCommand(commandResult: CommandResult, refreshNode: ()->Unit)
    {
        if(commandResult.error != null)
            resultCommandError = String.format("%s\n%s", resultCommandError, commandResult.error)
        else
            refreshNode.invoke()

        sendQueueSaveCommand()
    }

    private fun refreshPlaybackPartOfNode()
    {
        node.playbackRestartHour = viewModel.restartPlaybackHour
        node.playbackRestartMinute = viewModel.restartPlaybackMinute
        node.playbackRestartMeridiem = viewModel.restartPlaybackMeridian.name
        node.playbackRestartEnabled = viewModel.restartPlaybackSchedulerEnabled
        resultCommandInfo = String.format("%s\n%s", resultCommandInfo, "Save playback completed successfully")
    }

    private fun refreshShutdownPartOfNode()
    {
        node.shutdownHour = viewModel.shutdownHour
        node.shutdownMinute = viewModel.shutdownMinute
        node.shutdownMeridiem = viewModel.shutdownMeridian.name
        node.shutdownEnabled = viewModel.shutdownNodeSchedulerEnabled
        resultCommandInfo = String.format("%s\n%s", resultCommandInfo, "Save shutdown completed successfully")
    }

    private fun refreshRestartNodePartOfNode()
    {
        node.rebootHour = viewModel.restartNodeHour
        node.rebootMinute = viewModel.restartNodeMinute
        node.rebootMeridiem = viewModel.restartNodeMeridian.name
        node.rebootEnabled = viewModel.restartNodeSchedulerEnabled
        resultCommandInfo = String.format("%s\n%s", resultCommandInfo, "Save restart completed successfully")
    }

    private fun timeFromString(dateString: String, defaultCurrentTime: Boolean = true): Date
    {
        return try
        {
            inFormat.parse(dateString.toUpperCase())
        }
        catch(pe: ParseException)
        {
            if(!defaultCurrentTime)
            {
                val calendar = GregorianCalendar.getInstance()
                calendar.set(Calendar.HOUR_OF_DAY, 12)
                calendar.set(Calendar.MINUTE, 0)
                calendar.time
            }
            else
                Date()
        }
    }
}
