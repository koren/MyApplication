package com.evogence.eilink.controllers.apiServices;

import com.evogence.eilink.common.json_rpc.JsonRpcResponse;

import io.reactivex.Flowable;

/**
 * Created by Anatolij on 4/16/18.
 */
public interface CentralAPIInterface
{
    Flowable<JsonRpcResponse> checkConnection();

    Flowable<JsonRpcResponse> authByPin(String pin, String companyCode);

    Flowable<JsonRpcResponse> authByLogin(String login, String password, String companyCode);

    String getUrl();
}
