package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab

import com.evogence.eilink.R
import com.evogence.eilink.common.BlockRunnable
import com.evogence.eilink.common.dialogs.AlertDialogFragment
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.controllers.nodeCommandSender.ENodeCommand
import com.evogence.eilink.controllers.nodeCommandSender.EPairState
import com.evogence.eilink.controllers.nodeCommandSender.EPairType
import com.evogence.eilink.controllers.nodeCommandSender.ModeConfiguration
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetModeConfigurationCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetPairControllerCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.parameters.PairControllerParams
import com.evogence.eilink.controllers.nodeCommandSender.commands.parameters.PairNodeParams
import com.evogence.eilink.controllers.nodeCommandSender.commands.parameters.RemoteNodeSwitchSettingsParams
import com.evogence.eilink.models.node.ENodeOnlineStatus
import com.evogence.eilink.models.node.Node
import com.evogence.eilink.screens.nodeDetails.tabs.INodeDetailsTabView
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabPresenter

class AuxModePresenter(fingerprint: String?): NodeDetailsTabPresenter<AuxModeVM>(fingerprint)
{
    override val viewModel = AuxModeVM()

    private var nodeList: List<ListItemVM> = listOf()

    override fun prepareViewModel()
    {
        if(viewModel.modeConfiguration.snList.isNotEmpty())
        {
            val node = getNode(viewModel.modeConfiguration.snList)
            node?.let {
                viewModel.ip = it.address
                viewModel.model = it.model
                viewModel.title = it.title
                viewModel.version = it.version
                viewModel.iconName = it.getIconName()
            }
        }
    }

    fun prepareViewModel(modeConfiguration: ModeConfiguration)
    {
        viewModel.modeConfiguration = modeConfiguration
        if(viewModel.modeConfiguration.pairState == EPairState.PAIR)
            viewModel.modeConfiguration.onlineStatus = if(getNode(modeConfiguration.pairSN) == null) ENodeOnlineStatus.OFFLINE else ENodeOnlineStatus.ONLINE
    }

    override fun saveChanges()
    {
        view?.showProgress("Processing...")
        view?.retrieveChanges(viewModel)

        val timeout = if(viewModel.modeConfiguration.isEnablePort && viewModel.modeConfiguration.isEnableWatchdog) viewModel.modeConfiguration.timeout else 0.0

        val parameters = RemoteNodeSwitchSettingsParams(viewModel.modeConfiguration.pairSN, if(viewModel.modeConfiguration.isEnablePort) 1 else 0, viewModel.modeConfiguration.pairSN, timeout).buildMap()

        commandSender.send(ENodeCommand.SET_REMOTE_NODE_SWITCH_SETTINGS, node, parameters, BlockRunnable {
            view?.hideProgress()
            if(it.error == null)
                view?.showAlertDialog("Info", "Successful")
            else
                showCommandError(it)
        })
    }

    override fun attachView(view: INodeDetailsTabView<AuxModeVM>)
    {
        super.attachView(view)
        sendCommandGetModeConfiguration()
    }

    fun onUnpair()
    {
        view?.showProgress("Processing...")

        val nodeForPairing = getNode(viewModel.modeConfiguration.pairSN)

        if(nodeForPairing == null)
        {
            view?.hideProgress()
            view?.showAlertDialog("Error", "Node not found on local network")
        }
        else
            commandSender.send(ENodeCommand.SET_DISCONNECT_CONTROLLER, nodeForPairing, null, BlockRunnable {processingSetDisconnectControllerCommand(it)})
    }

    fun onRefresh()
    {
        sendCommandGetModeConfiguration()
    }

    fun selectNode()
    {
        nodeList = prepareNodeList()
        (view as IAuxModeView).showNodeList(nodeList)
    }

    fun onItemClick(nodeVM: ListItemVM)
    {
        viewModel.iconName = nodeVM.iconName
        viewModel.modeConfiguration.snList = nodeVM.serialNumber
        viewModel.modeConfiguration.typeLink = EPairType.LIST
        viewModel.ip = nodeVM.ip
        viewModel.title = nodeVM.title
        viewModel.model = nodeVM.model
        viewModel.version = nodeVM.version
        view?.fill(viewModel)
        (view as IAuxModeView).hideNodeList()
    }

    fun pairNode(force: Boolean = false)
    {
        view?.showProgress("Processing...")
        view?.retrieveChanges(viewModel)
        when(viewModel.modeConfiguration.typeLink)
        {
            EPairType.MANUALY ->
            {
                if(viewModel.modeConfiguration.snManual.isEmpty())
                {
                    view?.hideProgress()
                    view?.showAlertDialog("Info", "Please enter a serial number")
                    return
                }
            }
            EPairType.LIST ->
            {
                if(viewModel.modeConfiguration.snList.isEmpty())
                {
                    view?.hideProgress()
                    view?.showAlertDialog("Info", "Please select a Node from the list")
                    return
                }
            }
        }

        val nodeForPairing = when(viewModel.modeConfiguration.typeLink)
        {
            EPairType.MANUALY -> getNode(viewModel.modeConfiguration.snManual)
            EPairType.LIST -> getNode(viewModel.modeConfiguration.snList)
        }

        if(nodeForPairing == null)
        {
            view?.hideProgress()
            view?.showAlertDialog("Error", "[Ei] Node is unreachable")
        }
        else
            commandSender.send(ENodeCommand.SET_PAIR_CONTROLLER, nodeForPairing, PairControllerParams(nodeForPairing.sn, force).buildMap(), BlockRunnable {processingSetPairControllerCommand(it)})
    }

    private fun processingSetPairControllerCommand(commandResult: CommandResult)
    {
        if(commandResult.error != null)
        {
            view?.hideProgress()
            showCommandError(commandResult)
        }
        else
        {
            val status = commandResult.params[SetPairControllerCommand.STATUS_KEY] as? String

            when(status)
            {
                "pair_another" ->
                {
                    (view as IAuxModeView).showAlertDialogWithObserver("Info", "Already Paired with another device", R.string.force, android.R.string.ok, object: AlertDialogFragment.DialogResultObserver
                    {
                        override fun onClickPositive()
                        {
                            pairNode(true)
                        }
                    })
                }
                "pair", "pair_now" ->
                {
                    pairController()
                }
            }
        }
    }

    private fun pairController()
    {
        if(!node.sn.isEmpty())
        {
            val parameters = PairNodeParams(viewModel.modeConfiguration.snManual, viewModel.modeConfiguration.snList, viewModel.modeConfiguration.typeLink.value, true).buildMap()
            commandSender.send(ENodeCommand.SET_PAIR_NODE, node, parameters, BlockRunnable {processingSetPairNodeCommand(it)})
        }
    }

    private fun processingSetPairNodeCommand(commnadResult: CommandResult)
    {
        val error = commnadResult.error
        if(error == null)
        {
            val status = commnadResult.params[SetPairControllerCommand.STATUS_KEY]
            when(commnadResult.params[SetPairControllerCommand.STATUS_KEY])
            {
                "pair", "pair_now" -> showPaired()
                else -> view?.showAlertDialog("Error", "Pairing status: $status")
            }
        }
        else
            showCommandError(commnadResult)

        view?.hideProgress()
    }

    private fun showPaired()
    {
        val modeConfiguration = viewModel.modeConfiguration
        modeConfiguration.pairState = EPairState.PAIR
        val nodePaired = when(viewModel.modeConfiguration.typeLink)
        {
            EPairType.MANUALY -> getNode(viewModel.modeConfiguration.snManual)
            EPairType.LIST -> getNode(viewModel.modeConfiguration.snList)
        }

        if(nodePaired != null)
        {
            modeConfiguration.title = nodePaired.title
            modeConfiguration.ip = nodePaired.address
            modeConfiguration.pairSN = nodePaired.sn
            modeConfiguration.model = nodePaired.model
            modeConfiguration.version = nodePaired.version
            modeConfiguration.onlineStatus = ENodeOnlineStatus.ONLINE
        }
        else
        {
            modeConfiguration.onlineStatus = ENodeOnlineStatus.OFFLINE
        }

        view?.fill(viewModel)
    }

    private fun prepareNodeList(): List<ListItemVM>
    {
        val nodes = mutableListOf<ListItemVM>()

        nodesStorage.nodes.forEach {(key, value)->
            run {
                val model = ListItemVM()
                model.ip = value.address
                model.title = value.title
                model.serialNumber = value.sn
                model.model = value.model
                model.version = value.version
                model.iconName = value.getIconName()
                if(key != node.fingerprint)
                    nodes.add(model)
            }
        }
        return nodes
    }

    private fun sendCommandGetModeConfiguration()
    {
        view?.showProgress("Processing")
        commandSender.send(ENodeCommand.GET_MODE_CONFIGURATION, node, null, BlockRunnable {processingGetModeConfiguration(it)})
    }

    private fun getNode(serialNumber: String): Node?
    {
        return nodesStorage.getNodeBySerialNumber(serialNumber)
    }

    private fun processingSetDisconnectControllerCommand(commandResult: CommandResult)
    {
        if(commandResult.error != null)
            unpairCompletion(String.format("%s", commandResult.error))
        else
            commandSender.send(ENodeCommand.SET_DISCONNECT_NODE, node, null, BlockRunnable {processingSetDisconnectNodeCommand(it, commandResult.error)})
    }

    private fun processingSetDisconnectNodeCommand(result: CommandResult, error: String?)
    {
        val errorText = if((error != null) && (result.error != null))
            String.format("%s %s", error, result.error)
        else
            ""
        unpairCompletion(errorText)
    }

    private fun unpairCompletion(errorText: String)
    {
        view?.hideProgress()
        viewModel.modeConfiguration.pairState = EPairState.UNPAIR
        prepareViewModel()
        view?.fill(viewModel)

        if(errorText.isNotEmpty())
            view?.showAlertDialog("Error", errorText)
    }

    private fun processingGetModeConfiguration(commandResult: CommandResult)
    {
        if(commandResult.error != null)
            showCommandError(commandResult)
        else
        {
            prepareViewModel(GetModeConfigurationCommand.prepareResult(commandResult))
            view?.fill(viewModel)
        }
        view?.hideProgress()
    }

    private fun showCommandError(commandResult: CommandResult)
    {
        if(commandResult.isSupported)
            view?.showAlertDialog("Error", commandResult.error)
        else
            view?.showAlertDialog(message =  commandResult.error)
    }
}
