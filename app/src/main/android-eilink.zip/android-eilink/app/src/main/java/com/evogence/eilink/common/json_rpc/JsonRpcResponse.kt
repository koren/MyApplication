package com.evogence.eilink.common.json_rpc

import com.google.gson.JsonElement

/**
 * Created by Anatolij on 10/21/17.
 */

class JsonRpcResponse
{
    var id: Long? = null
    var result: JsonElement? = null
    var error: JsonRpcError? = null

    override fun toString(): String
    {
        return "id=" + id +
                " result=" + (if(result != null) result.toString() else "") +
                " error=" + if(error != null) error.toString() else ""
    }

    companion object
    {
        fun build(errorMessage: String): JsonRpcResponse
        {
            val response = JsonRpcResponse()
            val error = JsonRpcError()
            error.message = errorMessage
            response.error = error
            return response
        }
    }
}
