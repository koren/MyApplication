package com.evogence.eilink.models.node;

/**
 * Created by Koren Vitalii on 05/23/18.
 */
public enum ENodeStatus
{
}
