package com.evogence.eilink.controllers.nodesStorage

import com.evogence.eilink.models.node.Node

/**
 * Created by Koren Vitalii on 07/23/18.
 */
class NodesStorage: INodesStorage
{
    private var observers: ArrayList<INodesStorageObserver> = ArrayList()

    override var nodes: HashMap<String, Node> = HashMap()

    companion object
    {
        private const val MODE_DEVICE_PRODUCT_ID_EIC100 = "eic100"
        private const val SUPPORTED_VERSION_4_0_2 = "4.0.2"
        private const val SUPPORTED_VERSION_4_0_0_P1 = "4.0.0.p1"
        private const val SUPPORTED_VERSION_4_0_0_P_1 = "4.0.0.p.1"
    }

    override fun getDeviceByFingerprint(fingerprint: String): Node?
    {
        return try
        {
            nodes.getValue(fingerprint)
        }
        catch(e: NoSuchElementException)
        {
            null
        }
    }

    override fun getDevicesByFingerprint(fingerprints: Array<String>): List<Node>
    {
        val searchList = mutableListOf<Node>()
        nodes.forEach {(key, value)->
            if(fingerprints.contains(key))
                searchList.add(value)
        }
        return searchList
    }

    override fun getNodeBySerialNumber(serialNumber: String): Node?
    {
        var node: Node? = null
        nodes.forEach {(_, value)->
            run {
                if(value.sn == serialNumber)
                {
                    node = value
                    return@forEach
                }
            }
        }
        return node
    }

    override fun refreshLocalNodes(localNodes: List<Node>)
    {
        if(nodes.size > 0)
        {
            val isAdded = addNewNodes(localNodes)
            val isRemoved = removeOldNodes(localNodes)
            if(isAdded || isRemoved)
                notifyObservers(true)
            else
                notifyObservers(false)
        }
        else
        {
            for(node in localNodes)
                nodes[node.fingerprint] = node

            notifyObservers(true)
        }
    }

    override fun updateNode(node: Node)
    {
        nodes[node.fingerprint] = node
        notifyObservers(true)
    }

    override fun addObserver(observer: INodesStorageObserver)
    {
        observers.add(observer)
    }

    override fun removeObserver(observer: INodesStorageObserver)
    {
        observers.remove(observer)
    }

    override fun getNodes(): List<Node>
    {
        val result = mutableListOf<Node>()
        nodes.forEach {(_, value)->
            run {
                if(!isController(value.model) && isSupportedVersion(value.version))
                {
                    result.add(value)
                }
            }
        }
        return result
    }

    override fun getControllers(): List<Node>
    {
        val result = mutableListOf<Node>()
        nodes.forEach {(_, value)->
            run {
                if(isController(value.model) && isSupportedVersion(value.version))
                {
                    result.add(value)
                }
            }
        }
        return result
    }

    override fun getNotSupported(): List<Node>
    {
        val result = mutableListOf<Node>()
        nodes.forEach {(_, value)->
            run {
                if(!isSupportedVersion(value.version))
                {
                    result.add(value)
                }
            }
        }
        return result
    }

    override fun isController(model: String): Boolean
    {
        return model.toLowerCase() == MODE_DEVICE_PRODUCT_ID_EIC100
    }

    private fun isSupportedVersion(version: String): Boolean
    {
        return version >= SUPPORTED_VERSION_4_0_2 || version.contains(SUPPORTED_VERSION_4_0_0_P1) || version.contains(SUPPORTED_VERSION_4_0_0_P_1)
    }

    private fun removeOldNodes(localNodes: List<Node>): Boolean
    {
        val nodesForRemove = ArrayList<String>()
        for(node in nodes.values)
        {
            var isExist = false
            for(localNode in localNodes)
            {
                if(node.fingerprint == localNode.fingerprint)
                {
                    isExist = true
                    break
                }
            }
            if(!isExist)
                nodesForRemove.add(node.fingerprint)
        }

        for(fingerprint in nodesForRemove)
            nodes.remove(fingerprint)

        return (nodesForRemove.size > 0)
    }

    private fun notifyObservers(isUpdated: Boolean)
    {
        for(observer in observers)
            observer.nodesUpdated(isUpdated)
    }

    private fun addNewNodes(localNodes: List<Node>): Boolean
    {
        var isWasAddedNew = false
        for(node in localNodes)
        {
            if(nodes[node.fingerprint] == null)
            {
                nodes[node.fingerprint] = node
                isWasAddedNew = true
            }
        }

        return isWasAddedNew
    }
}