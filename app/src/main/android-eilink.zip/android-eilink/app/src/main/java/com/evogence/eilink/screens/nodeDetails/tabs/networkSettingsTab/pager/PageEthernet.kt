package com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.pager

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.NetworkSettingsVM
import kotlinx.android.synthetic.main.node_details_network_settings_ethernet_page.*

/**
 * Created by Koren Vitalii on 9/24/2018.
 */
class PageEthernet: NetworkSettingsPage(), View.OnClickListener
{
    override val title = "Ethernet"
    override var changeSaveButtonStatusListener: (()->Unit)? = null

    private var viewModel: NetworkSettingsVM? = null
    private var enableDataChangeListener = true

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"

        fun build(fingerprint: String?): Fragment
        {
            val fragment = PageEthernet()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.node_details_network_settings_ethernet_page, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        ipVersionSwitch.setOnClickListener(this)
        dhcpSwitch.setOnClickListener(this)
        viewModel?.let {fill(it)}
        super.onViewCreated(view, savedInstanceState)
    }

    override fun refresh()
    {
        viewModel?.let {fill(it)}
    }

    override fun retrieveChanges()
    {
        viewModel?.let {retrieveChanges(it)}
    }

    override fun fill(viewModel: NetworkSettingsVM)
    {
        enableDataChangeListener = false
        this.viewModel = viewModel
        dhcpSwitch?.isChecked = viewModel.ethernetIpDHCP
        ipVersionSwitch?.isChecked = viewModel.ethernetIpV4
        if(viewModel.ethernetIpV4)
        {
            val ethernetIpAddressV4 = viewModel.ethernetIpAddress.split(".")
            ethernetIpAddressV41ET?.setText(ethernetIpAddressV4.getOrNull(0) ?: "")
            ethernetIpAddressV42ET?.setText(ethernetIpAddressV4.getOrNull(1) ?: "")
            ethernetIpAddressV43ET?.setText(ethernetIpAddressV4.getOrNull(2) ?: "")
            ethernetIpAddressV44ET?.setText(ethernetIpAddressV4.getOrNull(3) ?: "")

            val ethernetNetmaskAddressV41 = viewModel.ethernetNetmask.split(".")
            ethernetNetmaskAddressV41ET?.setText(ethernetNetmaskAddressV41.getOrNull(0) ?: "")
            ethernetNetmaskAddressV42ET?.setText(ethernetNetmaskAddressV41.getOrNull(1) ?: "")
            ethernetNetmaskAddressV43ET?.setText(ethernetNetmaskAddressV41.getOrNull(2) ?: "")
            ethernetNetmaskAddressV44ET?.setText(ethernetNetmaskAddressV41.getOrNull(3) ?: "")

            val ethernetGatewayAddressV41 = viewModel.ethernetGateway.split(".")
            ethernetGatewayAddressV41ET?.setText(ethernetGatewayAddressV41.getOrNull(0) ?: "")
            ethernetGatewayAddressV42ET?.setText(ethernetGatewayAddressV41.getOrNull(1) ?: "")
            ethernetGatewayAddressV43ET?.setText(ethernetGatewayAddressV41.getOrNull(2) ?: "")
            ethernetGatewayAddressV44ET?.setText(ethernetGatewayAddressV41.getOrNull(3) ?: "")
        }
        else
        {
            ethernetIpAddressV6ET?.setText(viewModel.ethernetIpAddress)
            ethernetNetmaskAddressV6ET?.setText(viewModel.ethernetNetmask)
            ethernetGatewayAddressV6ET?.setText(viewModel.ethernetGateway)
        }

        val ethernetDns1V4 = viewModel.dns1.split(".")
        ethernetDns1V41ET?.setText(ethernetDns1V4.getOrNull(0) ?: "")
        ethernetDns1V42ET?.setText(ethernetDns1V4.getOrNull(1) ?: "")
        ethernetDns1V43ET?.setText(ethernetDns1V4.getOrNull(2) ?: "")
        ethernetDns1V44ET?.setText(ethernetDns1V4.getOrNull(3) ?: "")

        val ethernetDns2V4 = viewModel.dns2.split(".")
        ethernetDns2V41ET?.setText(ethernetDns2V4.getOrNull(0) ?: "")
        ethernetDns2V42ET?.setText(ethernetDns2V4.getOrNull(1) ?: "")
        ethernetDns2V43ET?.setText(ethernetDns2V4.getOrNull(2) ?: "")
        ethernetDns2V44ET?.setText(ethernetDns2V4.getOrNull(3) ?: "")

        val ethernetDns3V4 = viewModel.dns3.split(".")
        ethernetDns3V41ET?.setText(ethernetDns3V4.getOrNull(0) ?: "")
        ethernetDns3V42ET?.setText(ethernetDns3V4.getOrNull(1) ?: "")
        ethernetDns3V43ET?.setText(ethernetDns3V4.getOrNull(2) ?: "")
        ethernetDns3V44ET?.setText(ethernetDns3V4.getOrNull(3) ?: "")

        ipVersionSwitch?.let {onEthernetIpV4Switch()}
        dhcpSwitch?.let {onEthernetIpDHCPSwitch()}
        enableDataChangeListener = true
    }

    override fun retrieveChanges(model: NetworkSettingsVM)
    {
        model.ethernetIpDHCP = dhcpSwitch.isChecked
        model.ethernetIpV4 = ipVersionSwitch.isChecked

        if(ipVersionSwitch.isChecked)
        {
            model.ethernetIpAddress = String.format("%s.%s.%s.%s", ethernetIpAddressV41ET.text.toString(), ethernetIpAddressV42ET.text.toString(), ethernetIpAddressV43ET.text.toString(), ethernetIpAddressV44ET.text.toString())
            model.ethernetNetmask = String.format("%s.%s.%s.%s", ethernetNetmaskAddressV41ET.text.toString(), ethernetNetmaskAddressV42ET.text.toString(), ethernetNetmaskAddressV43ET.text.toString(), ethernetNetmaskAddressV44ET.text.toString())
            model.ethernetGateway = String.format("%s.%s.%s.%s", ethernetGatewayAddressV41ET.text.toString(), ethernetGatewayAddressV42ET.text.toString(), ethernetGatewayAddressV43ET.text.toString(), ethernetGatewayAddressV44ET.text.toString())
            model.ethernetIpAddress = model.ethernetIpAddress.replace("...", "")
            model.ethernetNetmask = model.ethernetNetmask.replace("...", "")
            model.ethernetGateway = model.ethernetGateway.replace("...", "")
        }
        else
        {
            model.ethernetIpAddress = ethernetIpAddressV6ET.text.toString()
            model.ethernetNetmask = ethernetNetmaskAddressV6ET.text.toString()
            model.ethernetGateway = ethernetGatewayAddressV6ET.text.toString()
        }

        model.dns1 = String.format("%s.%s.%s.%s", ethernetDns1V41ET.text.toString(), ethernetDns1V42ET.text.toString(), ethernetDns1V43ET.text.toString(), ethernetDns1V44ET.text.toString())
        model.dns2 = String.format("%s.%s.%s.%s", ethernetDns2V41ET.text.toString(), ethernetDns2V42ET.text.toString(), ethernetDns2V43ET.text.toString(), ethernetDns2V44ET.text.toString())
        model.dns3 = String.format("%s.%s.%s.%s", ethernetDns3V41ET.text.toString(), ethernetDns3V42ET.text.toString(), ethernetDns3V43ET.text.toString(), ethernetDns3V44ET.text.toString())

        model.dns1 = model.dns1.replace("...", "")
        model.dns2 = model.dns2.replace("...", "")
        model.dns3 = model.dns3.replace("...", "")
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.ipVersionSwitch -> onEthernetIpV4Switch()
            R.id.dhcpSwitch -> onEthernetIpDHCPSwitch()
        }
        if(listOf(R.id.ipVersionSwitch, R.id.dhcpSwitch).contains(v?.id))
        {
            if(enableDataChangeListener)
                changeSaveButtonStatusListener?.invoke()
        }
    }

    private fun onEthernetIpDHCPSwitch()
    {
        ipVersionSwitch.isEnabled = !dhcpSwitch.isChecked
        enableChildViewRecursive(ipDhcpContainer, !dhcpSwitch.isChecked)
    }

    private fun onEthernetIpV4Switch()
    {
        ethernetIpAddressV4Container.visibility = if(ipVersionSwitch.isChecked) View.VISIBLE else View.GONE
        ethernetNetmaskAddressV4Container.visibility = if(ipVersionSwitch.isChecked) View.VISIBLE else View.GONE
        ethernetGatewayAddressV4Container.visibility = if(ipVersionSwitch.isChecked) View.VISIBLE else View.GONE
        ethernetIpAddressV6ET.visibility = if(ipVersionSwitch.isChecked) View.GONE else View.VISIBLE
        ethernetNetmaskAddressV6ET.visibility = if(ipVersionSwitch.isChecked) View.GONE else View.VISIBLE
        ethernetGatewayAddressV6ET.visibility = if(ipVersionSwitch.isChecked) View.GONE else View.VISIBLE
    }

    private fun enableChildViewRecursive(container: ViewGroup, enable: Boolean)
    {
        for(i in 0 until container.childCount)
        {
            val child = container.getChildAt(i)
            if(child is ViewGroup)
                enableChildViewRecursive(child, enable)
            else if(child is View)
                child.isEnabled = enable
        }
    }

    override fun onDestroy()
    {
        changeSaveButtonStatusListener = null
        super.onDestroy()
    }
}