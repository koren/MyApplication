package com.evogence.eilink.controllers.nodesStorage

/**
 * Created by Anatolij on 8/29/18.
 */
interface INodesStorageObserver
{
	fun nodesUpdated(isUpdated: Boolean)
}