package com.evogence.eilink.screens.nodeDetails.tabs.restartSchedulerTab

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.EditText
import com.evogence.eilink.R
import com.evogence.eilink.common.EMeridium
import com.evogence.eilink.common.ui.TimePickerFragment
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabView
import com.evogence.eilink.screens.nodeList.groupOperations.restartSchedulerOperation.RestartSchedulerGroupOperationPresenter
import kotlinx.android.synthetic.main.node_details_restart_scheduler.*
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Koren Vitalii on 05/29/18.
 */

//todo anl: many work-logic inside View
class RestartSchedulerView: NodeDetailsTabView<RestartSchedulerVM>(), View.OnClickListener
{
    override val title: String = "Reboot & Shutdown"
    override val isShowSaveButton: Boolean = true
    override val layout: Int = R.layout.node_details_restart_scheduler
    private val inFormat = SimpleDateFormat("hh:mm aa", Locale.getDefault())

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"
        private const val LIST_FINGERPRINT_KEY = "list_fingerprint_key"
        private const val REQUEST_CODE_RESTART_NODE: Int = 0
        private const val REQUEST_CODE_RESTART_PLAYBACK: Int = 1
        private const val REQUEST_CODE_SHUTDOWN: Int = 2

        @JvmStatic
        fun build(fingerprint: String): RestartSchedulerView
        {
            val fragment = RestartSchedulerView()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }

        @JvmStatic
        fun build(fingerprints: Array<String>): RestartSchedulerView
        {
            val fragment = RestartSchedulerView()
            val args = Bundle()
            args.putStringArray(LIST_FINGERPRINT_KEY, fingerprints)
            fragment.arguments = args
            return fragment
        }
    }

    override fun initView()
    {
        timeRestartNodeSchedulerET.setOnClickListener(this)
        timePlaybackRestartSchedulerET.setOnClickListener(this)
        timeShutdownNodeSchedulerET.setOnClickListener(this)
        restartNodeSchedulerSwitch.setOnClickListener(this)
        playbackRestartSchedulerSwitch.setOnClickListener(this)
        shutdownNodeSchedulerSwitch.setOnClickListener(this)

        enableET(timeRestartNodeSchedulerET, restartNodeSchedulerSwitch.isChecked)
        enableET(timePlaybackRestartSchedulerET, playbackRestartSchedulerSwitch.isChecked)
        enableET(timeShutdownNodeSchedulerET, shutdownNodeSchedulerSwitch.isChecked)
    }

    override fun fill(model: Any)
    {
        enableDataChangeListener = false

        model as RestartSchedulerVM
        restartNodeSchedulerSwitch.isChecked = model.restartNodeSchedulerEnabled

        val timeRestartNodeScheduler = timeFromString(model.timeRestartNodeSchedulerText, false)
        timeRestartNodeSchedulerET.setText(inFormat.format(timeRestartNodeScheduler))

        playbackRestartSchedulerSwitch.isChecked = model.restartPlaybackSchedulerEnabled

        val timePlaybackRestartScheduler = timeFromString(model.timePlaybackRestartSchedulerText, false)
        timePlaybackRestartSchedulerET.setText(inFormat.format(timePlaybackRestartScheduler))

        shutdownNodeSchedulerSwitch.isChecked = model.shutdownNodeSchedulerEnabled

        val timeShutdownNodeScheduler = timeFromString(model.timeShutdownNodeSchedulerText, false)
        timeShutdownNodeSchedulerET.setText(inFormat.format(timeShutdownNodeScheduler))

        enableDataChangeListener = true
        enableET(timeRestartNodeSchedulerET, restartNodeSchedulerSwitch.isChecked)
        enableET(timePlaybackRestartSchedulerET, playbackRestartSchedulerSwitch.isChecked)
        enableET(timeShutdownNodeSchedulerET, shutdownNodeSchedulerSwitch.isChecked)
    }

    override fun retrieveChanges(model: RestartSchedulerVM)
    {
        val hourFormat = SimpleDateFormat("hh", Locale.getDefault())
        val minuteFormat = SimpleDateFormat("mm", Locale.getDefault())
        val meridianFormat = SimpleDateFormat("aa", Locale.getDefault())

        var time = timeFromString(timeRestartNodeSchedulerET.text.toString())
        model.restartNodeSchedulerEnabled = restartNodeSchedulerSwitch.isChecked
        model.timeRestartNodeSchedulerText = inFormat.format(time)
        model.restartNodeMeridian = EMeridium.get(meridianFormat.format(time))
        model.restartNodeMinute = minuteFormat.format(time).toInt()
        model.restartNodeHour = hourFormat.format(time).toInt()

        time = timeFromString(timePlaybackRestartSchedulerET.text.toString())
        model.restartPlaybackSchedulerEnabled = playbackRestartSchedulerSwitch.isChecked
        model.timePlaybackRestartSchedulerText = inFormat.format(time)
        model.restartPlaybackMeridian = EMeridium.get(meridianFormat.format(time))
        model.restartPlaybackMinute = minuteFormat.format(time).toInt()
        model.restartPlaybackHour = hourFormat.format(time).toInt()

        time = timeFromString(timeShutdownNodeSchedulerET.text.toString())
        model.shutdownNodeSchedulerEnabled = shutdownNodeSchedulerSwitch.isChecked
        model.timeShutdownNodeSchedulerText = timeShutdownNodeSchedulerET.text.toString()
        model.shutdownMeridian = EMeridium.get(meridianFormat.format(time))
        model.shutdownMinute = minuteFormat.format(time).toInt()
        model.shutdownHour = hourFormat.format(time).toInt()
    }

    override fun initPresenter()
    {
        arguments?.let {
            presenter = if(it.containsKey(FINGERPRINT_KEY))
                RestartSchedulerPresenter(it.getString(FINGERPRINT_KEY))
            else
                RestartSchedulerGroupOperationPresenter(it.getStringArray(LIST_FINGERPRINT_KEY))
        }
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.timeRestartNodeSchedulerET -> onTimeRestartNodeSchedulerClicked()
            R.id.timeShutdownNodeSchedulerET -> onTimeShutdownNodeSchedulerClicked()
            R.id.timePlaybackRestartSchedulerET -> onTimePlaybackRestartSchedulerClicked()
            R.id.restartNodeSchedulerSwitch -> enableET(timeRestartNodeSchedulerET, restartNodeSchedulerSwitch.isChecked)
            R.id.playbackRestartSchedulerSwitch -> enableET(timePlaybackRestartSchedulerET, playbackRestartSchedulerSwitch.isChecked)
            R.id.shutdownNodeSchedulerSwitch -> enableET(timeShutdownNodeSchedulerET, shutdownNodeSchedulerSwitch.isChecked)
        }

        val list = listOf(R.id.restartNodeSchedulerSwitch, R.id.playbackRestartSchedulerSwitch, R.id.shutdownNodeSchedulerSwitch)
        if(list.contains(v?.id))
            dataMayChanged()
    }

    private fun enableET(editText: EditText, enable: Boolean)
    {
        editText.isEnabled = enable
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent)
    {
        super.onActivityResult(requestCode, resultCode, data)
        if(resultCode == AppCompatActivity.RESULT_OK)
        {
            when(requestCode)
            {
                REQUEST_CODE_RESTART_NODE -> setTime(timeRestartNodeSchedulerET, data.getIntExtra(TimePickerFragment.HOUR_KEY, 0), data.getIntExtra(TimePickerFragment.MINUTE_KEY, 0))
                REQUEST_CODE_RESTART_PLAYBACK -> setTime(timePlaybackRestartSchedulerET, data.getIntExtra(TimePickerFragment.HOUR_KEY, 0), data.getIntExtra(TimePickerFragment.MINUTE_KEY, 0))
                REQUEST_CODE_SHUTDOWN -> setTime(timeShutdownNodeSchedulerET, data.getIntExtra(TimePickerFragment.HOUR_KEY, 0), data.getIntExtra(TimePickerFragment.MINUTE_KEY, 0))
            }

            if(listOf(REQUEST_CODE_RESTART_NODE, REQUEST_CODE_RESTART_PLAYBACK, REQUEST_CODE_SHUTDOWN).contains(requestCode))
                dataMayChanged()
        }
    }

    private fun onTimeRestartNodeSchedulerClicked()
    {
        val time = timeFromString(timeRestartNodeSchedulerET.text.toString())
        val calendar = GregorianCalendar.getInstance()
        calendar.time = time
        openTimePicker(calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), REQUEST_CODE_RESTART_NODE)
    }

    private fun timeFromString(dateString: String, defaultCurrentTime: Boolean = true): Date
    {
        return try
        {
            inFormat.parse(dateString.toUpperCase())
        }
        catch(pe: ParseException)
        {
            if(!defaultCurrentTime)
            {
                val calendar = GregorianCalendar.getInstance()
                calendar.set(Calendar.HOUR_OF_DAY, 12)
                calendar.set(Calendar.MINUTE, 0)
                calendar.time
            }
            else
                Date()
        }
    }

    private fun onTimePlaybackRestartSchedulerClicked()
    {
        val time = timeFromString(timePlaybackRestartSchedulerET.text.toString())
        val calendar = GregorianCalendar.getInstance()
        calendar.time = time
        openTimePicker(calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), REQUEST_CODE_RESTART_PLAYBACK)
    }

    private fun onTimeShutdownNodeSchedulerClicked()
    {
        val time = timeFromString(timeShutdownNodeSchedulerET.text.toString())
        val calendar = GregorianCalendar.getInstance()
        calendar.time = time
        openTimePicker(calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), REQUEST_CODE_SHUTDOWN)
    }

    private fun setTime(view: EditText, hour: Int, minute: Int)
    {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, hour)
        calendar.set(Calendar.MINUTE, minute)
        view.setText(inFormat.format(calendar.time))
    }

    private fun openTimePicker(hour: Int, minute: Int, timeRequestCode: Int)
    {
        val manager = fragmentManager
        val dialog = TimePickerFragment.newInstance(hour, minute)
        dialog.setTargetFragment(this, timeRequestCode)
        dialog.show(manager, dialog.javaClass.name)
    }
}
