package com.evogence.eilink.screens.nodeDetails.tabs.restartSchedulerTab

import com.evogence.eilink.common.EMeridium

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class RestartSchedulerVM: Cloneable
{
    var restartNodeSchedulerEnabled: Boolean = false
    var timeRestartNodeSchedulerText: String = ""
    var restartNodeMeridian: EMeridium = EMeridium.AM
    var restartNodeHour: Int = 0
    var restartNodeMinute: Int = 0

    var restartPlaybackSchedulerEnabled: Boolean = false
    var timePlaybackRestartSchedulerText: String = ""
    var restartPlaybackMeridian: EMeridium = EMeridium.AM
    var restartPlaybackHour: Int = 0
    var restartPlaybackMinute: Int = 0

    var shutdownNodeSchedulerEnabled: Boolean = false
    var timeShutdownNodeSchedulerText: String = ""
    var shutdownMeridian: EMeridium = EMeridium.AM
    var shutdownHour: Int = 0
    var shutdownMinute: Int = 0

    override fun equals(other: Any?): Boolean
    {
        return hashCode() == (other as RestartSchedulerVM).hashCode()
    }

    fun copy(): RestartSchedulerVM
    {
        return this.clone() as RestartSchedulerVM
    }

    override fun hashCode(): Int
    {
        var result = restartNodeSchedulerEnabled.hashCode()
        result = 31 * result + timeRestartNodeSchedulerText.hashCode()
        result = 31 * result + restartNodeMeridian.hashCode()
        result = 31 * result + restartNodeHour
        result = 31 * result + restartNodeMinute
        result = 31 * result + restartPlaybackSchedulerEnabled.hashCode()
        result = 31 * result + timePlaybackRestartSchedulerText.hashCode()
        result = 31 * result + restartPlaybackMeridian.hashCode()
        result = 31 * result + restartPlaybackHour
        result = 31 * result + restartPlaybackMinute
        result = 31 * result + shutdownNodeSchedulerEnabled.hashCode()
        result = 31 * result + timeShutdownNodeSchedulerText.hashCode()
        result = 31 * result + shutdownMeridian.hashCode()
        result = 31 * result + shutdownHour
        result = 31 * result + shutdownMinute
        return result
    }
}
