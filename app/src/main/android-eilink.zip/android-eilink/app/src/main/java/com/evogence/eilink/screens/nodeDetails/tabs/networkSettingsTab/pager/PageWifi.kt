package com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.pager

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import com.evogence.eilink.R
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.EProtocol
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.NetworkSettingsVM
import kotlinx.android.synthetic.main.node_details_network_settings_wifi_page.*


/**
 * Created by Koren Vitalii on 9/24/2018.
 */
class PageWifi: NetworkSettingsPage(), AdapterView.OnItemSelectedListener, View.OnClickListener
{
    override val title = "WiFi"
    override var changeSaveButtonStatusListener: (()->Unit)? = null

    private lateinit var spinnerAdapter: ArrayAdapter<String>
    private var viewModel: NetworkSettingsVM? = null
    private var enableDataChangeListener = true

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"

        fun build(fingerprint: String?): Fragment
        {
            val fragment = PageWifi()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.node_details_network_settings_wifi_page, container, false)
    }

    override fun refresh()
    {
        viewModel?.let {fill(it)}
    }

    override fun retrieveChanges()
    {
        viewModel?.let {retrieveChanges(it)}
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        wifiSwitch.setOnClickListener(this)
        dhcpSwitch.setOnClickListener(this)
        ipVersionSwitch.setOnClickListener(this)

        viewModel?.let {fill(it)}
        super.onViewCreated(view, savedInstanceState)
    }

    override fun fill(viewModel: NetworkSettingsVM)
    {
        enableDataChangeListener = false
        this.viewModel = viewModel

        activity?.let {
            spinnerAdapter = ArrayAdapter(it, android.R.layout.simple_spinner_item, ArrayList(viewModel.securityProtocols.values))
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            wifiSecuritiyProtocolSpinner?.adapter = spinnerAdapter
        }

        wifiSwitch?.isChecked = viewModel.wifiEnable
        preferredSwitch?.isChecked = viewModel.wifiPreferred
        wifiSsidET?.setText(viewModel.wifiSSID)
        wifiSecuritiyProtocolSpinner?.setSelection(spinnerAdapter.getPosition(viewModel.securityProtocols[viewModel.wifiSecurityProtocol]))
        wifiSecuritiyAuthKeyET?.setText(viewModel.wifiSecurityAuthKey)
        wifiIdentityET?.setText(viewModel.wifiIdentity)
        wifiPasswordET?.setText(viewModel.wifiPassword)
        dhcpSwitch?.isChecked = viewModel.wifiIpDHCP
        ipVersionSwitch?.isChecked = viewModel.wifiIpV4

        if(viewModel.wifiIpV4)
        {
            val wifiIpAddressV4 = viewModel.wifiIpAddress.split(".")
            wifiIpAddressV41ET?.setText(wifiIpAddressV4.getOrNull(0) ?: "")
            wifiIpAddressV42ET?.setText(wifiIpAddressV4.getOrNull(1) ?: "")
            wifiIpAddressV43ET?.setText(wifiIpAddressV4.getOrNull(2) ?: "")
            wifiIpAddressV44ET?.setText(wifiIpAddressV4.getOrNull(3) ?: "")

            val wifiNetmaskAddressV4 = viewModel.wifiNetmask.split(".")
            wifiNetmaskAddressV41ET?.setText(wifiNetmaskAddressV4.getOrNull(0) ?: "")
            wifiNetmaskAddressV42ET?.setText(wifiNetmaskAddressV4.getOrNull(1) ?: "")
            wifiNetmaskAddressV43ET?.setText(wifiNetmaskAddressV4.getOrNull(2) ?: "")
            wifiNetmaskAddressV44ET?.setText(wifiNetmaskAddressV4.getOrNull(3) ?: "")

            val wifiGatewayAddressV4 = viewModel.wifiGateway.split(".")
            wifiGatewayAddressV41ET?.setText(wifiGatewayAddressV4.getOrNull(0) ?: "")
            wifiGatewayAddressV42ET?.setText(wifiGatewayAddressV4.getOrNull(1) ?: "")
            wifiGatewayAddressV43ET?.setText(wifiGatewayAddressV4.getOrNull(2) ?: "")
            wifiGatewayAddressV44ET?.setText(wifiGatewayAddressV4.getOrNull(3) ?: "")
        }
        else
        {
            wifiIpAddressV6ET?.setText(viewModel.wifiIpAddress)
            wifiNetmaskAddressV6ET?.setText(viewModel.wifiNetmask)
            wifiGatewayAddressV6ET?.setText(viewModel.wifiGateway)
        }

        val wifiDns1V4 = viewModel.dns1.split(".")
        wifiDns1V41ET?.setText(wifiDns1V4.getOrNull(0) ?: "")
        wifiDns1V42ET?.setText(wifiDns1V4.getOrNull(1) ?: "")
        wifiDns1V43ET?.setText(wifiDns1V4.getOrNull(2) ?: "")
        wifiDns1V44ET?.setText(wifiDns1V4.getOrNull(3) ?: "")

        val wifiDns2V4 = viewModel.dns2.split(".")
        wifiDns2V41ET?.setText(wifiDns2V4.getOrNull(0) ?: "")
        wifiDns2V42ET?.setText(wifiDns2V4.getOrNull(1) ?: "")
        wifiDns2V43ET?.setText(wifiDns2V4.getOrNull(2) ?: "")
        wifiDns2V44ET?.setText(wifiDns2V4.getOrNull(3) ?: "")

        val wifiDns3V4 = viewModel.dns3.split(".")
        wifiDns3V41ET?.setText(wifiDns3V4.getOrNull(0) ?: "")
        wifiDns3V42ET?.setText(wifiDns3V4.getOrNull(1) ?: "")
        wifiDns3V43ET?.setText(wifiDns3V4.getOrNull(2) ?: "")
        wifiDns3V44ET?.setText(wifiDns3V4.getOrNull(3) ?: "")

        wifiSwitch?.let {onWiFiSwitch()}
        dhcpSwitch?.let {onDHCPSwitch()}
        ipVersionSwitch?.let {onIpVersionSwitch()}
        enableDataChangeListener = true
    }

    override fun retrieveChanges(model: NetworkSettingsVM)
    {
        model.wifiEnable = wifiSwitch.isChecked
        model.wifiPreferred = preferredSwitch.isChecked
        model.wifiSSID = wifiSsidET.text.toString()

        model.wifiSecurityProtocol = EProtocol.getKey(wifiSecuritiyProtocolSpinner.selectedItem.toString())
        model.wifiSecurityAuthKey = wifiSecuritiyAuthKeyET.text.toString()
        model.wifiIdentity = wifiIdentityET.text.toString()
        model.wifiPassword = wifiPasswordET.text.toString()
        model.wifiIpDHCP = dhcpSwitch.isChecked
        model.wifiIpV4 = ipVersionSwitch.isChecked

        if(ipVersionSwitch.isChecked)
        {
            model.wifiIpAddress = String.format("%s.%s.%s.%s", wifiIpAddressV41ET.text.toString(), wifiIpAddressV42ET.text.toString(), wifiIpAddressV43ET.text.toString(), wifiIpAddressV44ET.text.toString())
            model.wifiNetmask = String.format("%s.%s.%s.%s", wifiNetmaskAddressV41ET.text.toString(), wifiNetmaskAddressV42ET.text.toString(), wifiNetmaskAddressV43ET.text.toString(), wifiNetmaskAddressV44ET.text.toString())
            model.wifiGateway = String.format("%s.%s.%s.%s", wifiGatewayAddressV41ET.text.toString(), wifiGatewayAddressV42ET.text.toString(), wifiGatewayAddressV43ET.text.toString(), wifiGatewayAddressV44ET.text.toString())
            model.wifiIpAddress = model.wifiIpAddress.replace("...", "")
            model.wifiNetmask = model.wifiNetmask.replace("...", "")
            model.wifiGateway = model.wifiGateway.replace("...", "")
        }
        else
        {
            model.wifiIpAddress = wifiIpAddressV6ET.text.toString()
            model.wifiNetmask = wifiNetmaskAddressV6ET.text.toString()
            model.wifiGateway = wifiGatewayAddressV6ET.text.toString()
        }

        model.dns1 = String.format("%s.%s.%s.%s", wifiDns1V41ET.text.toString(), wifiDns1V42ET.text.toString(), wifiDns1V43ET.text.toString(), wifiDns1V44ET.text.toString())
        model.dns2 = String.format("%s.%s.%s.%s", wifiDns2V41ET.text.toString(), wifiDns2V42ET.text.toString(), wifiDns2V43ET.text.toString(), wifiDns2V44ET.text.toString())
        model.dns3 = String.format("%s.%s.%s.%s", wifiDns3V41ET.text.toString(), wifiDns3V42ET.text.toString(), wifiDns3V43ET.text.toString(), wifiDns3V44ET.text.toString())
        model.dns1 = model.dns1.replace("...", "")
        model.dns2 = model.dns2.replace("...", "")
        model.dns3 = model.dns3.replace("...", "")
    }

    override fun onNothingSelected(parent: AdapterView<*>?)
    {
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long)
    {
        when(parent?.id)
        {
            R.id.wifiSecuritiyProtocolSpinner -> onWifiSecurityProtocolSpinnerChanged(position)
        }
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.wifiSwitch -> onWiFiSwitch()
            R.id.dhcpSwitch -> onDHCPSwitch()
            R.id.ipVersionSwitch -> onIpVersionSwitch()
        }
        if(listOf(R.id.wifiSwitch, R.id.dhcpSwitch, R.id.ipVersionSwitch, R.id.preferredSwitch).contains(v?.id))
        {
            if(enableDataChangeListener)
                changeSaveButtonStatusListener?.invoke()
        }
    }

    override fun onDestroy()
    {
        changeSaveButtonStatusListener = null
        super.onDestroy()
    }

    private fun onWifiSecurityProtocolSpinnerChanged(position: Int)
    {
        val visibleVariant: Int = when(spinnerAdapter.getItem(position))
        {
            EProtocol.WEP.value -> 1
            EProtocol.WPA_PSK.value -> 1
            EProtocol.WPA_EAP_PEAP.value -> 2
            else -> 0
        }

        when(visibleVariant)
        {
            0 ->
            {
                wifiSecuritiyAuthKeyContainer.visibility = View.GONE
                wifiIdentityContainer.visibility = View.GONE
                wifiPasswordContainer.visibility = View.GONE
            }
            1 ->
            {
                wifiSecuritiyAuthKeyContainer.visibility = View.VISIBLE
                wifiIdentityContainer.visibility = View.GONE
                wifiPasswordContainer.visibility = View.GONE
            }
            2 ->
            {
                wifiSecuritiyAuthKeyContainer.visibility = View.GONE
                wifiIdentityContainer.visibility = View.VISIBLE
                wifiPasswordContainer.visibility = View.VISIBLE
            }
        }
    }

    private fun onIpVersionSwitch()
    {
        wifiIpAddressV4Container.visibility = if(ipVersionSwitch.isChecked) View.VISIBLE else View.GONE
        wifiNetmaskAddressV4Container.visibility = if(ipVersionSwitch.isChecked) View.VISIBLE else View.GONE
        wifiGatewayAddressV4Container.visibility = if(ipVersionSwitch.isChecked) View.VISIBLE else View.GONE
        wifiIpAddressV6ET.visibility = if(ipVersionSwitch.isChecked) View.GONE else View.VISIBLE
        wifiNetmaskAddressV6ET.visibility = if(ipVersionSwitch.isChecked) View.GONE else View.VISIBLE
        wifiGatewayAddressV6ET.visibility = if(ipVersionSwitch.isChecked) View.GONE else View.VISIBLE
    }

    private fun onDHCPSwitch()
    {
        ipVersionSwitch.isEnabled = !dhcpSwitch.isChecked
        enableChildViewRecursive(ipDhcpContainer, if(!wifiSwitch.isChecked) false else !dhcpSwitch.isChecked)
    }

    private fun onWiFiSwitch()
    {
        preferredSwitch.isEnabled = wifiSwitch.isChecked
        wifiSecuritiyProtocolSpinner.isEnabled = wifiSwitch.isChecked
        enableChildViewRecursive(wifiEnabledContainer, wifiSwitch.isChecked)
    }

    private fun enableChildViewRecursive(container: ViewGroup, enable: Boolean)
    {
        for(i in 0 until container.childCount)
        {
            val child = container.getChildAt(i)
            if(child is ViewGroup)
                enableChildViewRecursive(child, enable)
            else if(child is View)
                child.isEnabled = enable
        }
    }
}