package com.evogence.eilink.screens.nodeList.groupOperations.integrationOperation

import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.models.node.Node
import com.evogence.eilink.screens.nodeDetails.tabs.INodeDetailsTabView
import com.evogence.eilink.screens.nodeDetails.tabs.integrationTab.NodeIntegrationPresenter
import com.evogence.eilink.screens.nodeDetails.tabs.integrationTab.NodeIntegrationVM

/**
 * Created by Koren Vitalii on 9/6/2018.
 */
class NodeIntegrationGroupOperationPresenter(fingerprints: Array<String>): NodeIntegrationPresenter(null)
{
    private var nodes: List<Node> = nodesStorage.getDevicesByFingerprint(fingerprints)
    private lateinit var commandsSaveList: MutableList<()->Unit>
    private var numberErrorSaveNode: Int = 0
    private var numberSuccessSaveNode: Int = 0
    private var commandResultError = false
    private lateinit var nodesQueue: MutableList<Node>

    init
    {
        node = nodes[0]
    }

    override fun attachView(view: INodeDetailsTabView<NodeIntegrationVM>)
    {
        this.view = view
        viewModelBeforeChanges = viewModel.copy()
    }

    override fun saveChanges()
    {
        initSaveChangesNodesQueue()
        saveChangesNodesQueue()
    }

    override fun processingSaveManagementServer(commandResult: CommandResult)
    {
        if(commandResult.error == null)
        {
            numberSuccessSaveNode++
            refreshNodeManagementServer()
        }
        else
            commandResultError = true

        view?.fill(viewModel)
        sendCommandSaveQueue()
    }

    override fun processingSaveSupportServer(commandResult: CommandResult)
    {
        if(commandResult.error == null)
            refreshSupportServer()
        else
            commandResultError = true
        view?.fill(viewModel)
        sendCommandSaveQueue()
    }

    override fun processingSaveUpdateServer(commandResult: CommandResult)
    {
        if(commandResult.error == null)
            refreshUpdateServer()
        else
            commandResultError = true
        view?.fill(viewModel)
        sendCommandSaveQueue()
    }

    override fun sendCommandSaveQueue()
    {
        if(commandsSaveList.isNotEmpty())
        {
            val command = commandsSaveList[0]
            commandsSaveList.removeAt(0)
            command.invoke()
        }
        else
        {
            if(commandResultError)
                numberErrorSaveNode++
            else
                numberSuccessSaveNode++
            saveChangesNodesQueue()
        }
    }

    private fun initSaveChangesNodesQueue()
    {
        numberErrorSaveNode = 0
        numberSuccessSaveNode = 0
        commandResultError = false
        nodesQueue = nodes.toMutableList()
    }

    private fun saveChangesNodesQueue()
    {
        if(nodesQueue.size > 0)
        {
            node = nodesQueue[0]
            nodesQueue.removeAt(0)
            commandsSaveList = mutableListOf({saveManagementServer()}, {saveSupportServer()}, {saveUpdateServer()})
            sendCommandSaveQueue()
        }
        else
        {
            if(numberErrorSaveNode > 0 && numberSuccessSaveNode > 0)
                view?.showAlertDialog("Info", String.format("Save successful for %s nodes and failed for %s nodes.", numberSuccessSaveNode, numberErrorSaveNode))
            else if(numberErrorSaveNode == 0)
                view?.showAlertDialog("Info", "Successful")
            else
                view?.showAlertDialog("Error", "Failed for all nodes")

            if(numberErrorSaveNode == 0)
                view?.enableSaveButton(false)

            view?.hideProgress()
        }
    }
}