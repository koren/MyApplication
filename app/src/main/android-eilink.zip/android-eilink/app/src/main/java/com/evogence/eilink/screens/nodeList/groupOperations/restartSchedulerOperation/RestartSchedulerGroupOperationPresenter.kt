package com.evogence.eilink.screens.nodeList.groupOperations.restartSchedulerOperation

import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.models.node.Node
import com.evogence.eilink.screens.nodeDetails.tabs.restartSchedulerTab.RestartSchedulerPresenter

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class RestartSchedulerGroupOperationPresenter(fingerprints: Array<String>): RestartSchedulerPresenter(null)
{
    private lateinit var commandsSaveList: MutableList<()->Unit>
    private var nodes: List<Node> = nodesStorage.getDevicesByFingerprint(fingerprints)
    private var numberErrorSaveNode: Int = 0
    private var numberSuccessSaveNode: Int = 0
    private var commandResultError = false
    private lateinit var nodesQueue: MutableList<Node>

    init
    {
        node = nodes[0]
    }

    override fun saveChanges()
    {
        initSaveChangesNodesQueue()
        saveChangesNodesQueue()
    }

    override fun prepareViewModel()
    {
        viewModelBeforeChanges = viewModel.copy()
    }

    private fun saveChangesNodesQueue()
    {
        if(nodesQueue.size > 0)
        {
            node = nodesQueue[0]
            nodesQueue.removeAt(0)
            commandsSaveList = mutableListOf({saveRestartNodeScheduler()}, {savePlaybackRestartScheduler()}, {saveShutdownNodeScheduler()})
            sendQueueSaveCommand()
        }
        else
        {
            if(numberErrorSaveNode > 0 && numberSuccessSaveNode > 0)
                view?.showAlertDialog("Info", String.format("Save successful for %s nodes and failed for %s nodes.", numberSuccessSaveNode, numberErrorSaveNode))
            else if(numberErrorSaveNode == 0)
                view?.showAlertDialog("Info", "Successful")
            else
                view?.showAlertDialog("Error", "Failed for all nodes")
            view?.hideProgress()
        }
    }

    private fun initSaveChangesNodesQueue()
    {
        numberErrorSaveNode = 0
        numberSuccessSaveNode = 0
        commandResultError = false
        nodesQueue = nodes.toMutableList()
    }

    private fun sendQueueSaveCommand()
    {
        if(commandsSaveList.isNotEmpty())
        {
            val command = commandsSaveList[0]
            commandsSaveList.removeAt(0)
            command.invoke()
        }
        else
        {
            if(commandResultError)
                numberErrorSaveNode++
            else
                numberSuccessSaveNode++
            saveChangesNodesQueue()
        }
    }

    override fun processingSaveCommand(commandResult: CommandResult, refreshNode: ()->Unit)
    {
        if(commandResult.error == null)
            refreshNode.invoke()
        else
            commandResultError = true

        sendQueueSaveCommand()
    }
}
