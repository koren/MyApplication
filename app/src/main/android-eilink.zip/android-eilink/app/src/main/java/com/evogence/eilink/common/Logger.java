package com.evogence.eilink.common;

import android.text.TextUtils;
import android.util.Log;

import java.util.Calendar;

/**
 * Created by viro on 29.09.15.
 */
public class Logger
{
    private static final String TAG_LOG_CAT = "ASController";

    public static void write(String message)
    {
        write(EDebugLevel.DEBUG_LEVEL, null, message);
    }

    public static void writeError(String message)
    {
        write(EDebugLevel.ERROR_LEVEL, null, message);
    }

    public static <T> void write(EDebugLevel _level, Class<T> _class, String _message)
    {
        String title = Calendar.getInstance().getTime() + ":" + TAG_LOG_CAT;

        StackTraceElement[] stackTraceElement = Thread.currentThread().getStackTrace();
        int currentIndex = -1;

        String fullMessage = getLocation() + ": " + _message;
        switch (_level)
        {
            case ERROR_LEVEL:
                Log.e(title, fullMessage);
                break;

            case INFO_LEVEL:
                Log.i(title, fullMessage);
                break;

            case DEBUG_LEVEL:

            default:
                Log.d(title, fullMessage);
        }

        for (int i = 0; i < stackTraceElement.length; i++)
        {
            if (stackTraceElement[i].getMethodName().compareTo("write") == 0)
            {
                currentIndex = i + 1;
                break;
            }
        }
//        for (int i = 0; i < stackTraceElement.length; i++)
//        {
//            Log.d("DEBUG", "StackTrace: " + stackTraceElement[i].getClassName() + ":" +
//                    stackTraceElement[i].getMethodName());
//        }
    }

    public enum EDebugLevel
    {
        ERROR_LEVEL, DEBUG_LEVEL, INFO_LEVEL
    }

    private static String getLocation()
    {
        final String className = Logger.class.getName();
        final StackTraceElement[] traces = Thread.currentThread().getStackTrace();
        boolean found = false;

        for (int i = 0; i < traces.length; i++)
        {
            StackTraceElement trace = traces[i];
            try
            {
                if (found)
                {
                    if (!trace.getClassName().startsWith(className))
                    {
                        Class<?> _class = Class.forName(trace.getClassName());
                        return "[" + getClassName(_class) + "->"
                                + trace.getMethodName() + ":"
                                + trace.getLineNumber() + "]: ";
                    }
                }
                else if (trace.getClassName().startsWith(className))
                {
                    found = true;
                    continue;
                }
            }
            catch (ClassNotFoundException e)
            {
                e.printStackTrace();
            }
        }

        return "[]: ";
    }

    private static String getClassName(Class<?> _class)
    {
        if (_class != null)
        {
            if (!TextUtils.isEmpty(_class.getSimpleName()))
                return _class.getSimpleName();

            return getClassName(_class.getEnclosingClass());
        }
        return "";
    }
}
