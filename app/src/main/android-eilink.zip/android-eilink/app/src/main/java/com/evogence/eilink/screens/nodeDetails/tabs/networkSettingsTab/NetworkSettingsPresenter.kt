package com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab

import com.evogence.eilink.common.BlockRunnable
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.controllers.nodeCommandSender.ENodeCommand
import com.evogence.eilink.controllers.nodeCommandSender.IPSettings
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetNetSettingsCommand
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetUpNetSettingsCommand
import com.evogence.eilink.screens.nodeDetails.tabs.INodeDetailsTabView
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabPresenter

/**
 * Created by Koren Vitalii on 05/29/18.
 */
open class NetworkSettingsPresenter(fingerprint: String?): NodeDetailsTabPresenter<NetworkSettingsVM>(fingerprint)
{
    override var viewModel = NetworkSettingsVM()

    override fun attachView(view: INodeDetailsTabView<NetworkSettingsVM>)
    {
        super.attachView(view)
        if((System.currentTimeMillis() - node.networkSettings.updateTimestamp) > ONE_MINUTE)
            sendGetCommand()
    }

    override fun prepareViewModel()
    {
        val netSettings = node.networkSettings
        viewModel.wifiEnable = netSettings.wifiEnabled
        viewModel.wifiPreferred = netSettings.wifiPreferred
        viewModel.wifiSSID = netSettings.wifiSsid
        viewModel.wifiSecurityProtocol = netSettings.wifiSecurityProtocol
        viewModel.wifiSecurityAuthKey = netSettings.wifiAuthKey
        viewModel.wifiIdentity = netSettings.wifiAuthIdentity
        viewModel.wifiPassword = netSettings.wifiAuthPassword
        viewModel.wifiIpDHCP = netSettings.wifiIpdhcp

        viewModel.wifiIpAddress = netSettings.wifiIP.address
        viewModel.wifiNetmask = netSettings.wifiIP.netmask
        viewModel.wifiGateway = netSettings.wifiIP.gateway
        viewModel.wifiIpV4 = netSettings.wifiIP.versionType.value
        viewModel.dns1 = netSettings.dns1
        viewModel.dns2 = netSettings.dns2
        viewModel.dns3 = netSettings.dns3
        viewModel.ethernetIpDHCP = netSettings.ipdhcp

        viewModel.ethernetIpAddress = netSettings.ethernetIP.address
        viewModel.ethernetNetmask = netSettings.ethernetIP.netmask
        viewModel.ethernetGateway = netSettings.ethernetIP.gateway
        viewModel.ethernetIpV4 = netSettings.ethernetIP.versionType.value
        viewModel.securityProtocols = getProtocols()

        viewModelBeforeChanges = viewModel.copy()
    }

    override fun saveChanges()
    {
        sendSetNetSettingsCommand()
    }

    fun sendSetNetSettingsCommand()
    {
        val parameters = HashMap<String, Any?>()

        val ethernet = HashMap<String, Any>()
        ethernet[SetUpNetSettingsCommand.IPDHCP1_KEY] = viewModel.ethernetIpDHCP
        ethernet[SetUpNetSettingsCommand.IPADDRESS_KEY] = viewModel.ethernetIpAddress
        ethernet[SetUpNetSettingsCommand.IPNETMASK_KEY] = viewModel.ethernetNetmask
        ethernet[SetUpNetSettingsCommand.IPGATEWAY_KEY] = viewModel.ethernetGateway
        ethernet[SetUpNetSettingsCommand.IPDNS1_KEY] = viewModel.dns1
        ethernet[SetUpNetSettingsCommand.IPDNS2_KEY] = viewModel.dns2
        ethernet[SetUpNetSettingsCommand.IPDNS3_KEY] = viewModel.dns3
        ethernet[SetUpNetSettingsCommand.IPVERSION_KEY] = IPSettings.getVersionType(viewModel.ethernetIpV4)
        parameters[SetUpNetSettingsCommand.ETHERNET_KEY] = ethernet

        val wifi = HashMap<String, Any>()
        wifi[SetUpNetSettingsCommand.WIFI_ENABLED_KEY] = viewModel.wifiEnable
        wifi[SetUpNetSettingsCommand.WIFI_PREFERRED_KEY] = viewModel.wifiPreferred
        wifi[SetUpNetSettingsCommand.SSID_KEY] = viewModel.wifiSSID
        wifi[SetUpNetSettingsCommand.SECURITY_PROTOCOL_KEY] = viewModel.wifiSecurityProtocol
        wifi[SetUpNetSettingsCommand.AUTH_IDENTITY_KEY] = viewModel.wifiIdentity
        wifi[SetUpNetSettingsCommand.AUTH_KEY] = viewModel.wifiSecurityAuthKey
        wifi[SetUpNetSettingsCommand.AUTH_PASSWORD_KEY] = viewModel.wifiPassword
        wifi[SetUpNetSettingsCommand.IPDHCP1_KEY] = viewModel.wifiIpDHCP
        wifi[SetUpNetSettingsCommand.IPADDRESS1_KEY] = viewModel.wifiIpAddress
        wifi[SetUpNetSettingsCommand.IPNETMASK1_KEY] = viewModel.wifiNetmask
        wifi[SetUpNetSettingsCommand.IPGATEWAY1_KEY] = viewModel.wifiGateway
        wifi[SetUpNetSettingsCommand.IPDNS1_KEY] = viewModel.dns1
        wifi[SetUpNetSettingsCommand.IPDNS2_KEY] = viewModel.dns2
        wifi[SetUpNetSettingsCommand.IPDNS3_KEY] = viewModel.dns3
        wifi[SetUpNetSettingsCommand.IPVERSION1_KEY] = IPSettings.getVersionType(viewModel.wifiIpV4)
        parameters[SetUpNetSettingsCommand.WIFI_KEY] = wifi

        commandSender.send(ENodeCommand.SET_NET_SETTINGS, node, parameters, BlockRunnable {processingSaveCommand(it)})
    }

    protected open fun processingSaveCommand(commandResult: CommandResult)
    {
        if(commandResult.error == null)
        {
            viewModelBeforeChanges = viewModel.copy()
            refreshNode()
            view?.enableSaveButton(false)
            view?.showAlertDialog("Info", "Successful")
        }
        else
            showCommandError(commandResult)

        view?.hideProgress()
    }

    protected fun getProtocols(): Map<String, String>
    {
        return mapOf(EProtocol.NONE.key to EProtocol.NONE.value, EProtocol.WEP.key to EProtocol.WEP.value, EProtocol.WPA_PSK.key to EProtocol.WPA_PSK.value, EProtocol.WPA_EAP_PEAP.key to EProtocol.WPA_EAP_PEAP.value)
    }

    private fun sendGetCommand()
    {
        view?.showProgress("Processing")
        commandSender.send(ENodeCommand.GET_NET_SETTINGS, node, null, BlockRunnable {this.processingGetCommand(it)})
    }

    private fun processingGetCommand(commandResult: CommandResult)
    {
        if(commandResult.error == null)
        {
            refreshNode(commandResult)
            prepareViewModel()
        }
        else
            showCommandError(commandResult)

        view?.fill(viewModel)
        view?.hideProgress()
    }

    protected fun refreshNode()
    {
        val networkSettings = node.networkSettings
        networkSettings.wifiPreferred = viewModel.wifiPreferred
        networkSettings.wifiIpdhcp = viewModel.wifiIpDHCP
        networkSettings.wifiEnabled = viewModel.wifiEnable
        networkSettings.wifiSsid = viewModel.wifiSSID
        networkSettings.wifiSecurityProtocol = viewModel.wifiSecurityProtocol
        networkSettings.wifiAuthIdentity = viewModel.wifiIdentity
        networkSettings.wifiAuthKey = viewModel.wifiSecurityAuthKey
        networkSettings.wifiAuthPassword = viewModel.wifiPassword

        val wifiIP = networkSettings.wifiIP

        wifiIP.address = viewModel.wifiIpAddress
        wifiIP.netmask = viewModel.wifiNetmask
        wifiIP.gateway = viewModel.wifiGateway
        wifiIP.versionType = IPSettings.getVersionType(viewModel.wifiIpV4)

        val ethernetIP = networkSettings.ethernetIP
        ethernetIP.address = viewModel.ethernetIpAddress
        ethernetIP.netmask = viewModel.ethernetNetmask
        ethernetIP.gateway = viewModel.ethernetGateway
        ethernetIP.versionType = IPSettings.getVersionType(viewModel.ethernetIpV4)

        networkSettings.dns1 = viewModel.dns1
        networkSettings.dns2 = viewModel.dns2
        networkSettings.dns3 = viewModel.dns3
    }

    private fun refreshNode(commandResult: CommandResult)
    {
        if(commandResult.params == null)
            return

        val networkSettings = node.networkSettings
        val result = commandResult.params
        val wifi = result[GetNetSettingsCommand.WIFI_KEY] as Map<*, *>
        val ethernet = result[GetNetSettingsCommand.ETHERNET_KEY] as Map<*, *>
        networkSettings.wifiPreferred = (wifi[GetNetSettingsCommand.WIFI_PREFERRED_KEY] as? Int) ?: 0 == 1
        networkSettings.wifiIpdhcp = (wifi[GetNetSettingsCommand.IPDHCP1_KEY] ?: 0) == 1
        networkSettings.wifiEnabled = (wifi[GetNetSettingsCommand.WIFI_ENABLED_KEY] as? Boolean) ?: false
        networkSettings.wifiSsid = wifi[GetNetSettingsCommand.SSID_KEY] as? String ?: ""
        networkSettings.wifiSecurityProtocol = wifi[GetNetSettingsCommand.SECURITY_PROTOCOL_KEY] as? String ?: ""
        networkSettings.wifiAuthIdentity = wifi[GetNetSettingsCommand.AUTH_IDENTITY_KEY] as? String ?: ""
        networkSettings.wifiAuthKey = wifi[GetNetSettingsCommand.AUTH_KEY] as? String ?: ""
        networkSettings.wifiAuthPassword = wifi[GetNetSettingsCommand.AUTH_PASSWORD_KEY] as? String ?: ""
        networkSettings.wifiAuthPrivateKeyPassword = wifi[GetNetSettingsCommand.AUTH_PRIVATE_KEY_PASSWD_KEY] as? String ?: ""

        val wifiIP = networkSettings.wifiIP
        wifiIP.address = wifi[GetNetSettingsCommand.IPADDRESS1_KEY] as? String ?: ""
        wifiIP.netmask = wifi[GetNetSettingsCommand.IPNETMASK1_KEY] as? String ?: ""
        wifiIP.gateway = wifi[GetNetSettingsCommand.IPGATEWAY1_KEY] as? String ?: ""

        wifiIP.versionType = IPSettings.getVersionType(wifi[GetNetSettingsCommand.IP_VERSION1_KEY]as? String)

        val ethernetIP = networkSettings.ethernetIP
        ethernetIP.address = ethernet[GetNetSettingsCommand.IPADDRESS_KEY] as? String ?: ""
        ethernetIP.netmask = ethernet[GetNetSettingsCommand.IPNETMASK_KEY] as? String ?: ""
        ethernetIP.gateway = ethernet[GetNetSettingsCommand.IPGATEWAY_KEY] as? String ?: ""
        ethernetIP.versionType = IPSettings.getVersionType(wifi[GetNetSettingsCommand.IP_VERSION_KEY]as? String)

        if(networkSettings.dns1.isEmpty())
            networkSettings.dns1 = ethernet[GetNetSettingsCommand.IPDNS1_KEY] as? String ?: ""

        if(networkSettings.dns2.isEmpty())
            networkSettings.dns2 = ethernet[GetNetSettingsCommand.IPDNS2_KEY] as? String ?: ""

        if(networkSettings.dns3.isEmpty())
            networkSettings.dns3 = ethernet[GetNetSettingsCommand.IPDNS3_KEY] as? String ?: ""

        networkSettings.updateTimestamp = System.currentTimeMillis()
    }

    private fun showCommandError(commandResult: CommandResult)
    {
        if(commandResult.isSupported)
            view?.showAlertDialog("Error", commandResult.error)
        else
            view?.showAlertDialog(message =  commandResult.error)
    }
}
