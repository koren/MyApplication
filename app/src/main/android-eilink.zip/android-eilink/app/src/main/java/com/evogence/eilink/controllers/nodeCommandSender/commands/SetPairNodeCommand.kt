package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.google.gson.JsonObject
import com.google.gson.JsonPrimitive

/**
 * Created by Koren Vitalii on 9/3/2018.
 */
class SetPairNodeCommand(parameters: Any?): INodeCommand
{
    override var params: MutableMap<String, Any> = HashMap()
    override val method: String = "Integration.RPN.settings.ContextualDeviceService::pairEiNode"
    override val desc: String = "Pair [Ei] Node"

    companion object MapKeys
    {
        const val PARAMS_KEY = "params"
        const val STATUS_KEY = "status"
        const val SERIAL_MANUAL_KEY = "serial_manual"
        const val SERIAL_LIST_KEY = "serial_list"
        const val TYPE_LINK_KEY = "type_link"
        const val FORCE_KEY = "force"
    }

    init
    {
        if(parameters != null)
            params[PARAMS_KEY] = parameters
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonObject)?.has(STATUS_KEY) ?: false && !(((response.result as? JsonObject)?.get(STATUS_KEY) as? JsonPrimitive)?.asString ?: "").isEmpty()
    }
}