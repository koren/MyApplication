package com.evogence.eilink.controllers.nodesStorage

import com.evogence.eilink.models.node.Node

interface INodesStorage
{
    var nodes: HashMap<String, Node>

    fun refreshLocalNodes(localNodes: List<Node>)
    fun updateNode(node: Node)
    fun getDeviceByFingerprint(fingerprint: String): Node?
    fun addObserver(observer: INodesStorageObserver)
    fun removeObserver(observer: INodesStorageObserver)
    fun getNodeBySerialNumber(serialNumber: String): Node?
    fun getNodes(): List<Node>
    fun getControllers(): List<Node>
    fun getNotSupported(): List<Node>
    fun isController(model: String): Boolean
    fun getDevicesByFingerprint(fingerprints: Array<String>): List<Node>
}
