package com.evogence.eilink.screens.nodeList

import com.evogence.eilink.EiLinkApplication
import com.evogence.eilink.SystemPreferences
import com.evogence.eilink.common.BlockRunnable
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.controllers.nodeCommandSender.ENodeCommand
import com.evogence.eilink.controllers.nodeCommandSender.NodeCommandSender
import com.evogence.eilink.controllers.nodeCommandSender.commands.GetNodeInfoCommand
import com.evogence.eilink.controllers.nodesStorage.INodesStorage
import com.evogence.eilink.controllers.nodesStorage.INodesStorageObserver
import com.evogence.eilink.models.node.Node
import com.evogence.eilink.screens.INavigator
import com.evogence.eilink.screens.nodeDetails.tabs.restartSchedulerTab.ERebootAndShutdownCommand
import com.evogence.eilink.screens.nodeList.groupOperations.EGroupOperation
import javax.inject.Inject

/**
 * Created by Koren Vitalii on 05/21/18.
 */
class NodeListPresenter: INodesStorageObserver
{
    var view: INodeListView? = null
    val viewModel = NodeListVM()
    var commandSender: NodeCommandSender

    private var currentNode: Node? = null

    @Inject lateinit var navigator: INavigator
    @Inject lateinit var nodesStorage: INodesStorage
    @Inject lateinit var interactor: EiLinkApplication
    @Inject lateinit var systemPreferences: SystemPreferences

    init
    {
        EiLinkApplication.appComponent.inject(this)
        commandSender = NodeCommandSender()
    }

    fun searchLocalDevice()
    {
        if(interactor.canSearchLocalDevice())
        {
            view?.showProgress("Searching...")
            interactor.findLocalDevice()
        }
        else
            view?.showAlertDialog(message = "Please ensure the device has access to WiFi on the local network.")
    }

    fun onAttachView(view: NodeListView)
    {
        this.view = view
        nodesStorage.addObserver(this)
        prepareViewModel()
        view.fill(viewModel)
        if(nodesStorage.nodes.size == 0)
            searchLocalDevice()
    }

    fun onDetachView()
    {
        view?.hideProgress()
        if(navigator.getBackStackEntryCount() == 0)
            view?.finish()
        view = null
        nodesStorage.removeObserver(this)
    }

    override fun nodesUpdated(isUpdated: Boolean)
    {
        view?.hideProgress()
        if(isUpdated)
        {
            prepareViewModel()
            view?.fill(viewModel)
        }
    }

    fun prepareViewModel()
    {
        viewModel.enableSwipe = systemPreferences.getServiceMode()

        fillList(nodesStorage.getNodes(), viewModel.nodes)
        fillList(nodesStorage.getControllers(), viewModel.controllers)
        fillList(nodesStorage.getNotSupported(), viewModel.notSupported)

        val nodesSize = viewModel.nodes.size
        val controllersSize = viewModel.controllers.size
        val notSupportedSize = viewModel.notSupported.size

        viewModel.titleList.clear()
        if(nodesSize > 0)
            viewModel.titleList.add("Nodes: $nodesSize")

        if(controllersSize > 0)
            viewModel.titleList.add("Controllers: $controllersSize")

        if(notSupportedSize > 0)
            viewModel.titleList.add("Not supported: $notSupportedSize")
    }

    fun onClickAbout()
    {
        navigator.navigateToAbout()
    }

    fun onClickNodeIconContainer(fingerprint: String)
    {
        view?.showProgress("Processing")
        currentNode = nodesStorage.getDeviceByFingerprint(fingerprint)
        if(currentNode != null)
        //todo koren for test navigator.navigateToNodeDetails(currentNode!!.fingerprint)
            commandSender.send(ENodeCommand.GET_INFO, currentNode!!, null, BlockRunnable {this.processingGetInfoCommand(it)})
    }

    fun reset(fingerprint: String)
    {
        val node = nodesStorage.getDeviceByFingerprint(fingerprint)
        if(node != null)
            commandSender.send(ENodeCommand.RESET, node, null, BlockRunnable {this.processingCommand(it)})
    }

    fun reboot(fingerprint: String)
    {
        val node = nodesStorage.getDeviceByFingerprint(fingerprint)
        if(node != null)
            commandSender.send(ENodeCommand.REBOOT_AND_SHUTDOWN, node, ERebootAndShutdownCommand.REBOOT_SCHEDULER.type, BlockRunnable {this.processingCommand(it)})
    }

    fun restart(fingerprint: String)
    {
        val node = nodesStorage.getDeviceByFingerprint(fingerprint)
        if(node != null)
            commandSender.send(ENodeCommand.REBOOT_AND_SHUTDOWN, node, ERebootAndShutdownCommand.REBOOT_PLAYBACK.type, BlockRunnable {this.processingCommand(it)})
    }

    private fun getSelectedItems(): MutableList<String>
    {
        val listTab = mutableListOf<MutableList<NodeListItemVM>>()
        if(viewModel.nodes.size > 0)
            listTab.add(viewModel.nodes)
        if(viewModel.controllers.size > 0)
            listTab.add(viewModel.controllers)
        if(viewModel.notSupported.size > 0)
            listTab.add(viewModel.notSupported)

        val selectedItems = mutableListOf<String>()
        if(listTab.size > 0)
        {
            listTab[viewModel.currentPage].forEach {
                if(it.isSelected)
                    selectedItems.add(it.fingerprint)
            }
        }
        return selectedItems
    }

    fun onClickGroupOperationMenuItemIntegration()
    {
        showGroupOperation(EGroupOperation.Integration)
    }

    fun onClickGroupOperationMenuItemNetwork()
    {
        showGroupOperation(EGroupOperation.Network)
    }

    fun onClickGroupOperationMenuItemReset()
    {
        showGroupOperation(EGroupOperation.Reboot)
    }

    fun onPageSelected(position: Int)
    {
        viewModel.currentPage = position
    }

    fun changeStatusGroupOperationsBar()
    {
        view?.enableBottomButtonsContainer(getSelectedItems().size > 0)
    }

    private fun processingGetInfoCommand(commandResult: CommandResult)
    {
        if(commandResult.error == null)
        {
            fillNode(commandResult.params)
            if(currentNode != null)
                navigator.navigateToNodeDetails(currentNode!!.fingerprint)
        }
        else
            showCommandError(commandResult)

        currentNode?.updateTimestamp = System.currentTimeMillis()
        view?.hideProgress()
    }

    private fun fillNode(params: Map<String, Any>)
    {
        if(currentNode == null)
            return

        currentNode?.address = params[GetNodeInfoCommand.ADDRESS_KEY] as String
        currentNode?.audioChannelsCount = params[GetNodeInfoCommand.AUDIO_CHANNELS_COUNT_KEY] as Int
        currentNode?.company = params[GetNodeInfoCommand.COMPANY_KEY] as String
        currentNode?.updateTimestamp = params[GetNodeInfoCommand.DETAILS_LAST_TIMESTAMP_KEY] as Long
        currentNode?.edition = params[GetNodeInfoCommand.EDITION_KEY] as String

        @Suppress("UNCHECKED_CAST")
        currentNode?.gpusTemp?.clear()
        currentNode?.gpusTemp?.addAll(params[GetNodeInfoCommand.GPUS_TEMP_KEY] as Collection<Double>)
        @Suppress("UNCHECKED_CAST")
        currentNode?.cpusLoad?.clear()
        currentNode?.cpusLoad?.addAll(params[GetNodeInfoCommand.CPUS_LOAD_KEY] as Collection<Double>)
        @Suppress("UNCHECKED_CAST")
        currentNode?.cpusTemp?.clear()
        currentNode?.cpusTemp?.addAll(params[GetNodeInfoCommand.CPUS_TEMP_KEY] as Collection<Double>)

        currentNode?.hddFree = params[GetNodeInfoCommand.HDD_FREE_KEY] as Double
        currentNode?.hddTotal = params[GetNodeInfoCommand.HDD_TOTAL_KEY] as Double
        currentNode?.interfaceTrafficDate = params[GetNodeInfoCommand.INTERFACE_TRAFFIC_DATE_KEY] as Int
        currentNode?.interfaceTrafficReceivedLAN = params[GetNodeInfoCommand.INTERFACE_TRAFFIC_RECEIVED_LAN_KEY] as Int
        currentNode?.interfaceTrafficReceivedWiFi = params[GetNodeInfoCommand.INTERFACE_TRAFFIC_RECEIVED_WIFI_KEY] as Int
        currentNode?.interfaceTrafficSendLAN = params[GetNodeInfoCommand.INTERFACE_TRAFFIC_SEND_LAN_KEY] as Int
        currentNode?.interfaceTrafficSendWiFi = params[GetNodeInfoCommand.INTERFACE_TRAFFIC_SEND_WIFI_KEY] as Int
        currentNode?.location = params[GetNodeInfoCommand.LOCATION_KEY] as String
        currentNode?.macAddress = params[GetNodeInfoCommand.MAC_ADDRESS_KEY] as String
        currentNode?.model = params[GetNodeInfoCommand.MODEL_KEY] as String
        currentNode?.motherboard = params[GetNodeInfoCommand.MOTHERBOARD_KEY] as String
        currentNode?.period = params[GetNodeInfoCommand.PERIOD_KEY] as Int
        currentNode?.playbackRestartEnabled = params[GetNodeInfoCommand.PLAYBACK_RESTART_ENABLED_KEY] as Boolean
        currentNode?.playbackRestartHour = params[GetNodeInfoCommand.PLAYBACK_RESTART_HOUR_KEY] as Int
        currentNode?.playbackRestartMeridiem = params[GetNodeInfoCommand.PLAYBACK_RESTART_MERIDIEM_KEY] as String
        currentNode?.playbackRestartMinute = params[GetNodeInfoCommand.PLAYBACK_RESTART_MINUTE_KEY] as Int
        currentNode?.protocol = params[GetNodeInfoCommand.PROTOCOL_KEY] as String
        currentNode?.ramFree = params[GetNodeInfoCommand.RAM_FREE_KEY] as Double
        currentNode?.ramTotal = params[GetNodeInfoCommand.RAM_TOTAL_KEY] as Double
        currentNode?.rebootEnabled = params[GetNodeInfoCommand.REBOOT_ENABLED_KEY] as Boolean
        currentNode?.rebootHour = params[GetNodeInfoCommand.REBOOT_HOUR_KEY] as Int
        currentNode?.rebootMeridiem = params[GetNodeInfoCommand.REBOOT_MERIDIEM_KEY] as String
        currentNode?.rebootMinute = params[GetNodeInfoCommand.REBOOT_MINUTE_KEY] as Int
        currentNode?.registrationDate = params[GetNodeInfoCommand.REGISTRATION_DATE_KEY] as Int
        currentNode?.shutdownEnabled = params[GetNodeInfoCommand.SHUTDOWN_RESTART_ENABLED_KEY] as Boolean
        currentNode?.shutdownHour = params[GetNodeInfoCommand.SHUTDOWN_RESTART_HOUR_KEY] as Int
        currentNode?.shutdownMeridiem = params[GetNodeInfoCommand.SHUTDOWN_RESTART_MERIDIEM_KEY] as String
        currentNode?.shutdownMinute = params[GetNodeInfoCommand.SHUTDOWN_RESTART_MINUTE_KEY] as Int
        currentNode?.sid = params[GetNodeInfoCommand.SID_KEY] as String
        currentNode?.sn = params[GetNodeInfoCommand.SN_KEY] as String
        currentNode?.sysTime = params[GetNodeInfoCommand.SYS_TIME_KEY] as String
        currentNode?.timezone = params[GetNodeInfoCommand.TIMEZONE_KEY] as String
        currentNode?.title = params[GetNodeInfoCommand.TITLE_KEY] as String
        currentNode?.upTime = params[GetNodeInfoCommand.UPTIME_KEY] as String
        currentNode?.version = params[GetNodeInfoCommand.VERSION_KEY] as String
        currentNode?.videoChannelsCount = params[GetNodeInfoCommand.VIDEO_CHANNELS_COUNT_KEY] as Int

        nodesUpdated(true)
    }

    private fun fillList(nodes: List<Node>, viewModelList: MutableList<NodeListItemVM>)
    {
        viewModelList.clear()
        nodes.forEach {viewModelList.add(createCellViewModel(it))}
    }

    private fun createCellViewModel(node: Node): NodeListItemVM
    {
        val viewModel = NodeListItemVM()
        viewModel.fingerprint = node.fingerprint
        viewModel.title = node.title
        viewModel.serialNumber = node.sn
        viewModel.sId = node.sid
        viewModel.version = node.version
        viewModel.edition = node.edition
        viewModel.model = node.model.toUpperCase()
        viewModel.companyUnique = node.company
        viewModel.timezone = node.timezone
        viewModel.iconName = node.getIconName()
        return viewModel
    }

    private fun processingCommand(commandResult: CommandResult)
    {
        view?.hideProgress()
        if(commandResult.error == null)
            view?.showAlertDialog("Info", "Successful")
        else
            showCommandError(commandResult)
    }

    private fun showCommandError(commandResult: CommandResult)
    {
        if(commandResult.isSupported)
            view?.showAlertDialog("Error", commandResult.error)
        else
            view?.showAlertDialog(message =  commandResult.error)
    }

    private fun showGroupOperation(operationType: EGroupOperation)
    {
        navigator.navigateToGroupOperation(getSelectedItems().toTypedArray(), operationType)
    }
}
