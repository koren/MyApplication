package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.pager

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import com.evogence.eilink.common.Utils
import com.evogence.eilink.common.ui.SelectorView
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.AuxModeVM
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.IAuxModeView
import kotlinx.android.synthetic.main.node_details_aux_mode_grid_node_tab.*
import kotlinx.android.synthetic.main.node_details_aux_mode_node_select_list_item.*

/**
 * Created by Koren Vitalii on 9/25/2018.
 */
class GridNodePage: AuxModePage(), View.OnClickListener
{
    override var auxModeView: IAuxModeView? = null
    override val title = "[Ei] Grid Node"
    private var viewModel: AuxModeVM? = null

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"

        fun build(fingerprint: String?): AuxModePage
        {
            val fragment = GridNodePage()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.node_details_aux_mode_grid_node_tab, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        val selectorView = SelectorView()
        selectNodeBtn.setOnTouchListener(selectorView)
        pairBtn.setOnTouchListener(selectorView)

        selectNodeBtn.setOnClickListener(this)
        pairBtn.setOnClickListener(this)

        viewModel?.let {fill(it)}
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.selectNodeBtn -> auxModeView?.onClickSelectNode()
            R.id.pairBtn -> auxModeView?.onClickPair()
        }
    }

    override fun fill(model: AuxModeVM)
    {
        this.viewModel = model
        view?.let {
            statusImg.visibility = View.GONE

            if(model.modeConfiguration.snList.isEmpty())
            {
                nodeDetailsContainer.visibility = View.GONE
                selectNodeContainer.visibility = View.VISIBLE
            }
            else
            {
                nodeDetailsContainer.visibility = View.VISIBLE
                selectNodeContainer.visibility = View.GONE

                applianceImg.setImageResource(Utils.prepareIconRes(context, model.iconName))
                modelLabelTV.text = model.model
                nodeNameTV.text = model.title
                addressTV.text = model.ip
                serialNumberTV.text = model.modeConfiguration.snList
                versionLabelTV.text = model.version
            }
        }
    }

    override fun retrieveChanges(model: AuxModeVM)
    {
    }
}
