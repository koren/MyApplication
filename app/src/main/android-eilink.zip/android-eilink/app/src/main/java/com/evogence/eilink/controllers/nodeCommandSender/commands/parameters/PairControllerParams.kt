package com.evogence.eilink.controllers.nodeCommandSender.commands.parameters

import com.evogence.eilink.controllers.nodeCommandSender.commands.SetPairControllerCommand.MapKeys.FORCE_KEY
import com.evogence.eilink.controllers.nodeCommandSender.commands.SetPairControllerCommand.MapKeys.SERIAL_KEY

/**
 * Created by Koren Vitalii on 9/3/2018.
 */
class PairControllerParams(val serial: String = "", val force: Boolean = false)
{
    fun buildMap(): Map<String, Any?>
    {
        return mapOf(SERIAL_KEY to serial, FORCE_KEY to force)
    }
}
