package com.evogence.eilink.screens.nodeDetails.tabs.performanceTab

import java.util.*

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class PerformanceVM
{
    var cpuLoadTitle: String = ""
    var cpuTempTitle: String = ""
    var gpuTempTitle: String = ""
    var ramTotal: String = ""
    var ramFree: String = ""
    var interfaceTrafficMonth: String = ""
    var interfaceTrafficSendLAN: String = ""
    var interfaceTrafficReceivedLAN: String = ""
    var interfaceTrafficSendWiFi: String = ""
    var interfaceTrafficReceivedWiFi: String = ""
    var ramProgress: Double = 0.0
    var storageProgress: Double = 0.0
    var storageTotal: String = ""
    var storageFree: String = ""
    var cpuAndTempProgress: List<CPUAndTempProgressVM> = ArrayList()
    var gpuTemp: List<CPUAndTempProgressVM> = ArrayList()
}