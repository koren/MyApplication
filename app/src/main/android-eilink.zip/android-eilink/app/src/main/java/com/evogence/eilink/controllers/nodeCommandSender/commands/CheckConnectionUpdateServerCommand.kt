package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.JsonPrimitive

class CheckConnectionUpdateServerCommand(parameters: Any?): INodeCommand
{
    override val method: String = "Integration.RPN.settings.ManagementServer::checkUpdateServer"
    override val desc: String = "Check Connection to Reverse Monitoring Configuration Server"

    override var params: MutableMap<String, Any> = HashMap()

    companion object MapKeys
    {
        const val HOST_KEY = "host"
    }

    init
    {
        params[HOST_KEY] = parameters as String
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonPrimitive)?.isBoolean ?: false
    }

    override fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()
        val result = (response.result as JsonPrimitive).asBoolean
        if(!result)
        {
            commandResult.error = "The connection with the server cannot be established"
        }
        return commandResult
    }
}

