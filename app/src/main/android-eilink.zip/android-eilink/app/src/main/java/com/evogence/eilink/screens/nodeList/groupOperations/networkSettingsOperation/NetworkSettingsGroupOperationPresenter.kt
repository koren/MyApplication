package com.evogence.eilink.screens.nodeList.groupOperations.networkSettingsOperation

import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.models.node.Node
import com.evogence.eilink.screens.nodeDetails.tabs.INodeDetailsTabView
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.NetworkSettingsPresenter
import com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab.NetworkSettingsVM

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class NetworkSettingsGroupOperationPresenter(fingerprints: Array<String>): NetworkSettingsPresenter(null)
{
    private var nodes: List<Node> = nodesStorage.getDevicesByFingerprint(fingerprints)
    private var numberErrorSaveNode: Int = 0
    private var numberSuccessSaveNode: Int = 0
    private lateinit var nodesQueue: MutableList<Node>

    init
    {
        node = nodes[0]
    }

    override fun attachView(view: INodeDetailsTabView<NetworkSettingsVM>)
    {
        this.view = view
        prepareViewModel()
        view.fill(viewModel)
    }

    override fun prepareViewModel()
    {
        viewModel.securityProtocols = getProtocols()
        viewModelBeforeChanges = viewModel.copy()
    }

    override fun saveChanges()
    {
        initSaveChangesNodesQueue()
        saveChangesNodesQueue()
    }

    private fun saveChangesNodesQueue()
    {
        if(nodesQueue.size > 0)
        {
            node = nodesQueue[0]
            nodesQueue.removeAt(0)
            sendSaveChangesCommand()
        }
        else
        {
            if(numberErrorSaveNode > 0 && numberSuccessSaveNode > 0)
                view?.showAlertDialog("Info", String.format("Save successful for %s nodes and failed for %s nodes.", numberSuccessSaveNode, numberErrorSaveNode))
            else if(numberErrorSaveNode == 0)
                view?.showAlertDialog("Info", "Successful")
            else
                view?.showAlertDialog("Error", "Failed for all nodes")
            view?.hideProgress()
        }
    }

    private fun initSaveChangesNodesQueue()
    {
        numberErrorSaveNode = 0
        numberSuccessSaveNode = 0
        nodesQueue = nodes.toMutableList()
    }

    private fun sendSaveChangesCommand()
    {
        sendSetNetSettingsCommand()
    }

    override fun processingSaveCommand(commandResult: CommandResult)
    {
        if(commandResult.error == null)
        {
            numberSuccessSaveNode++
            refreshNode()
        }
        else
            numberErrorSaveNode++

        saveChangesNodesQueue()
    }


}
