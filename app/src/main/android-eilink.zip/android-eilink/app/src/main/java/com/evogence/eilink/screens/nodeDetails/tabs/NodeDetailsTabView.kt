package com.evogence.eilink.screens.nodeDetails.tabs

import android.graphics.Rect
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.common.ui.ScreenView

/**
 * Created by Koren Vitalii on 9/12/2018.
 */
abstract class NodeDetailsTabView<T>: ScreenView(), INodeDetailsTabView<T>, View.OnClickListener
{
    override lateinit var presenter: NodeDetailsTabPresenter<T>
    override var changeSaveButtonStatusListener: ((Boolean)->Unit)? = null
    protected var enableDataChangeListener = true
    private var maxHeight: Int = 0
    private var isWatchingKeyboard: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?)
    {
        initPresenter()
        super.onCreate(savedInstanceState)
    }

    override fun onClick(v: View?)
    {
    }

    override fun onClickSave()
    {
        presenter.onSave()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(layout, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        initView()
        initKeyboardShowListener(view)

        presenter.attachView(this)
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onDestroyView()
    {
        changeSaveButtonStatusListener = null
        presenter.detachView()
        super.onDestroyView()
    }

    override fun enableSaveButton(enable: Boolean)
    {
        changeSaveButtonStatusListener?.invoke(enable)
    }

    private fun initKeyboardShowListener(view: View)
    {
        view.viewTreeObserver.addOnGlobalLayoutListener {

            val rect = Rect().apply {view.rootView.getWindowVisibleDisplayFrame(this)}
            maxHeight = Math.max(rect.bottom, maxHeight)

            if((rect.bottom < maxHeight) && !this.isWatchingKeyboard)
            {
                this.isWatchingKeyboard = true
            }
            else if((rect.bottom >= maxHeight) && this.isWatchingKeyboard)
            {
                this.isWatchingKeyboard = false
                dataMayChanged()
            }
        }
    }

    protected fun dataMayChanged()
    {
        if(enableDataChangeListener)
            presenter.onDataChanged()
    }
}