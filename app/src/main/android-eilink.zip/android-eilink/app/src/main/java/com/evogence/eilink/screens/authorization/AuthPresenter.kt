package com.evogence.eilink.screens.authorization

import com.evogence.eilink.EiLinkApplication
import com.evogence.eilink.common.SysInfo
import com.evogence.eilink.controllers.authManager.AuthManager
import com.evogence.eilink.screens.INavigator
import javax.inject.Inject

/**
 * Created by Koren Vitalii on 8/28/2018.
 */
class AuthPresenter
{
    private var view: AuthView? = null
    private val viewModel = AuthVM()

    @Inject lateinit var authManager: AuthManager
    @Inject lateinit var navigator: INavigator
    @Inject lateinit var sysInfo: SysInfo

    init
    {
        EiLinkApplication.appComponent.inject(this)
    }

    fun onAttachView(view: AuthView)
    {
        this.view = view
        prepareViewModel()
        view.fill(viewModel)
    }

    private fun prepareViewModel()
    {
        viewModel.title = "[Ei] Link " + sysInfo.shortVersion
    }

    fun onDetachView()
    {
        view?.hideProgress()
        view = null
    }

    fun onLogin()
    {
        view?.retrieveChanges(viewModel)
        val error = validation(viewModel.username, viewModel.password)
        if(error == null)
        {
            authManager.authByLogin(viewModel.username, viewModel.password)
            {
                if(it == null)
                    navigator.navigateToNodeList()
                else
                    view?.showAlertDialog("Info", it)
            }
        }
        else
            view?.showAlertDialog("Info", error)
    }

    private fun validation(login: String, password: String): String?
    {
        var error: String? = null
        if(login.isEmpty() || password.isEmpty())
            error = "Please enter login and password"
        return error
    }
}