package com.evogence.eilink.common.dialogs

import android.app.Dialog
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.support.v4.app.FragmentManager
import android.support.v7.app.AlertDialog

/**
 * Created by Koren Vitalii on 07/26/18.
 */
class AlertDialogFragment: DialogFragment()
{
    private var showPositiveButton: Boolean = false
    private var showNegativeButton: Boolean = false
    private var positiveButtonTextId: Int = android.R.string.ok
    private var negativeButtonTextId: Int = android.R.string.no
    private var observer: DialogResultObserver? = null

    companion object
    {
        private const val TITLE_KEY = "title"
        private const val MESSAGE_KEY = "message"
        private const val SHOW_POSITIVE_BUTTON_KEY = "show_positive_button"
        private const val SHOW_NEGATIVE_BUTTON_KEY = "show_negative_button"
        private const val POSITIVE_BUTTON_ID_KEY = "positive_button_id"
        private const val NEGATIVE_BUTTON_ID_KEY = "negative_button_id"

        fun getInstance(title: String, message: String, showPositiveButton: Boolean, showNegativeButton: Boolean, positiveButtonTextId: Int = android.R.string.ok, negativeButtonTextId: Int = android.R.string.no): AlertDialogFragment
        {
            val dialog = AlertDialogFragment()
            val bundle = Bundle()
            bundle.putString(TITLE_KEY, title)
            bundle.putString(MESSAGE_KEY, message)
            bundle.putBoolean(SHOW_POSITIVE_BUTTON_KEY, showPositiveButton)
            bundle.putBoolean(SHOW_NEGATIVE_BUTTON_KEY, showNegativeButton)
            bundle.putInt(POSITIVE_BUTTON_ID_KEY, positiveButtonTextId)
            bundle.putInt(NEGATIVE_BUTTON_ID_KEY, negativeButtonTextId)

            dialog.arguments = bundle
            return dialog
        }
    }

    fun setObserver(observer: DialogResultObserver)
    {
        this.observer = observer
    }

    fun show(fragmentManager: FragmentManager)
    {
        show(fragmentManager, this.javaClass.name)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        var title: String? = null
        var message: String? = null
        if(arguments != null)
        {
            title = arguments!!.getString(TITLE_KEY)
            message = arguments!!.getString(MESSAGE_KEY)
            showPositiveButton = arguments!!.getBoolean(SHOW_POSITIVE_BUTTON_KEY)
            showNegativeButton = arguments!!.getBoolean(SHOW_NEGATIVE_BUTTON_KEY)
            positiveButtonTextId = arguments!!.getInt(POSITIVE_BUTTON_ID_KEY)
            negativeButtonTextId = arguments!!.getInt(NEGATIVE_BUTTON_ID_KEY)
        }
        val dialog = AlertDialog.Builder(activity!!)
            .setTitle(title)
            .setMessage(message)
        if(showPositiveButton)
            dialog.setPositiveButton(positiveButtonTextId) {_, _->
                if(observer != null)
                    observer!!.onClickPositive()
                dismiss()
            }

        if(showNegativeButton)
            dialog.setNegativeButton(negativeButtonTextId) {_, _-> dismiss()}

        return dialog.create()
    }

    interface DialogResultObserver
    {
        fun onClickPositive()
    }
}
