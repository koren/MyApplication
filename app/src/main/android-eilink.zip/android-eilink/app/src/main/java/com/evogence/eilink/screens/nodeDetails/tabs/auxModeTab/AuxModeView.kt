package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab

import android.annotation.SuppressLint
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat
import android.support.v7.widget.LinearLayoutManager
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.PopupWindow
import android.widget.TextView
import com.evogence.eilink.R
import com.evogence.eilink.common.Utils
import com.evogence.eilink.common.dialogs.AlertDialogFragment
import com.evogence.eilink.common.ui.SelectorView
import com.evogence.eilink.controllers.nodeCommandSender.EPairState
import com.evogence.eilink.controllers.nodeCommandSender.EPairType
import com.evogence.eilink.models.node.ENodeOnlineStatus
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabView
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.pager.AuxModePage
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.pager.AuxModePagerAdapter
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.pager.GridNodePage
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.pager.SerialNumberPage
import kotlinx.android.synthetic.main.node_details_aux_mode.*
import kotlinx.android.synthetic.main.node_details_aux_mode_node_select_list.view.*
import kotlinx.android.synthetic.main.node_details_aux_mode_node_select_list_item.*

/**
 * Created by Koren Vitalii on 9/25/2018.
 */
class AuxModeView: NodeDetailsTabView<AuxModeVM>(), View.OnClickListener, IAuxModeView
{
    override val layout = R.layout.node_details_aux_mode
    override val title = "Mode"
    override val isShowSaveButton = false
    private lateinit var gridNodeAuxModePage: AuxModePage
    private lateinit var serialNumberAuxModePage: AuxModePage
    private lateinit var auxModePagerAdapter: AuxModePagerAdapter
    private var popupList: PopupWindow? = null

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"

        @JvmStatic
        fun build(fingerprint: String): Fragment
        {
            val fragment = AuxModeView()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }
    }

    override fun fill(model: Any)
    {
        model as AuxModeVM
        viewPager.currentItem = auxModePagerAdapter.getItemPosition(model.modeConfiguration.typeLink)
        setVisibleView(model.modeConfiguration.pairState)

        when(model.modeConfiguration.pairState)
        {
            EPairState.PAIR ->
            {
                applianceImg.setImageResource(Utils.prepareIconRes(context, model.iconName))

                statusImg.visibility = View.VISIBLE
                if(model.modeConfiguration.onlineStatus == ENodeOnlineStatus.ONLINE)
                    statusImg.setImageDrawable(ContextCompat.getDrawable(activity!!, R.drawable.status_active))
                else
                    statusImg.setImageDrawable(ContextCompat.getDrawable(activity!!, R.drawable.status_inactive))

                modelLabelTV.text = model.modeConfiguration.model
                nodeNameTV.text = model.modeConfiguration.title
                addressTV.text = model.modeConfiguration.ip
                serialNumberTV.text = model.modeConfiguration.pairSN
                versionLabelTV.text = model.modeConfiguration.version

                timeoutPairedNodeET.setText(model.modeConfiguration.timeout.toString())
                portPairedNodeSwitch.isChecked = model.modeConfiguration.isEnablePort
                watchdogPairedNodeSwitch.isChecked = model.modeConfiguration.isEnableWatchdog

                infoTV.visibility = View.GONE

                onPortPairedNodeSwitch()
                onWatchdogPairedNodeSwitch()
            }
            EPairState.UNPAIR ->
            {
                infoTV.visibility = View.VISIBLE
            }
        }

        gridNodeAuxModePage.fill(model)
        serialNumberAuxModePage.fill(model)
    }

    override fun retrieveChanges(model: AuxModeVM)
    {
        gridNodeAuxModePage.retrieveChanges(model)
        serialNumberAuxModePage.retrieveChanges(model)

        model.modeConfiguration.typeLink = auxModePagerAdapter.getPairType(viewPager.currentItem)

        model.modeConfiguration.timeout = timeoutPairedNodeET.text.toString().toDoubleOrNull() ?: 0.0
        model.modeConfiguration.isEnablePort = portPairedNodeSwitch.isChecked
        model.modeConfiguration.isEnableWatchdog = watchdogPairedNodeSwitch.isChecked
    }

    override fun initPresenter()
    {
        presenter = AuxModePresenter(arguments?.getString(FINGERPRINT_KEY))
    }

    override fun initView()
    {
        gridNodeAuxModePage = GridNodePage.build(arguments?.getString(FINGERPRINT_KEY))
        serialNumberAuxModePage = SerialNumberPage.build(arguments?.getString(FINGERPRINT_KEY))

        initTabs()
        val selectorView = SelectorView()

        unpairBtn.setOnTouchListener(selectorView)
        refreshBtn.setOnTouchListener(selectorView)
        savePairedNodeBtn.setOnTouchListener(selectorView)

        unpairBtn.setOnClickListener(this)
        refreshBtn.setOnClickListener(this)
        savePairedNodeBtn.setOnClickListener(this)

        portPairedNodeSwitch.setOnClickListener(this)
        watchdogPairedNodeSwitch.setOnClickListener(this)
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.unpairBtn -> (presenter as AuxModePresenter).onUnpair()
            R.id.refreshBtn -> (presenter as AuxModePresenter).onRefresh()
            R.id.savePairedNodeBtn -> presenter.onSave()

            R.id.portPairedNodeSwitch -> onPortPairedNodeSwitch()
            R.id.watchdogPairedNodeSwitch -> onWatchdogPairedNodeSwitch()
        }
    }

    override fun onClickPair()
    {
        (presenter as AuxModePresenter).pairNode()
    }

    override fun onClickSelectNode()
    {
        (presenter as AuxModePresenter).selectNode()
    }

    @SuppressLint("InflateParams")
    override fun showNodeList(nodeList: List<ListItemVM>)
    {
        val popupView = LayoutInflater.from(activity).inflate(R.layout.node_details_aux_mode_node_select_list, null)
        popupList = PopupWindow(popupView, WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT)

        val adapter = ListAdapter(activity!!)
        adapter.setOnClickObserver(object: ListAdapter.OnItemClicked
        {
            override fun onItemClick(position: Int)
            {
                (presenter as AuxModePresenter).onItemClick(nodeList[position])
            }
        })
        popupView.gridNodesRecyclerView.layoutManager = LinearLayoutManager(activity!!)
        popupView.gridNodesRecyclerView.adapter = adapter

        adapter.setList(nodeList)
        popupList?.showAtLocation(popupView, Gravity.CENTER, 0, 0)
    }

    override fun hideNodeList()
    {
        popupList?.dismiss()
    }

    override fun showAlertDialogWithObserver(title: String, message: String, positiveButtonTextId: Int, negativeButtonTextId: Int, observer: AlertDialogFragment.DialogResultObserver)
    {
        val dialog = AlertDialogFragment.getInstance(title, message, true, true, positiveButtonTextId, negativeButtonTextId)
        dialog.setObserver(observer)
        fragmentManager?.let {dialog.show(it)}
    }

    private fun onWatchdogPairedNodeSwitch()
    {
        if(!watchdogPairedNodeSwitch.isChecked)
            timeoutPairedNodeET.setText("")

        timeoutPairedNodeET.isEnabled = watchdogPairedNodeSwitch.isChecked
    }

    private fun onPortPairedNodeSwitch()
    {
        savePairedNodeBtn.isEnabled = portPairedNodeSwitch.isChecked
        watchdogPairedNodeSwitch.isEnabled = portPairedNodeSwitch.isChecked

        if(!portPairedNodeSwitch.isChecked)
            watchdogPairedNodeSwitch.isChecked = false

        onWatchdogPairedNodeSwitch()
    }

    private fun setVisibleView(pairState: EPairState)
    {
        when(pairState)
        {
            EPairState.PAIR ->
            {
                pairingNodeContainer.visibility = View.GONE
                nodePairedContainer.visibility = View.VISIBLE
                switchPortContainer.visibility = View.VISIBLE
            }
            EPairState.UNPAIR ->
            {
                nodePairedContainer.visibility = View.GONE
                switchPortContainer.visibility = View.GONE
                pairingNodeContainer.visibility = View.VISIBLE
            }
        }
    }

    private fun initTabs()
    {
        serialNumberAuxModePage.auxModeView = this
        gridNodeAuxModePage.auxModeView = this
        auxModePagerAdapter = AuxModePagerAdapter(context!!, listOf(serialNumberAuxModePage, gridNodeAuxModePage), listOf(EPairType.MANUALY, EPairType.LIST), activity?.supportFragmentManager!!)
        viewPager.adapter = auxModePagerAdapter

        tabLayout.setupWithViewPager(viewPager)
        for(i in 0 until tabLayout.tabCount)
        {
            val tab = tabLayout.getTabAt(i)
            tab?.customView = auxModePagerAdapter.getTabView(i)
            if(i == 0)
                setTabSelectedStyle(tab)
            else
                setTabUnselectedStyle(tab)
        }

        tabLayout.addOnTabSelectedListener(object: TabLayout.OnTabSelectedListener
        {
            override fun onTabReselected(tab: TabLayout.Tab?)
            {
            }

            override fun onTabUnselected(tab: TabLayout.Tab?)
            {
                setTabUnselectedStyle(tab)
            }

            override fun onTabSelected(tab: TabLayout.Tab?)
            {
                setTabSelectedStyle(tab)
            }
        })
    }

    fun setTabSelectedStyle(tab: TabLayout.Tab?)
    {
        tab?.customView?.let {
            it.findViewById<TextView>(R.id.selectedTV).visibility = View.VISIBLE
            it.findViewById<TextView>(R.id.unselectedTV).visibility = View.GONE
        }
    }

    fun setTabUnselectedStyle(tab: TabLayout.Tab?)
    {
        tab?.customView?.let {
            it.findViewById<TextView>(R.id.selectedTV).visibility = View.GONE
            it.findViewById<TextView>(R.id.unselectedTV).visibility = View.VISIBLE
        }
    }
}