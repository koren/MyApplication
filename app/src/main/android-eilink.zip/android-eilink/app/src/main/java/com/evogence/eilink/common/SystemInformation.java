package com.evogence.eilink.common;

import android.content.Context;
import android.telephony.TelephonyManager;

import java.util.UUID;

public class SystemInformation
{
    public static final String NONE_STR = "none";

    private SystemInformation()
    {
    }

//    static public EConnectionType getConnectionType(Context _context)
//    {
//        EConnectionType result = EConnectionType.NONE;
//
//        ConnectivityManager cm = (ConnectivityManager) _context.getSystemService(Context.CONNECTIVITY_SERVICE);
//        NetworkInfo info = cm.getActiveNetworkInfo();
//        if (info != null)
//        {
//            if ((info.getType() == ConnectivityManager.TYPE_WIFI) || (info.getType() == ConnectivityManager.TYPE_ETHERNET))
//                result = EConnectionType.WIFI;
//            else
//                result = EConnectionType.WWAN;
//        }
//
//        return result;
//    }

//    public static boolean isInetConnect(Context context)
//    {
//        boolean result = false;
//
//        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
//        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
//        if (networkInfo != null && networkInfo.isConnected())
//            result = true;
//
//        return result;
//    }

    static public String getUdid(Context context)
    {
        final TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);

        final String tmDevice, tmSerial, androidId;
        tmDevice = "" + tm.getDeviceId();
        tmSerial = "" + tm.getSimSerialNumber();
        androidId = "" + android.provider .Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);

        UUID deviceUuid = new UUID(androidId.hashCode(), ((long) tmDevice.hashCode() << 32) | tmSerial.hashCode());
        return deviceUuid.toString();
    }


//    static public String getLocalIpAddress()
//    {
//        try
//        {
//            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); )
//            {
//                NetworkInterface intf = en.nextElement();
//                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); )
//                {
//                    InetAddress inetAddress = enumIpAddr.nextElement();
//                    if (!inetAddress.isLoopbackAddress())
//                    {
//                        return inetAddress.getHostAddress().toString();
//                    }
//                }
//            }
//        }
//        catch (SocketException ex)
//        {
//            Log.e("ERROR", ex.toString());
//        }
//
//        return null;
//    }
//
//    static public String getPlatformUniqId(Context context)
//    {
//        String result = "";
//
//        if (context != null)
//            result = context.getString(R.string.platform_uniqid);
//
//        return result;
//    }
//
//    public static String getIPAddress(boolean useIPv4)
//    {
//        try
//        {
//            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
//            for (NetworkInterface intf : interfaces)
//            {
//                List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
//                for (InetAddress addr : addrs)
//                {
//                    if (!addr.isLoopbackAddress())
//                    {
//                        String sAddr = addr.getHostAddress().toLowerCase(Locale.getDefault());
//
//                        //FIXME anl: need find new way to prepareConnectionData ip address
////                        boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
////                        if (useIPv4)
////                        {
////                            if (isIPv4)
////                                return sAddr;
////                        }
////                        else
////                        {
////                            if (!isIPv4)
////                            {
////                                int delim = sAddr.indexOf('%'); // drop ip6 port suffix
////                                return delim < 0 ? sAddr : sAddr.substring(0, delim);
////                            }
////                        }
//                    }
//                }
//            }
//        }
//        catch (Exception ex)
//        {
//        } // for now eat exceptions
//
//        return null;
//    }
//
//    public static boolean externalMemoryAvailable()
//    {
//        return Environment.getExternalStorageState().equals(
//                Environment.MEDIA_MOUNTED);
//    }
//
//    public static long getSizeByPath(String path)
//    {
//        long size = -1;
//
//        if (path != null && !path.isEmpty())
//        {
//            StatFs stat = new StatFs(path);
//            long blockSize = stat.getBlockSize();
//            long blockCount = stat.getBlockCount();
//            size = blockSize * blockCount;
//        }
//
//        return size;
//    }
//
//    public static long getAvailableSizeByPath(String path)
//    {
//        long size = -1;
//
//        if (path != null && !path.isEmpty())
//        {
//            StatFs stat = new StatFs(path);
//            long blockSize = stat.getBlockSize();
//            long availableBlocks = stat.getAvailableBlocks();
//            size = blockSize * availableBlocks;
//        }
//
//        return size;
//    }
//
//    public static long getAvailableInternalMemorySize()
//    {
//        File path = Environment.getDataDirectory();
//        long size = getAvailableSizeByPath(path.getAbsolutePath());
//        return size;
//    }
//
//    public static String getAvailableInternalMemorySizeStr()
//    {
//        long size = getAvailableInternalMemorySize();
//        String sizeStr = NONE_STR;
//        if (size > 0)
//            sizeStr = formatSize(size);
//
//        return sizeStr;
//    }
//
//    public static long getTotalInternalMemorySize()
//    {
//        File path = Environment.getDataDirectory();
//        long size = getSizeByPath(path.getAbsolutePath());
//        return size;
//    }
//
//    public static String getTotalInternalMemorySizeStr()
//    {
//        long size = getTotalInternalMemorySize();
//        String sizeStr = NONE_STR;
//        if (size > 0)
//            sizeStr = formatSize(size);
//
//        return sizeStr;
//    }
//
//    public static long getAvailableExternalMemorySize()
//    {
//        File path = Environment.getExternalStorageDirectory();
//        long size = getAvailableSizeByPath(path.getAbsolutePath());
//        return size;
//    }
//
//    public static String getAvailableExternalMemorySizeStr()
//    {
//        String sizeStr = NONE_STR;
//
//        if (externalMemoryAvailable())
//        {
//            long size = getAvailableExternalMemorySize();
//            if (size > 0)
//                sizeStr = formatSize(size);
//        }
//
//        return sizeStr;
//    }
//
//    public static long getTotalExternalMemorySize()
//    {
//        File path = Environment.getExternalStorageDirectory();
//        long size = getSizeByPath(path.getAbsolutePath());
//        return size;
//    }
//
//    public static String getTotalExternalMemorySizeStr()
//    {
//        String sizeStr = NONE_STR;
//
//        if (externalMemoryAvailable())
//        {
//            long size = getTotalExternalMemorySize();
//            if (size > 0)
//                sizeStr = formatSize(size);
//        }
//
//        return sizeStr;
//    }
//
//    public static String formatSize(long size)
//    {
//        String suffix = null;
//
//        if (size >= 1024)
//        {
//            suffix = "KB";
//            size /= 1024;
//            if (size >= 1024)
//            {
//                suffix = "MB";
//                size /= 1024;
//            }
//        }
//
//        StringBuilder resultBuffer = new StringBuilder(Long.toString(size));
//
//        int commaOffset = resultBuffer.length() - 3;
//        while (commaOffset > 0)
//        {
//            resultBuffer.insert(commaOffset, ',');
//            commaOffset -= 3;
//        }
//
//        if (suffix != null) resultBuffer.append(suffix);
//        return resultBuffer.toString();
//    }
//
//    public static String getDocDir(Context context)
//    {
//        String docDir = null;
//        if (context != null)
//        {
//            String filesDir = context.getFilesDir().getAbsolutePath();
//            int lastFolder = filesDir.lastIndexOf(File.separator);
//            docDir = filesDir.substring(0, lastFolder);
//        }
//        return docDir;
//    }
//
//    public static String getCpuInfo()
//    {
//        StringBuffer sb = new StringBuffer();
//        sb.append("abi: ").append(Build.CPU_ABI).append("\n");
//        if (new File("/proc/cpuinfo").exists())
//        {
//            try
//            {
//                BufferedReader br = new BufferedReader(new FileReader(new File("/proc/cpuinfo")));
//                String aLine;
//                while ((aLine = br.readLine()) != null)
//                {
//                    sb.append(aLine + "\n");
//                }
//                if (br != null)
//                    br.close();
//            }
//            catch (IOException e)
//            {
//                e.printStackTrace();
//            }
//        }
//        return sb.toString();
//    }
//
//    public static float readCpuUsage()
//    {
//        try
//        {
//            RandomAccessFile reader = new RandomAccessFile("/proc/stat", "r");
//            String load = reader.readLine();
//
//            String[] toks = load.split(" ");
//
//            long idle1 = Long.parseLong(toks[5]);
//            long cpu1 = Long.parseLong(toks[2]) + Long.parseLong(toks[3]) + Long.parseLong(toks[4])
//                    + Long.parseLong(toks[6]) + Long.parseLong(toks[7]) + Long.parseLong(toks[8]);
//
//            try
//            {
//                Thread.sleep(360);
//            }
//            catch (Exception ignored)
//            {
//            }
//
//            reader.seek(0);
//            load = reader.readLine();
//            reader.close();
//
//            toks = load.split(" ");
//
//            long idle2 = Long.parseLong(toks[5]);
//            long cpu2 = Long.parseLong(toks[2]) + Long.parseLong(toks[3]) + Long.parseLong(toks[4])
//                    + Long.parseLong(toks[6]) + Long.parseLong(toks[7]) + Long.parseLong(toks[8]);
//
//            return (float) (cpu2 - cpu1) / ((cpu2 + idle2) - (cpu1 + idle1));
//
//        }
//        catch (Exception ex)
//        {
//            ex.getMessage();
//        }
//
//        return 0;
//    }
//
//    public static String getDeviceName()
//    {
//        String manufacturer = Build.MANUFACTURER;
//        String model = Build.MODEL;
//        if (model.startsWith(manufacturer))
//            return model;
//        else
//            return manufacturer + " " + model;
//    }
//
//    public static String getTempFileDir()
//    {
//        String fileDir = "";
//        File dcimDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
//
//        if (dcimDir != null && dcimDir.exists())
//        {
//            fileDir = dcimDir.getAbsolutePath() + File.separator;
//            File tempFileDir = new File(fileDir);
//            if (!tempFileDir.exists())
//                tempFileDir.mkdir();
//        }
//
//        return fileDir;
//    }
//
//    public static double getScreenSizeInInch(Context context)
//    {
//        DisplayMetrics dm = context.getResources().getDisplayMetrics();
//
//        float screenWidth = dm.widthPixels / dm.xdpi;
//        float screenHeight = dm.heightPixels / dm.ydpi;
//
//        Logger.write("ScreenInch: fullDPI: w: " + dm.xdpi + " h: " + dm.ydpi);
//        Logger.write("ScreenInch: full: w: " + dm.widthPixels + " h: " + dm.heightPixels);
//        Logger.write("ScreenInch: w: " + screenWidth + " h: " + screenHeight);
//
//        double size = Math.sqrt(Math.pow(screenWidth, 2) + Math.pow(screenHeight, 2));
//
//        return size + (size * 0.085f);
//    }
//
//    public static String getDeviceModel(Context context)
//    {
//        String model = "asme_tablet_android";
//        double inch = SystemInformation.getScreenSizeInInch(context);
//
//        if (context.getResources().getDisplayMetrics().densityDpi <= DisplayMetrics.DENSITY_MEDIUM)
//        {
//            model = "asme_appliance_android";
//        }
//        else
//        {
//            if (inch > 7 && inch <= 18.2d)
//            {
//                model = "asme_tablet_android";
//            }
//            else if (inch > 18.2d)
//            {
//                UiModeManager uiModeManager = (UiModeManager) context.getSystemService(Context.UI_MODE_SERVICE);
//                if (uiModeManager.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION)
//                    model = "asme_appliance_android";
//                else
//                    model = "asme_aio_android";
//            }
//        }
//        return model;
//    }
//
//    public static String getAppVersion(Context context)
//    {
//        return SystemInformation.getLongVersion(context);
//    }
//
//    public static String getLongVersion(Context context)
//    {
//        String result = "N/A";
//        try
//        {
//            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
//            result = pInfo.versionName + ".b" + pInfo.versionCode;
//        }
//        catch (PackageManager.NameNotFoundException ex)
//        {
//            ex.printStackTrace();
//        }
//
//        return result;
//    }
//
//    public static String getShortVersion(Context context)
//    {
//        String result = "N/A";
//        try
//        {
//            PackageInfo pInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
//            result = pInfo.versionName;
//        }
//        catch (PackageManager.NameNotFoundException ex)
//        {
//            ex.printStackTrace();
//        }
//
//        return result;
//    }
}
