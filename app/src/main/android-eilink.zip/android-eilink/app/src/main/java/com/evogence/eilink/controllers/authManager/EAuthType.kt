package com.evogence.eilink.controllers.authManager

/**
 * Created by Koren Vitalii on 8/28/2018.
 */
enum class EAuthType(val value: Int)
{
    NONE_AUTH(0),
    AUTH_BY_PIN(1),
    AUTH_BY_LOGIN(2)
}