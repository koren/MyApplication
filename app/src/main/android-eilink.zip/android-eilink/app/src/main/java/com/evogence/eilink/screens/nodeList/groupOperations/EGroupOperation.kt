package com.evogence.eilink.screens.nodeList.groupOperations

enum class EGroupOperation
{
    Integration,
    Network,
    Reboot
}
