package com.evogence.eilink.screens.nodeDetails.tabs.networkSettingsTab

import com.evogence.eilink.screens.nodeDetails.tabs.integrationTab.NodeIntegrationVM

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class NetworkSettingsVM: Cloneable
{
    var wifiEnable: Boolean = false
    var wifiPreferred: Boolean = false
    var wifiSSID: String = ""
    var wifiSecurityProtocol: String = ""
    var wifiSecurityAuthKey: String = ""
    var wifiIdentity: String = ""
    var wifiPassword: String = ""
    var wifiIpDHCP: Boolean = false
    var wifiIpV4: Boolean = false
    var wifiIpAddress: String = ""
    var wifiNetmask: String = ""
    var wifiGateway: String = ""
    var dns1: String = ""
    var dns2: String = ""
    var dns3: String = ""
    var ethernetIpDHCP: Boolean = false
    var ethernetIpV4: Boolean = false
    var ethernetIpAddress: String = ""
    var ethernetNetmask: String = ""
    var ethernetGateway: String = ""
    var securityProtocols: Map<String, String> = HashMap()

    override fun equals(other: Any?): Boolean
    {
        return hashCode() == (other as NetworkSettingsVM).hashCode()
    }

    fun copy(): NetworkSettingsVM
    {
        return this.clone() as NetworkSettingsVM
    }

    override fun hashCode(): Int
    {
        var result = wifiEnable.hashCode()
        result = 31 * result + wifiPreferred.hashCode()
        result = 31 * result + wifiSSID.hashCode()
        result = 31 * result + wifiSecurityProtocol.hashCode()
        result = 31 * result + wifiSecurityAuthKey.hashCode()
        result = 31 * result + wifiIdentity.hashCode()
        result = 31 * result + wifiPassword.hashCode()
        result = 31 * result + wifiIpDHCP.hashCode()
        result = 31 * result + wifiIpV4.hashCode()
        result = 31 * result + wifiIpAddress.hashCode()
        result = 31 * result + wifiNetmask.hashCode()
        result = 31 * result + wifiGateway.hashCode()
        result = 31 * result + dns1.hashCode()
        result = 31 * result + dns2.hashCode()
        result = 31 * result + dns3.hashCode()
        result = 31 * result + ethernetIpDHCP.hashCode()
        result = 31 * result + ethernetIpV4.hashCode()
        result = 31 * result + ethernetIpAddress.hashCode()
        result = 31 * result + ethernetNetmask.hashCode()
        result = 31 * result + ethernetGateway.hashCode()
        result = 31 * result + securityProtocols.hashCode()
        return result
    }
}
