package com.evogence.eilink.screens.nodeDetails.tabs.profileTab

import android.graphics.Color
import com.evogence.eilink.common.BlockRunnable
import com.evogence.eilink.common.dialogs.AlertDialogFragment
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.evogence.eilink.controllers.nodeCommandSender.ENodeCommand
import com.evogence.eilink.screens.nodeDetails.tabs.NodeDetailsTabPresenter
import com.evogence.eilink.screens.nodeDetails.tabs.restartSchedulerTab.ERebootAndShutdownCommand
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Koren Vitalii on 05/29/18.
 */
class ProfilePresenter(fingerprint: String?): NodeDetailsTabPresenter<ProfileVM>(fingerprint)
{
    override var viewModel = ProfileVM()

    override fun prepareViewModel()
    {
        viewModel.sId = node.sid
        viewModel.edition = node.edition.capitalize()
        viewModel.company = node.company.capitalize()
        viewModel.location = node.location.capitalize()
        viewModel.ipAddress = node.address.capitalize()
        viewModel.timeZone = node.timezone.capitalize()
        viewModel.upTime = node.upTime
        viewModel.systemTime = node.sysTime

        if(node.registrationDate > 0)
        {
            val simpleDateFormat = SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault())
            viewModel.registrationDate = simpleDateFormat.format(node.registrationDate)
        }
        else
            viewModel.registrationDate = "N/A"

        viewModel.videoChannels = String.format("Video: %s", node.videoChannelsCount)
        viewModel.audioChannels = String.format("Audio: %s", node.audioChannelsCount)
        viewModel.activity = String.format("%s day(s)", if(node.period == null) "N/A" else node.period)
        if(node.rebootEnabled)
        {
            val calendar = Calendar.getInstance()
            calendar.set(Calendar.HOUR, node.rebootHour)
            calendar.set(Calendar.MINUTE, node.rebootMinute)

            val simpleDateFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

            val time = simpleDateFormat.format(calendar.time)
            viewModel.rebootScheduler = String.format("every day at %s", time)
            viewModel.rebootSchedulerColor = Color.rgb(54, 56, 60)
        }
        else
        {
            viewModel.rebootScheduler = "disabled"
            viewModel.rebootSchedulerColor = Color.rgb(236, 0, 22)
        }
    }

    override fun saveChanges()
    {
    }

    fun onClickShutdown()
    {
        view?.showAlertDialog("", "Do you want to shutdown the Node?", object: AlertDialogFragment.DialogResultObserver
        {
            override fun onClickPositive()
            {
                sendShutdownNodeCommand()
            }
        }, true, true)
    }

    private fun sendShutdownNodeCommand()
    {
        commandSender.send(ENodeCommand.REBOOT_AND_SHUTDOWN, node, ERebootAndShutdownCommand.SHUTDOWN_APPLIANCE.type, BlockRunnable {processingCommand(it)})
    }

    fun onClickReboot()
    {
        view?.showAlertDialog("", "Do you want to restart the Node?", object: AlertDialogFragment.DialogResultObserver
        {
            override fun onClickPositive()
            {
                sendRestartNodeCommand()
            }
        }, true, true)
    }

    private fun sendRestartNodeCommand()
    {
        commandSender.send(ENodeCommand.REBOOT_AND_SHUTDOWN, node, ERebootAndShutdownCommand.REBOOT_SCHEDULER.type, BlockRunnable {this.processingCommand(it)})
    }

    fun onClickRestart()
    {
        view?.showAlertDialog("", "Do you want to restart playback?", object: AlertDialogFragment.DialogResultObserver
        {
            override fun onClickPositive()
            {
                sendRestartPalybackCommand()
            }
        }, true, true)
    }

    private fun sendRestartPalybackCommand()
    {
        commandSender.send(ENodeCommand.REBOOT_AND_SHUTDOWN, node, ERebootAndShutdownCommand.REBOOT_PLAYBACK.type, BlockRunnable {this.processingCommand(it)})
    }

    private fun processingCommand(commandResult: CommandResult)
    {
        view?.hideProgress()
        if(commandResult.error == null)
            view?.showAlertDialog("Info", "Successful")
        else
            showCommandError(commandResult)
    }

    private fun showCommandError(commandResult: CommandResult)
    {
        if(commandResult.isSupported)
            view?.showAlertDialog("Error", commandResult.error)
        else
            view?.showAlertDialog(message = commandResult.error)
    }
}
