package com.evogence.eilink.screens.nodeDetails.integrationStatusesUpdater

enum class EConnectionStatus
{
    UNDEFINED_STATUS,
    CONNECTED_STATUS,
    DISCONNECTED_STATUS
}
