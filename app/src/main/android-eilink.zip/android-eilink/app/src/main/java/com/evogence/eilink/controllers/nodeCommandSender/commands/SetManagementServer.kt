package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.JsonPrimitive

class SetManagementServer(parameters: Any?): INodeCommand
{
    override val method: String = "Integration.RPN.settings.ManagementServer::setIntegrationParams"
    override val desc: String = "Set Management Server"

    override var params: MutableMap<String, Any> = HashMap()

    companion object MapKeys
    {
        const val HOST_KEY = "host"
        const val PARAMS_KEY = "params"
        const val IS_ES_ENABLE_KEY = "is_es_enable"
        const val USE_ES_AS_UPDATE_SERVER_KEY = "use_es_as_update_server"
        const val USE_ES_SSH_CONNECTION_KEY = "use_es_ssh_connection"
        const val TASK_TIMEOUT_KEY = "task_timeout"
        const val REGISTER_TOKEN_KEY = "register_token"
        const val PRIMARY_ES_KEY = "primary_es"
        const val HTTP_PORT_KEY = "http_port"
        const val SSH_PORT_KEY = "ssh_port"
        const val FTP_PORT_KEY = "ftp_port"
        const val SECONDARY_ES_KEY = "secondary_es"
    }

    init
    {
        params[SetManagementServer.PARAMS_KEY] = parameters as MutableMap<String, Any>
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonPrimitive)?.isBoolean ?: false
    }

    override fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()
        val result = (response.result as JsonPrimitive).asBoolean
        if(!result)
        {
            if((response.error) != null && (response.error!!.message != null))
            {
                commandResult.error = "Configuration have not been changed: " + response.error!!.message
            }
            else
            {
                commandResult.error = "Configuration have not been changed."
            }
        }
        return commandResult
    }
}