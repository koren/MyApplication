package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import com.evogence.eilink.R

/**
 * Created by Koren Vitalii on 8/30/2018.
 */
class ListAdapter(val context: Context): RecyclerView.Adapter<ListItemHolder>()
{
    private var onClick: OnItemClicked? = null

    interface OnItemClicked
    {
        fun onItemClick(position: Int)
    }

    lateinit var nodes: List<ListItemVM>

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListItemHolder
    {
        val view = LayoutInflater.from(context).inflate(R.layout.node_details_aux_mode_node_select_list_item, parent, false)
        return ListItemHolder(view)
    }

    override fun getItemCount(): Int
    {
        return nodes.size
    }

    override fun onBindViewHolder(holder: ListItemHolder, position: Int)
    {
        holder.bind(nodes[position])
        holder.itemView.setOnClickListener { onClick?.onItemClick(position) }
    }

    fun setList(nodes: List<ListItemVM>)
    {
        this.nodes = nodes
        notifyDataSetChanged()
    }

    fun setOnClickObserver(onClick: OnItemClicked)
    {
        this.onClick = onClick
    }
}