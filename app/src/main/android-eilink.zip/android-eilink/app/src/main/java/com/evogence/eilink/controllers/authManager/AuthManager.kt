package com.evogence.eilink.controllers.authManager

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager

/**
 * Created by Koren Vitalii on 19.04.2018.
 */
class AuthManager(context: Context)
{
    private var status: EAuthStatus = EAuthStatus.NON_AUTH
    private var preferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)

    companion object
    {
        const val DEFAULT_AUTH_LOGIN = "evo_user"
        const val DEFAULT_AUTH_PASSWORD = "s3rv1c3"
        const val USER_AUTH_TYPE_KEY = "user_auth_type_key"
    }

    fun isAuth(): Boolean
    {
        return (preferences.getInt(USER_AUTH_TYPE_KEY, EAuthType.NONE_AUTH.value) != EAuthType.NONE_AUTH.value)
    }

    fun authByLogin(username: String, password: String, completion: (String?)->Unit)
    {
        var error: String? = null
        if((DEFAULT_AUTH_LOGIN == username) && (DEFAULT_AUTH_PASSWORD == password))
        {
            status = EAuthStatus.OFFLINE_AUTH
            preferences.edit().putInt(USER_AUTH_TYPE_KEY, EAuthType.AUTH_BY_LOGIN.value).apply()
        }
        else
        {
            status = EAuthStatus.NON_AUTH
            error = "Incorrect login or password"
        }

        completion.invoke(error)
    }

    fun logout()
    {
        preferences.edit().putInt(USER_AUTH_TYPE_KEY, EAuthType.NONE_AUTH.value).apply()
    }
}
