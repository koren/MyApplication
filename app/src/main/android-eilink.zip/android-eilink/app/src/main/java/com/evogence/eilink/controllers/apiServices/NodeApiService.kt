package com.evogence.eilink.controllers.apiServices

import com.evogence.eilink.common.ConnectionData
import com.evogence.eilink.common.json_rpc.JsonRpcRequest
import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.google.gson.GsonBuilder
import io.reactivex.Flowable
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

class NodeApiService: INodeApiService
{
    private lateinit var nodeApi: NodeAPI
    private lateinit var baseUrl: String
    private lateinit var fingerprint: String

    override fun build(connectionData: ConnectionData, fingerprint: String): INodeApiService
    {
        this.fingerprint = fingerprint
        this.baseUrl = connectionData.getFullAddress()

        val retrofit = Retrofit.Builder()
                .baseUrl(this.baseUrl)
                .client(OkHttpClient().newBuilder().build())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
                .build()

        this.nodeApi = retrofit.create<NodeAPI>(NodeAPI::class.java)
        return this
    }

    override fun getFingerprint(): String
    {
        return this.fingerprint
    }

    override fun getBaseURL(): String
    {
        return this.baseUrl
    }

    override fun request(request: JsonRpcRequest): Flowable<JsonRpcResponse>
    {
        return this.nodeApi.request(request)
    }

    private interface NodeAPI
    {
        @POST("/das-json.php")
        @Headers("Content-Type: application/json;charset=UTF-8")
        fun request(@Body request: JsonRpcRequest): Flowable<JsonRpcResponse>
    }

//    private fun getUnsafeOkHttpClient(): OkHttpClient
//    {
//        try
//        {
//            // Create a trust manager that does not validate certificate chains
//            val trustAllCerts = arrayOf<TrustManager>(object: X509TrustManager
//            {
//                @SuppressLint("TrustAllX509TrustManager")
//                @Throws(CertificateException::class)
//                override fun checkClientTrusted(chain: Array<java.security.cert.X509Certificate>,authType: String)
//                {
//
//                }
//
//                @SuppressLint("TrustAllX509TrustManager")
//                @Throws(CertificateException::class)
//                override fun checkServerTrusted(chain: Array<java.security.cert.X509Certificate>,authType: String)
//                {
//
//                }
//
//                override fun getAcceptedIssuers(): Array<X509Certificate?>
//                {
//                    return arrayOfNulls(0)
//                }
//            })
//
//            // Install the all-trusting trust manager
//            val sslContext = SSLContext.getInstance("TLS")
//            sslContext.init(null,trustAllCerts,java.security.SecureRandom())
//            // Create an ssl socket factory with our all-trusting manager
//            val sslSocketFactory = sslContext.socketFactory
//
//            var okHttpClient = OkHttpClient()
//            okHttpClient = okHttpClient.newBuilder()
//                    .sslSocketFactory(sslSocketFactory)
//                    .hostnameVerifier(org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER).build()
//
//            return okHttpClient
//        }
//        catch (e: Exception)
//        {
//            throw RuntimeException(e)
//        }
//
//    }
}