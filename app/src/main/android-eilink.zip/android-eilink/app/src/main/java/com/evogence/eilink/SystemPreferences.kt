package com.evogence.eilink

import android.content.Context
import android.preference.PreferenceManager

/**
 * Created by Koren Vitalii on 07/26/18.
 */
class SystemPreferences(val context: Context)
{
    private val MODE = "MODE"

    fun getServiceMode(): Boolean
    {
        val sharedPref = PreferenceManager.getDefaultSharedPreferences(context)
        return sharedPref.getBoolean(MODE, true)
    }

    fun setServiceMode(fullMode: Boolean)
    {
        val sharedPref = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = sharedPref.edit()
        editor.putBoolean(MODE, fullMode)
        editor.apply()
    }
}
