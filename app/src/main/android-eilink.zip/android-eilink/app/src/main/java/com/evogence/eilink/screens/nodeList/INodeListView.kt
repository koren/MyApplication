package com.evogence.eilink.screens.nodeList

import com.evogence.eilink.common.ui.IScreenView

/**
 * Created by Koren Vitalii on 05/21/18.
 */
interface INodeListView: IScreenView
{
    var presenter: NodeListPresenter
    fun initView()
    fun enableBottomButtonsContainer(enable: Boolean)
    fun changeStatusGroupOperationsBar()
}
