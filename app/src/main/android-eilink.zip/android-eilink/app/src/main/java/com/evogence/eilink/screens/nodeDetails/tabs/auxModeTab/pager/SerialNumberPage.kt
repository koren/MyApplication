package com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.pager

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.evogence.eilink.R
import com.evogence.eilink.common.ui.SelectorView
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.AuxModeVM
import com.evogence.eilink.screens.nodeDetails.tabs.auxModeTab.IAuxModeView
import kotlinx.android.synthetic.main.node_details_aux_mode_serial_number_tab.*

/**
 * Created by Koren Vitalii on 9/25/2018.
 */
class SerialNumberPage: AuxModePage(), View.OnClickListener
{
    override var auxModeView: IAuxModeView? = null
    override val title = "Serial number"
    private var viewModel: AuxModeVM? = null

    companion object
    {
        private const val FINGERPRINT_KEY = "fingerprint_key"

        fun build(fingerprint: String?): AuxModePage
        {
            val fragment = SerialNumberPage()
            val args = Bundle()
            args.putString(FINGERPRINT_KEY, fingerprint)
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View?
    {
        return inflater.inflate(R.layout.node_details_aux_mode_serial_number_tab, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {
        pairBtn.setOnTouchListener(SelectorView())
        pairBtn.setOnClickListener(this)
        viewModel?.let {fill(it)}
        super.onViewCreated(view, savedInstanceState)
    }

    override fun fill(model: AuxModeVM)
    {
        this.viewModel = model
        view?.let {serialNumberET.setText(model.modeConfiguration.snManual)}
    }

    override fun retrieveChanges(model: AuxModeVM)
    {
        model.modeConfiguration.snManual = serialNumberET?.text.toString()
    }

    override fun onClick(v: View?)
    {
        when(v?.id)
        {
            R.id.pairBtn -> auxModeView?.onClickPair()
        }
    }
}