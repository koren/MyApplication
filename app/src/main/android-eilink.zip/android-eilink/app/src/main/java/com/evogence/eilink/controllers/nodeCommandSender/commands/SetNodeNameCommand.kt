package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.CommandResult
import com.google.gson.JsonPrimitive

/**
 * Created by Koren Vitalii on 07/24/18.
 */
class SetNodeNameCommand(parameters: Any?): INodeCommand
{
    override val method: String = "Integration.RPN.settings.ProfilerService::setNodeTitle"
    override val desc: String = "Set Node Name"

    companion object MapKeys
    {
        const val TITLE_KEY = "title"
    }

    override var params: MutableMap<String, Any> = HashMap()

    init
    {
        if(parameters is String)
            params[TITLE_KEY] = parameters
    }

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return (response.result as? JsonPrimitive)?.isBoolean ?: false
    }

    override fun parseResponse(response: JsonRpcResponse): CommandResult
    {
        val commandResult = CommandResult()
        val result = (response.result as JsonPrimitive).asBoolean
        if(!result)
        {
            if((response.error) != null && (response.error!!.message != null))
            {
                commandResult.error = response.error!!.message
            }
            else
            {
                commandResult.error = "Configuration have not been changed."
            }
        }
        return commandResult
    }
}
