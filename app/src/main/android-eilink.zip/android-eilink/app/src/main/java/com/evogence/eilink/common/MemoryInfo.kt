package com.evogence.eilink.common

/**
 * Created by Koren Vitalii on 8/28/2018.
 */
class MemoryInfo
{
    //all in kB
    var totalRAM: Long = 0
    var freeRAM: Long = 0
    var totalFlash: Long = 0
    var availableFlash: Long = 0
    var reservedFlash: Long = 0
}