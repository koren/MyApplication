package com.evogence.eilink.controllers.nodeCommandSender.commands

import com.evogence.eilink.common.json_rpc.JsonRpcResponse
import com.evogence.eilink.controllers.nodeCommandSender.commands.INodeCommand

class ResetCommand(parameters: Any?): INodeCommand
{
    override var params: MutableMap<String, Any> = HashMap()
    override val method: String = ""
    override val desc: String = ""

    override fun isCorrectResponse(response: JsonRpcResponse): Boolean
    {
        return true
    }
}
