package com.evogence.eilink.controllers.apiServices;

import android.annotation.SuppressLint;
import com.evogence.eilink.common.ConnectionData;
import com.evogence.eilink.common.json_rpc.JsonRpcRequest;
import com.evogence.eilink.common.json_rpc.JsonRpcResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import io.reactivex.Flowable;
import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

/**
 * Created by Anatolij on 4/13/18.
 */
public class CentralAPIService implements CentralAPIInterface
{
    private final String baseUrl;
    private String fingerprint;
    protected CentralAPI esAPI;

    public CentralAPIService(ConnectionData connectionData, String fingerprint)
    {
        this.fingerprint = fingerprint;
        this.baseUrl = connectionData.getFullAddress();

        Gson gson = new GsonBuilder().create();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(connectionData.getFullAddress())
                .client(getUnsafeOkHttpClient())
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();

        esAPI = retrofit.create(CentralAPI.class);
    }

    @Override
    public Flowable<JsonRpcResponse> checkConnection()
    {
        Map<String, Object> params = new HashMap<>();
        params.put("data", fingerprint);
        return esAPI.request(new JsonRpcRequest("Integration.RPNES.RPNES_echo_service::_echo", params));
    }

    @Override
    public Flowable<JsonRpcResponse> authByPin(String pin, String companyCode)
    {
        Map<String, Object> params = new HashMap<>();
        params.put("pin", pin);
        params.put("company_code", companyCode);
        return esAPI.request(new JsonRpcRequest("IDServer.IDS_Allow::authEmployeeByPin", params));
    }

    @Override
    public Flowable<JsonRpcResponse> authByLogin(String login, String password, String companyCode)
    {
        Map<String, Object> params = new HashMap<>();
        params.put("login", login);
        params.put("password", password);
        params.put("company_code", companyCode);
        return esAPI.request(new JsonRpcRequest("IDServer.IDS_Allow::authEmployee", params));
    }

    @Override
    public String getUrl()
    {
        return null;
    }

    private interface CentralAPI
    {
        @POST("/das-json.php")
        @Headers({"Content-Type: application/json;charset=UTF-8"})
        Flowable<JsonRpcResponse> request(@Body JsonRpcRequest request);
    }

    private static OkHttpClient getUnsafeOkHttpClient()
    {
        try
        {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager()
            {
                @SuppressLint("TrustAllX509TrustManager")
                @Override
                public void checkClientTrusted(
                        java.security.cert.X509Certificate[] chain,
                        String authType) throws CertificateException
                {
                }

                @SuppressLint("TrustAllX509TrustManager")
                @Override
                public void checkServerTrusted(
                        java.security.cert.X509Certificate[] chain,
                        String authType) throws CertificateException
                {
                }

                @Override
                public java.security.cert.X509Certificate[] getAcceptedIssuers()
                {
                    return new java.security.cert.X509Certificate[0];
                }
            }};

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("TLS");
            sslContext.init(null, trustAllCerts,
                    new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext
                    .getSocketFactory();

            OkHttpClient okHttpClient = new OkHttpClient();
            okHttpClient = okHttpClient.newBuilder()
                    .sslSocketFactory(sslSocketFactory)
                    .hostnameVerifier(org.apache.http.conn.ssl.SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER).build();

            return okHttpClient;
        }
        catch(Exception e)
        {
            throw new RuntimeException(e);
        }
    }
}
